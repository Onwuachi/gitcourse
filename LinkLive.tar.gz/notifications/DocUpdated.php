<?php
$emailSubject='Shared folder “'.$_REQUEST['folder'].'” ';
if($_DOCS[1]['document'])
	$emailSubject=$emailSubject+'multiple documents updated';
else
	$emailSubject=$emailSubject+'document "'.$_REQUEST['document'].'" updated';
?><html>
<body>
This is an automated email notification that “<?=htmlspecialchars($_REQUEST['account'])?>” has updated
the following documents in the folder “<?=htmlspecialchars($_REQUEST['folder'])?>”:<br /><br />
<table border="0" cellpadding="2" cellspacing="0" style="border: 1px solid silver; border-collapse: collapse;">
<tr style="background-color: #e0e0e0;"><td style="border: 1px solid silver;">Document Name</td><td style="border: 1px solid silver;">Comments</td></tr>
<?php
$i=0;
while($_DOCS[$i]){
	echo'<tr><td style="border: 1px solid silver;">'.htmlspecialchars($_DOCS[$i]['document']).'</td><td style="border: 1px solid silver;">'.htmlspecialchars($_DOCS[$i]['comment']).'&nbsp;</td></tr>';
	$i=$i+1;
}
?>
</table>
</body>
</html>