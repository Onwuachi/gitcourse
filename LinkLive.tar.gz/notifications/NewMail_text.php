This is an automated email notification that you have secure mail waiting.

To log in, use the following information:
     Username:  <?=$_REQUEST['account']?>"
  Web Address:  https://<?php echo $_SERVER['host'];if(isset($_REQUEST['group']))echo '?group='.urlencode($_REQUEST['group']);?>

Please do not reply to this email, as it will not be received by anyone.


This message is intended only for the persons or entities to which it is
addressed. The information transmitted herein may contain proprietary or
confidential material. Review, reproduction, retransmission, distribution,
disclosure or other use, and any consequent action taken by persons or
entities other than intended recipients, are prohibited and may be unlawful.
If you are not the intended recipient, please delete this information from
your system and contact the sender. The information contained herein is
subject to change without notice. Although reasonable precautions have been
taken to ensure that no viruses are present, the sender makes no warranty or
guaranty with respect thereto, and is not responsible for any loss or damage
arising from the receipt or use of this e-mail or attachments hereto.