<?php
$emailSubject='Shared users added to  "'.$_REQUEST['folder'].'"';
?><html>
<body>
This is an automated email notification that “<?=htmlspecialchars($_REQUEST['account'])?>” has added the following
users view access to the shared folder “<?=htmlspecialchars($_REQUEST['folder'])?>”:
<br/><br/>
“<?=htmlspecialchars($_REQUEST['userlist'])?>”
<br/><br/>
<?php
if($_REQUEST['rightlist'])
  echo'The users were granted the following additional rights: “'.htmlspecialchars($_REQUEST['rightlist']).'”';
?>
</body>
</html>