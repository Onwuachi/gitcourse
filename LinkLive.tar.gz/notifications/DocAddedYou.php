<?php
$emailSubject='You were granted access to  "'.$_REQUEST['folder'].'"';
?><html>
<body>
This is an automated email notification that “<?=htmlspecialchars($_REQUEST['account'])?>” has given you
access to the shared folder “<?=htmlspecialchars($_REQUEST['folder'])?>”.
<br/><br/>
<?php
if($_REQUEST['rightlist'])
  echo'You were granted the following additional rights: “'.htmlspecialchars($_REQUEST['rightlist']).'”';
?>
</body>
</html>