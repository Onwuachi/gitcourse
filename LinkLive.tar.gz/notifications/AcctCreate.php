<html>
<body>
<br/>
This is an automated email notification that <?php echo htmlspecialchars($_REQUEST['display']);?> has sent you secure email.
If this is unexpected, you are safe to ignore this message.
<br/><br/>
<?php
$link='https://'.$_SERVER['host'].'/?authtoken='.urlencode($_REQUEST['token']).'&group='.urlencode($_REQUEST['group']);
?>
To automatically log in, <a href="<?=$link?>">click here</a>, then set your password.
<br/><br/>
Or copy the following link into your web browser:
<br/><br/>
<?=$link?>
<br/><br/>
Please do not reply to this email, as it will not be received by anyone.
<p style="font-size: xx-small;">
This message is intended only for the persons or entities to which it is addressed. The information transmitted herein may contain proprietary or confidential material. Review, reproduction, retransmission, distribution, disclosure or other use, and any consequent action taken by persons or entities other than intended recipients, are prohibited and may be unlawful. If you are not the intended recipient, please delete this information from your system and contact the sender. The information contained herein is subject to change without notice. Although reasonable precautions have been taken to ensure that no viruses are present, the sender makes no warranty or guaranty with respect thereto, and is not responsible for any loss or damage arising from the receipt or use of this e-mail or attachments hereto. 
</p>
</body>
</html>