<?php
include 'tableTop.php';
$urlTokenArg=$revation->getUrlTokenArg();
?>

<script>

var profiles = null;
var dataTable = dataTable = null;

$(document).ready(function(){
	$.ajax({
		type: 'GET',
		url: 'json/profileNames?<?=$urlTokenArg?>&custom=true',
		async: true,
		cache: false,
		success: function (json) {
			if (json.profiles){
				profiles = json.profiles;
				var data = [];
				for(var i=0;i<profiles.length;i++){
					data.push( [ i, profiles[i].use ] );
				}
				populateTable(data);
			}
		}
	});
});

$(window).on('unload',function() {
	tableConfigStore("profiles",dataTable.fnSettings());
});

function renderProfile( data, type, full ) {
	if(type=='display'){
		return '<div style="white-space: nowrap;"><button class="btn btn-secondary btn-xs" title="Properties of '+rwc_htmlescape(profiles[data].name)+'" onclick="window.location=\'embed.php?doc=ProfileAdd.html&<?=$urlTokenArg?>&edit='+encodeURIComponent(profiles[data].name)+'\';return false;">&#x270e;</button> <a href="embed.php?doc=ProfileAdd.html&amp;'+getUrlTokenArg()+'&amp;edit='+encodeURIComponent(profiles[data].name)+'&amp;">' + rwc_htmlescape(profiles[data].name) + '</a></div>';
	}
	else {
		return profiles[data].name;
	}
}

function populateTable(data) {
	var config = {
		"aaData": data,
		"bAutoWidth":false,
		responsive: true,
		"aoColumns": [
			{ "sTitle": "Profile Name", "mRender": renderProfile, responsivePriority: 1 },
			{ "sTitle": "Active Use" }
		]
	};
	tableConfigLoad("profiles", config);
	dataTable = $('#main_data_table').dataTable(config);
}
</script>

<div class='legend'>Profiles</div>
<table cellpadding="0" cellspacing="0" border="0" class="display table-striped table-bordered nowrap w-100" id="main_data_table">
<tfoot><tr><th>&nbsp;</th><th>&nbsp;</th></tr></tfoot>
</table>
<br/>
<div style='text-align:center;'>
<br/>
<?php
if($revation->adminGlobalView()){
	echo'<input type=button name=add value="Add New Profile" class="btn btn-secondary btn-sm" onclick="window.location=\'embed.php?doc=ProfileAdd.html&'.$urlTokenArg.'&add\';return false;">&nbsp;';
}
echo'<input type=button name=compare value="Compare Two Profiles" class="btn btn-secondary btn-sm" onclick="window.location=\'embed.php?doc=ProfileCompare.html&'.$urlTokenArg.'\';return false;">&nbsp;';
echo'<input type=button value="&#x21e6; Back" class="btn btn-dark btn-sm" onclick="window.location=\'embed.php?php=Tools&'.$urlTokenArg.'\';return false;">';
?>
</div>

<?php include 'tableBottom.php';?>