<?php
if(!isset($_SESSION)){
    include'/index.php';
    exit();
}
if(isset($_REQUEST['php']))
    include $_REQUEST['php']+'.php';
else{
    if(!isset($doc))
        $doc=$_REQUEST['doc'];
    $cc=mime_content_type($doc);
    if($cc!='text/html'){
        header('Content-Disposition: attachment; filename="'.urlencode($doc).'"'."; filename*=utf-8''".urlencode($doc));
    }
    http_send_content_type($cc);
    $revation->embed($doc);
}
?>