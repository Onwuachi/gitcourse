var g_data = null;
var dataTable = null;

function userHasRight(user, right) {
    if (user.rights) {
        for (var i = 0; i < user.rights.length; i++) {
            if (user.rights[i] == right) {
                return true;
            }
        }
    }
    return false;
}

function userRightsChanged() {
    $("#user_rights_changed").css('display', '');
}

function doSaveElement(id, right) {
    var e = document.getElementById('ri-' + right + '-' + id);
    if (e) {
        e.disabled = true;
        if (e.checked) {
            return right + ',';
        }
    }
    return '';
}

function doRightsSave() {
    for (var i = 0; i < document.users.elements.length; i++) {
        var element = document.users.elements[i];
        if (element.name.substring(0, 7) == "rights-") {
            // get the user
            var id = element.name.substring(7);

            // find the rights
            var r = doSaveElement(id, 'owner') + doSaveElement(id, 'collaborator') + doSaveElement(id, 'inviter');

            // lop off the trailing comma
            if (r.length > 0) {
                r = r.substring(0, r.length - 1);
            }

            // save the results
            element.value = r;
        }
    }
    var formData = $("#users").serialize();
    $('#userRightsDialog').modal('hide');
    loadTable(formData);
}

function doUserRights(user) {
    var html;
    html = '<tr style="background-color: #f6f6f6;"><td style="min-width: 0">' + user.id + '</td><td style="min-width: 0"><input type="hidden" name="rights-' + user.id + '" value="">';
    html += '<input type="checkbox" onchange="userRightsChanged();" id="ri-owner-' + user.id + '"';
    if (userHasRight(user, 'owner'))
        html += ' checked';
    html += '></td><td style="min-width: 0"><input type="checkbox" onchange="userRightsChanged();" id="ri-collaborator-' + user.id + '"';
    if (userHasRight(user, 'collaborator'))
        html += ' checked';
    html += '></td style="min-width: 0"><td style="min-width: 0"><input type="checkbox" onchange="userRightsChanged();" id="ri-inviter-' + user.id + '"';
    if (userHasRight(user, 'inviter'))
        html += ' checked';
    html += "></td><td style='min-width: 0' >" + (user.from ? user.from : '(creator)') + "</td><td style='min-width: 0'><a class='btn btn-secondary btn-sm' href='#' onclick='userRightsChanged();$(this).closest(\"tr\").remove();return false;' title=\"Delete all access for " + user.id + "\" class='delete'>Delete</a></td></tr>";
    return html;
}

function doAddUser() {
    var id = $('#user_new').val();
    if (id && id.length) {
        var user = {
            id: id,
            from: '(admin)'
        };
        var t = $('#user_rights_table tr:last').before(doUserRights(user));

        $('#user_new').val('');
        userRightsChanged();
    }
}

function showUserRightsDialog(index) {
    var folder = g_data.docFolders[index];

    html = '';
    html += '<div class="modal fade text-center" id="userRightsDialog" role="dialog" style="text-align: center; ">';
    html += '<div class="modal-dialog" role="document" style="padding-top: 15%; text-align: left; max-width: 100%; width: auto !important; display: inline-block;" >';
    html += '<div class="modal-content" style="overflow: auto;">';
    html += '<div class="modal-header light-background">';
    html += '<h5 class="modal-title">User Rights</h5>';
    html += '<button type="button" class="close" data-dismiss="modal">&times;</button>';
    html += '</div>';
    html += '<div class="modal-body">';
    html += '<form method="post" enctype="application/x-www-form-urlencoded" action="docs.php?' + getUrlTokenArg() + '" id="users" name="users">';
    html += '<input type="hidden" name="cmd" value="doc-folder-users">';
    html += '<input type="hidden" name="fldrref" value="' + folder.reference + '">';
    html += '<table id="user_rights_table" cellpadding="2" cellspacing="0"><tr class="mainline"><th>Who</th><th>Owner</th><th>Collaborator</th><th>Inviter</th><th>Invited By</th><th>&nbsp;</th></tr>';
    var users = folder.descriptor.config.users;
    for (var i = 0; i < users.length; i++) {
        html += doUserRights(users[i]);
    }
    html += '<tr><td colspan=6 align="center" >';
    html += '<div id="user_rights_changed" style="display: none; text-align: center; margin-bottom: .5em; background-color: red; color: white;">Changes not yet saved!</div>';
    html += '<input type=text id="user_new" placeholder="presence id" autofocus /> ';
    html += '<input type=button value="Add User" class="btn btn-secondary btn-sm" onclick="doAddUser();return false;" /> &nbsp; &nbsp; ';
    html += '<input type=button value=Save class="btn btn-secondary btn-sm" onclick="doRightsSave();return false;" /> ';
    html += '<input type="button" value=Cancel class="btn btn-secondary btn-sm" data-dismiss="modal";return false;" />';
    html += '</td></tr>';
    html += '</table>';
    html += '</form>';
    html += '</div>';
    html += '</div>';
    html += '</div>';
    html += '</div>';

    $('#userRightsDialog').replaceWith(html);
    $("#userRightsDialog").modal('show');   

}

function detail_format(oTable, nTr) {
    var aData = oTable.fnGetData(nTr);
    var sOut = '<table class="table-striped table-bordered nowrap" cellpadding="0" cellspacing="0" border="0" style="width: 100%;">';
    sOut += '<tr>';
    sOut += '<th>' +
        'Users &nbsp; ' +
        '<input type=button value="Edit Users" class="btn btn-secondary btn-sm" onclick="showUserRightsDialog(' + aData[5] + ');return false;">' +
        '</th>';
    sOut += '<th>' +
        'Files &nbsp; ' +
        '<input type=button value="Delete Entire Folder" class="btn btn-secondary btn-sm" onclick="if(confirm(\'Are you sure you want to COMPLETELY delete the folder ' + rwc_htmlescape(aData[0]) + '?\'))loadTable(\'cmd=doc-folder-delete&fldrref=' + g_data.docFolders[aData[5]].reference + '\');return false;">' +
        '</th>';
    sOut += '</tr>';
    sOut += '<tr>';
    var files = '';
    var folder = g_data.docFolders[aData[5]];
    for (var i = 0; i < folder.descriptor.folders.length; ++i) {
        var fn = folder.descriptor.folders[i].name;
        files += "<a href='/download.php?filename=" + escape(fn) + "&" + getUrlTokenArg() + "&pg=" + privateGroup + "&cmd=mail-attachment&mailbox=%3c" + folder.reference + "%3e" + escape(fn) + "&att=0'>" + rwc_htmlescape(fn) + "</a>";
        files += "<br/>";
    }
    sOut += '<td valign="top">' + (aData[3].length ? aData[3] : '(none)') + '</td>';
    sOut += '<td valign="top">' + (files.length ? files : '(none)') + '</td>';
    sOut += '<td>&nbsp;</td>';
    sOut += '</tr>';

    sOut += '</table>';
    return sOut;
}


function eclick(_this) {
    var t = $(_this);
    var tr = t.parents('tr')[0];
    var span = t.children('span')[0];
    if (dataTable.fnIsOpen(tr)) {
        span.innerHTML = "&#x25B6;";
        dataTable.fnClose(tr);
    }
    else {
        span.innerHTML = "&#x25BC;";
        dataTable.fnOpen(tr, detail_format(dataTable, tr), 'details');
    }
    return false;
}


function renderFolder(data, type, full) {
    if (type == 'display') {
        return "<a href='#' onclick='return eclick(this);'><span>&#x25B6;</span> " + rwc_htmlescape(data) + "</a>";
    }
    else {
        return data;
    }
}


function loadTable(parms) {
    $.ajax({
        type: 'POST',
        url: 'json/docFolders?' + getUrlTokenArg(),
        async: true,
        cache: false,
        data: parms,
        success: function (json) {
            g_data = json;
            var data = [];
            if (json.docFolders) {
                for (var i = 0; i < json.docFolders.length; i++) {
                    var users = '';
                    for (var j = 0; j < json.docFolders[i].descriptor.config.users.length; j++) {
                        if (users.length) {
                            users += '<br/>';
                        }
                        users += rwc_htmlescape(json.docFolders[i].descriptor.config.users[j].id);
                    }
                    var files = '';
                    for (var j = 0; j < json.docFolders[i].descriptor.folders.length; j++) {
                        if (files.length) {
                            files += '<br/>';
                        }
                        files += rwc_htmlescape(json.docFolders[i].descriptor.folders[j].name);
                    }
                    data.push([
                        json.docFolders[i].descriptor.alias,
                        json.docFolders[i].descriptor.config.users.length,
                        json.docFolders[i].descriptor.folders.length,
                        users,
                        files,
                        i
                    ]);
                }
            }
            if (dataTable == null) {
                var config = {
                    "aaData": data,
                    "bAutoWidth": false,
                    responsive: true,
                    "oLanguage": {
                        "sEmptyTable": "(none set)"
                    },
                    "aoColumns": [
                        { "mRender": renderFolder, responsivePriority: 1 },
						{ "bSearchable": false },
						{ "bSearchable": false },
						{ "bVisible": false },
						{ "bVisible": false },
						{ "bSearchable": false, "bVisible": false }
                    ]
                };
                tableConfigLoad("docres", config);
                dataTable = $('#main_data_table').dataTable(config);
            }
            else {
                dataTable.fnClearTable();
                if (data.length) {
                    dataTable.fnAddData(data);
                }
            }
        }
    });
}

$(document).ready(function () {
    loadTable();
});

$(window).on('unload',function () {
    tableConfigStore("docres", dataTable.fnSettings());
});