<?php
include 'tableTop.php';
include 'groupPre.php';
echo'Testing';
include 'groupStart.php';
$urlTokenArg=$revation->getUrlTokenArg();
?>

<table>
<tr><td>Test telephone number routing:</td><td><input type=button value='Test Tel Routing' class='btn btn-secondary btn-sm' onclick="window.location='embed.php?doc=UserDial.html&<?=$urlTokenArg?>&back_php=Tools';return false;"></td></tr>
<tr><td>Test DTMF dial-by-name routing:</td><td><input type=button value='Test DTMF Routing' class='btn btn-secondary btn-sm' onclick="window.location='embed.php?doc=UserDtmf.html&<?=$urlTokenArg?>&back_php=Tools';return false;"></td></tr>
<tr><td>Test user credentials:</td><td><input type=button value='Test User Credentials' class='btn btn-secondary btn-sm' onclick="window.location='embed.php?doc=UserTest.html&<?=$urlTokenArg?>';return false;"></td></tr>
<tr><td>Test chat text filter:</td><td><input type=button value='Test Chat Text Filter' class='btn btn-secondary btn-sm' onclick="window.location='embed.php?doc=ChatFilter.html&<?=$urlTokenArg?>';return false;"></td></tr>
</table>

<?php
include 'groupEnd.php';
include 'groupPre.php';
echo'Managing';
include 'groupStart.php';
echo'<table>';
if($revation->adminGlobal())
	$needgroup='disabled=disabled';
if($revation->adminGlobalView())
	echo'<tr><td>Add a new service:</td><td><input type=button value="Add Service" class="btn btn-secondary btn-sm" '.$needgroup.' onclick="window.location=\'embed.php?php=NewService&'.$urlTokenArg.'\';return false;"></td></tr>';
$_SESSION['nav_back']='Tools';
?>
<tr><td>Manage user directories:</td><td><input type=button value='Directories' class='btn btn-secondary btn-sm' onclick="window.location='embed.php?doc=Directories.html&<?=$urlTokenArg?>&back_php=Tools';return false;"></td></tr>
<tr><td>Manage user status menus:</td><td><input type=button value='Status Menus' class='btn btn-secondary btn-sm' onclick="window.location='embed.php?doc=StatusMenus.html&<?=$urlTokenArg?>&back_php=Tools';return false;"></td></tr>
<tr><td>Manage user shortcut lists:</td><td><input type=button value='Shortcut Lists' class='btn btn-secondary btn-sm' onclick="window.location='embed.php?doc=ShortcutLists.html&<?=$urlTokenArg?>&back_php=Tools';return false;"></td></tr>
<tr><td>Manage user authentication:</td><td>
	<input type=button name=ldap value="LDAP" class='btn btn-secondary btn-sm' onclick="window.location='embed.php?php=LdapConfig&<?=$urlTokenArg?>';return false;">
	<input type=button name=openidc value="OpenID Connect" class='btn btn-secondary btn-sm' onclick="window.location='embed.php?php=OpenIDCreds&<?=$urlTokenArg?>';return false;">
	<input type=button name=saml2 value="SAML 2.0" class='btn btn-secondary btn-sm' onclick="window.location='embed.php?php=SAML2&<?=$urlTokenArg?>';return false;">
	<input type=button name=shared value="Shared Auth" class='btn btn-secondary btn-sm' onclick="window.location='embed.php?php=SharedAuth&<?=$urlTokenArg?>';return false;">
</td></tr>
<tr><td>Manage user profiles:</td><td><input type=button value='User Profiles' class='btn btn-secondary btn-sm' onclick="window.location='embed.php?php=Profiles&<?=$urlTokenArg?>';return false;"></td></tr>
<tr><td>Manage trunking access:</td><td><input type=button name=outbound value="Outbound Restrictions" class='btn btn-secondary btn-sm' <?=$needgroup?> onclick="window.location='embed.php?php=TrunkRestrictions&<?=$urlTokenArg?>';return false;"> <input type=button name=outbound value="Inbound Redirects" class='btn btn-secondary btn-sm' <?=$needgroup?> onclick="window.location='embed.php?php=TrunkRedirects&<?=$urlTokenArg?>';return false;"></td></tr>
<tr><td>Manage API Origins:</td><td><input type=button name=apiorigins value="API Origins" class='btn btn-secondary btn-sm' onclick="window.location='embed.php?php=APIOrigins&<?=$urlTokenArg?>';return false;"></td></tr>
<tr><td>Manage unauthenticated access:</td><td><input type=button name=outbound value="Unauthenticated Requests" class='btn btn-secondary btn-sm' onclick="window.location='embed.php?php=UnauthRequests&<?=$urlTokenArg?>';return false;"></td></tr>
<tr><td>Manage SMTP servers:</td><td>
	<input type=button name=smtps value="SMTP Servers" class='btn btn-secondary btn-sm' onclick="window.location='embed.php?doc=SmtpConfigs.html&<?=$urlTokenArg?>';return false;">
</td></tr>
</table>
<?php
if($revation->adminRight('ar_broadcast')){
	include 'groupEnd.php';
	include 'groupPre.php';
	echo'Contacting';
	include 'groupStart.php';
	echo'<table>';
	echo'<tr><td>Broadcast message to Communicator users:</td><td><input type=button value="Broadcast Message" class="btn btn-secondary btn-sm" onclick="window.location=\'embed.php?doc=Broadcast.html&'.$urlTokenArg.'\';return false;"></td></tr>';
	echo'<tr><td>Send Secure Mail to users:</td><td><input type=button value="Send Mail" class="btn btn-secondary btn-sm" onclick="window.location=\'embed.php?doc=SendMail.html&'.$urlTokenArg.'\';return false;"></td></tr>';
	echo'</table>';
}

include 'groupEnd.php';
include 'groupPre.php';
echo'Utilities';
include 'groupStart.php';
echo'<table>';

echo'<tr><td>Set User Passwords as Expired:</td><td><input type=button value="Expire Passwords" class="btn btn-secondary btn-sm" onclick="window.location=\'embed.php?php=PassReset&'.$urlTokenArg.'\';return false;"';
if(!$revation->adminRight('ar_profiles')){
  echo' disabled=disabled';
}
echo'></td></tr>';

echo'<tr><td>Set Restricted Passwords:</td><td><input type=button value="Restricted Passwords" class="btn btn-secondary btn-sm" onclick="window.location=\'embed.php?php=PassRestrict&'.$urlTokenArg.'\';return false;"';
if(!$revation->adminRight('ar_profiles')){
  echo' disabled=disabled';
}
echo'></td></tr>';

echo'<tr><td>View phone number logs:</td><td><input type=button value="Phone Logs" class="btn btn-secondary btn-sm" onclick="window.location=\'embed.php?php=PhoneLogs&'.$urlTokenArg.'\';return false;" '.$needgroup.'></td></tr>';

echo'<tr><td>View document folders:</td><td><input type=button value="Document Folders" class="btn btn-secondary btn-sm" onclick="window.location=\'embed.php?php=DocFolders&'.$urlTokenArg.'\';return false;" '.$needgroup.'></td></tr>';

echo'<tr><td>Download a .csv file of all users:</td><td><form method=post action="embedalone.php?doc=UserDump.csv&'.$urlTokenArg.'" target="_blank"><input type=hidden name=pg value="'.$revation->adminGroup().'"><input type=submit name=dump value="Download .CSV" class="btn btn-secondary btn-sm" '.$needgroup.'></form></td></tr>';
echo'<tr><td>Upload a .csv of user changes:</td><td><form method="post" action="embed.php?doc=UsersUpload.html&'.$urlTokenArg.'" enctype="multipart/form-data" style="display: inline;"><input type=hidden name=pg value="'.$revation->adminGroup().'"><label class="btn btn-secondary btn-sm';
if($needgroup)echo' disabled';
echo'" style="margin-bottom: 0;"><input hidden title="Upload .CSV" type="file" name="filename" id="uploadButton" '.$needgroup.' onchange="if(this.value){if(this.value.search(/\.csv/i)==-1){alert(\'file not of correct extension!\');this.form.reset();return false;}else{this.form.submit();return true;}}" />Upload .CSV...</label> <label><input type="checkbox" name="test_mode" checked="checked" '.$needgroup.'/> test mode</label></form></td></tr>';

echo'<tr><td>View deleted users:</td><td><input type=button value="Deleted Users" class="btn btn-secondary btn-sm" onclick="window.location=\'embed.php?php=DelUsers&'.$urlTokenArg.'\';return false;" '.$needgroup.'></td></tr>';

if($revation->adminRight('ar_ucroutes')){
	echo'<tr><td>Link with other domains:</td><td><input type=button value="UC Routes" class="btn btn-secondary btn-sm" onclick="window.location=\'embed.php?php=LinkRoutes&'.$urlTokenArg.'\';return false;"></td></tr>';
}

echo'<tr><td>Manage Calendars:</td><td><input type=button value="Calendars" class="btn btn-secondary btn-sm" onclick="window.location=\'embed.php?doc=Calendars.html&'.$urlTokenArg.'\';return false;"></td></tr>';

if($revation->adminGlobal())
	$needgroup='disabled=disabled';
if($revation->adminGlobalView())
	echo'<tr><td>Enable Appointment Scheduling:</td><td><input type=button value="Appointment Scheduling" class="btn btn-secondary btn-sm" '.$needgroup.' onclick="window.location=\'embed.php?php=ApptScheduling&'.$urlTokenArg.'\';return false;"></td></tr>';

if($revation->adminGlobalView())
	echo'<tr><td>Lookup User by Mailbox:</td><td><input type=button value="Lookup User" class="btn btn-secondary btn-sm" '.$needgroup.' onclick="window.location=\'embed.php?doc=UserLookup.html&'.$urlTokenArg.'\';return false;"></td></tr>';

echo'</table>';


include 'groupEnd.php';
include 'tableBottom.php';
?>
