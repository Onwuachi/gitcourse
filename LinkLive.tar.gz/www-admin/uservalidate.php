<?php
if(strpos($_REQUEST['callback'],'..')||strcspn($_REQUEST['callback'],'><:/&,?%*"\'\\')<strlen($_REQUEST['callback']))
	unset($_REQUEST['callback']);
if($_REQUEST['callback']){
	header('Content-Type: text/javascript');
	echo$_REQUEST['callback'].'(';
}
else
	header('Content-Type: application/json');
echo'{';
if($_REQUEST['id'])
	echo'"id":'.json_encode($_REQUEST['id']).',';
echo '"results":"'.$revation->userAuth($_REQUEST['pid'],$_REQUEST['user'],$_REQUEST['pswd'],$_REQUEST['group']).'","profile":'.json_encode($_REQUEST['profile']);
echo'}';
if($_REQUEST['callback'])
	echo');';
?>