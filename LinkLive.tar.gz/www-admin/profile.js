﻿function profile_row_show(e, b, s) {
    if (s) {
        e.addClass('open');
        e.find('span').html('&#x25BC;');
        b.addClass('open');
    }
    else {
        e.removeClass('open');
        e.find('span').html('&#x25B6;');
        b.removeClass('open');
    }
}

function profile_row_toggle() {
    var id = $(this).attr('name').substr(9);
    var e = $("[name='profrow_t" + id + "']");
    var b = $("[name='profrow_c" + id + "']");
    profile_row_show(e, b, !e.hasClass('open'));
}

function profile_show_all(show) {
    profile_row_show($("[name^='profrow_t']"), $("[name^='profrow_c']"), show);
}

function profile_disable_all() {
    var es = $("[name^='profrow_c']");
    es.find('input').prop('disabled', true);
    es.find('select').find('option:not(:selected)').attr('disabled', true);
}

function important_info(page) {
    return "<a href='#' alt='important information!' class='btn btn-warning btn-sm rev-help' onclick=\"window.open('Help/" + page + ".html','help','width=512,height=600,scrollbars=yes','alwaysRaised')\">&#x1f6c8; Important information</a>";
}



function calendarOwnershipChanged() {
    var cpa = $('#calendarProfileAssociation');
    if (!$('#calendarOwnership').is(':checked')) {
        cpa.prop('disabled', true).css("background-color", "d3d3d3").prop('checked', false);
    }
    else {
        cpa.prop('disabled', false).css("background-color", "#FFFFFF");
    }
}

function eFolderSharingChanged() {
    var cpa = $('#eFolderProfileSharing');
    if (!$('#eFolderCreation').is(':checked')) {
        cpa.prop('disabled', true).css("background-color", "d3d3d3").prop('checked', false);
    }
    else {
        cpa.prop('disabled', false).css("background-color", "#FFFFFF");
    }
}



var openList = [];

function titleChanged(title) {
    openList[title] = true;
}

function checked_if(b) {
    return b ? " checked" : "";
}



function profile_disable_div(parent_div) {
    // get the inputs from that div (except the default checkbox)
    var selects = $(parent_div).find('select');
    var inputs = $(parent_div).find('input').not('[id^=default_]');

    // set to enabled/disabled
    inputs.prop('disabled', true);
    selects.prop('disabled', true);
}

var g_profile = {
    editing: null,
    default: null,
    callbacks: []
};

function profile_set_data(parent_div, checked) {
    // set the data to either the main or the default
    if (g_profile.default) {
        var setter = parseInt(parent_div.data('setter'));
        if (setter > 0 && typeof g_profile.callbacks[setter - 1] === 'function') {
            g_profile.callbacks[setter - 1](checked ? g_profile.default : g_profile.editing);
        }
    }
}

function profile_toggle_default() {
    // get the parent div for the default section
    var parent_div = $(this).closest('div.prodef');

    // get the current check state
    var checked = $(this).is(':checked');

    // set the data
    profile_set_data(parent_div, checked);

    // get the inputs from that div (except the default checkbox)
    var selects = parent_div.find('select');
    var inputs = parent_div.find('input').not(this);

    // set to enabled/disabled
    inputs.prop('disabled', checked);
    selects.prop('disabled', checked);
}

function profile_table_init(defaults, add_default_selectors, isNewProfile) {
    $(".profrow_t").on("click", profile_row_toggle);
    if (add_default_selectors) {
        $(".prodef").each(function () {
            var id = $(this).attr('id').substr(5);  // 'prof_'
            var is_default_checked = isNewProfile;
            if (!is_default_checked && defaults) {
                for (var i = 0; i < defaults.length; ++i) {
                    if (id === defaults[i]) {
                        is_default_checked = true;
                        break;
                    }
                }
            }
            var check = "<div class='profrow_d'><label><input type=checkbox id=default_" + id;
            if ($(this).data('disabled')) {
                check += ' disabled=disabled';
            }
            if (is_default_checked) {
                check += ' checked=checked';
                if (isNewProfile) {
                    // set the data
                    profile_set_data($(this), true);
                }
            }
            check += "> default</label></div>";
            $(this).prepend(check);
            if (is_default_checked) {
                profile_disable_div(this);
            }
        });
        $(".profrow_d input").on("click", profile_toggle_default);
        var f = $("form[name=f]");
        f.append('<input type=hidden id=defaults name=defaults />');
        f.on("submit", function () {
            // marshal up the default checkboxes
            var defs = $('input[id^=default_]');
            var d = '[';
            defs.each(function () {
                if ($(this).is(':checked')) {
                    if (d.length > 1) {
                        d += ',';
                    }
                    d += '\"' + $(this).attr('id').substr(8) + '\"';
                }
            });
            d += ']';
            $('#defaults').val(d);
        });
    }
}

function getTitle(title, profrow, openAll) {
    var changed = title in openList;
    var open = changed || openAll;
    var html = "<div class='profrow_t" + (open ? " open" : "") + "' name='profrow_t" + profrow + "'><span>" + (open ? "&#x25BC;" : "&#x25B6;") + "</span> " + title + "</div><div class='profrow_c" + (open ? " open" : "") + (changed ? " changed" : "") + "' name='profrow_c" + profrow + "'>";
    return html;
}

function endTitle() {
    return "</div>";
}

function get_default_start(name, setter, disableDefault) {
    var html = "<div class=prodef id=prof_" + name;
    if (disableDefault) {
        html += ' data-disabled=true';
    }
    if (setter) {
        var index = g_profile.callbacks.push(setter);
        html += ' data-setter=' + index;
    }
    return html + " >";
}

function get_default_end() {
    return "</div>";
}

function get_default_restart(name, setter, disableDefault) {
    return get_default_end() + get_default_start(name, setter, disableDefault);
}

function rightToNumber(right) {
    if (right === "send") {
        return 1;
    }
    else if (right === "recv") {
        return 2;
    }
    else if (right === "sendrecv") {
        return 3;
    }
    else {
        // "no"
        return 0;
    }
}

function ProfileApplications() {
    var next_i = 0;

    var _add = function (app) {
        next_i++;
        var li = "<li><input type=button class='btn btn-secondary btn-sm' value='&#x1F5D1;' onclick='$(this).closest(\"li\").remove();return false;'/> id <input type=text name=app_id_" + next_i + " value=\"" + rwc_htmlescape(app.id) + "\"> app <input type=text name=app_" + next_i + " value=\"" + rwc_htmlescape(app.app) + "\"></li>";

        $('#applications li:last').before(li);
        $('#applications_max').val(next_i);
    };

    // add a new empty host line
    this.add = function () {
        _add({ id: '', app: '' });
    };

    // load the table
    this.init = function (list) {
        if (list && typeof list === 'object') {
            for (var i = 0; i < list.length; ++i) {
                _add(list[i]);
            }
        }
    }
}

var profileApplications = new ProfileApplications();

let languages = [
    { d: "Afrikaans", c: "af" },
    { d: "Albanian", c: "sq" },
    { d: "Amharic", c: "am" },
    { d: "Arabic", c: "ar" },
    { d: "Armenian", c: "hy" },
    { d: "Azerbaijani", c: "az" },
    { d: "Bengali", c: "bn" },
    { d: "Bosnian", c: "bs" },
    { d: "Bulgarian", c: "bg" },
    { d: "Catalan", c: "ca" },
    { d: "Chinese - Simplified", c: "zh" },
    { d: "Chinese - Traditional", c: "zh-TW" },
    { d: "Croatian", c: "hr" },
    { d: "Czech", c: "cs" },
    { d: "Danish", c: "da" },
    { d: "Dari", c: "fa-AF" },
    { d: "Dutch", c: "nl" },
    { d: "English", c: "en" },
    { d: "Estonian", c: "et" },
    { d: "Farsi - Persian", c: "fa" },
    { d: "Filipino, Tagalog", c: "tl" },
    { d: "Finnish", c: "fi" },
    { d: "French", c: "fr" },
    { d: "French - Canada", c: "fr-CA" },
    { d: "Georgian", c: "ka" },
    { d: "German", c: "de" },
    { d: "Greek", c: "el" },
    { d: "Gujarati", c: "gu" },
    { d: "Haitian Creole", c: "ht" },
    { d: "Hausa", c: "ha" },
    { d: "Hebrew", c: "he" },
    { d: "Hindi", c: "hi" },
    { d: "Hungarian", c: "hu" },
    { d: "Icelandic", c: "is" },
    { d: "Indonesian", c: "id" },
    { d: "Irish", c: "ga" },
    { d: "Italian", c: "it" },
    { d: "Japanese", c: "ja" },
    { d: "Kannada", c: "kn" },
    { d: "Kazakh", c: "kk" },
    { d: "Korean", c: "ko" },
    { d: "Latvian", c: "lv" },
    { d: "Lithuanian", c: "lt" },
    { d: "Macedonian", c: "mk" },
    { d: "Malay", c: "ms" },
    { d: "Malayalam", c: "ml" },
    { d: "Maltese", c: "mt" },
    { d: "Marathi", c: "mr" },
    { d: "Mongolian", c: "mn" },
    { d: "Norwegian - Bokmål", c: "no" },
    { d: "Pashto", c: "ps" },
    { d: "Polish", c: "pl" },
    { d: "Portuguese - Brazil", c: "pt" },
    { d: "Portuguese - Portugal", c: "pt-PT" },
    { d: "Punjabi", c: "pa" },
    { d: "Romanian", c: "ro" },
    { d: "Russian", c: "ru" },
    { d: "Serbian", c: "sr" },
    { d: "Sinhala", c: "si" },
    { d: "Slovak", c: "sk" },
    { d: "Slovenian", c: "sl" },
    { d: "Somali", c: "so" },
    { d: "Spanish", c: "es" },
    { d: "Spanish - Mexico", c: "es-MX" },
    { d: "Swahili", c: "sw" },
    { d: "Swedish", c: "sv" },
    { d: "Tamil", c: "ta" },
    { d: "Telugu", c: "te" },
    { d: "Thai", c: "th" },
    { d: "Turkish", c: "tr" },
    { d: "Ukrainian", c: "uk" },
    { d: "Urdu", c: "ur" },
    { d: "Uzbek", c: "uz" },
    { d: "Vietnamese", c: "vi" },
    { d: "Welsh", c: "cy" }
];



function profile_write_table(profile, timezoneInfo, profileNames, passPolicies, namedElements, disabledIfNotGlobal, ar_e911clid, openAll, doInit, isNewProfile, profileDefault) {
    g_profile.editing = profile;
    g_profile.default = profileDefault;

    disabledIfNotGlobal = disabledIfNotGlobal ? " disabled" : "";
    var html = '';
    var profrow = 1;



    html += getTitle('File Transfer', profrow++, openAll);
    var radio_name = namedElements ? " name=fileXfer" : "";
    html += get_default_start('fileTransfer_rights', function (profile) {
        $('input[name=fileXfer][value=' + rightToNumber(profile.fileXfer.right) + ']').prop("checked", true);
    }) +
        "<label><input type=radio value=0" + radio_name + checked_if(profile.fileXfer.right === "no") + "> No</label> &nbsp; " +
        "<label><input type=radio value=1" + radio_name + checked_if(profile.fileXfer.right === "send") + "> Send</label> &nbsp; " +
        "<label><input type=radio value=2" + radio_name + checked_if(profile.fileXfer.right === "recv") + "> Receive</label> &nbsp; " +
        "<label><input type=radio value=3" + radio_name + checked_if(profile.fileXfer.right === "sendrecv") + "> Send/Receive</label>" +
        get_default_restart('fileTransfer_maxSendMB', function (profile) {
            $('input[name=fileXferMaxS]').val(profile.fileXfer.maxSend);
        }) +
        "Maximum Send Size: <input type=text name=fileXferMaxS style='text-align: right;' size='6' value=\"" + profile.fileXfer.maxSend + "\">MB" +
        get_default_end();
    radio_name = namedElements ? " name=fileXferAllow" : "";
    html +=
        get_default_start('fileTransfer_extensions', function (profile) {
            var val = profile.fileXfer.allow ? 1 : 0;
            $('input[name=fileXferAllow][value=' + val + ']').prop("checked", true);
            $('input[name=fileXferExtensions]').val(profile.fileXfer.extensions);
        }) +
        "<label><input type=radio value=0" + radio_name + checked_if(!profile.fileXfer.allow) + "> Disallow</label>, or " +
        "<label><input type=radio value=1" + radio_name + checked_if(profile.fileXfer.allow) + "> Allow these extensions:</label>" +
        " &nbsp; <input type=text name=fileXferExtensions style='width: 16em;' value=\"" + rwc_htmlescape(profile.fileXfer.extensions) + "\">" +
        get_default_end();
    html += endTitle();



    html += getTitle('Desktop Sharing', profrow++, openAll);
    val = profile.rds.right;
    radio_name = namedElements ? " name=rds" : "";
    html += get_default_start('rds_rights', function (profile) {
        $('input[name=rds][value=' + rightToNumber(profile.rds.right) + ']').prop("checked", true);
    }) +
        "<label><input type=radio value=0" + radio_name + checked_if(val === "no") + "> No</label> &nbsp; " +
        "<label><input type=radio value=1" + radio_name + checked_if(val === "send") + "> Share</label> &nbsp; " +
        "<label><input type=radio value=2" + radio_name + checked_if(val === "recv") + "> View</label> &nbsp; " +
        "<label><input type=radio value=3" + radio_name + checked_if(val === "sendrecv") + "> Share/View</label>" +
        get_default_restart('rdsUserAgents', function (profile) {
            $('input[name=rdsUserAgents]').val(profile.rds.userAgents);
        }) +
        "Disable specific User-Agents:<br/><input type=text name=rdsUserAgents style='width: 90%; margin-left: 5%;' value=\"" + rwc_htmlescape(profile.rds.userAgents) + "\">" +
        get_default_restart('rdsLogging', function (profile) {
            $('input[name=rdslog]').prop("checked", profile.rds.logged);
        }) +
        "<label><input type=checkbox name=rdslog id=rdslog" + checked_if(profile.rds.logged) + "> Log (<i>can be very large</i>)</label>" +
        get_default_restart('rdsLocation', function (profile) {
            $('input[name=rdsLocation]').val(profile.rds.location);
        }, disabledIfNotGlobal) +
        "Service Location: <input type=text name=rdsLocation value=\"" + rwc_htmlescape(profile.rds.location) + '\"' + disabledIfNotGlobal + '>' +
        get_default_restart('rds_data', function (profile) {
            var rdsRate = profile.rds.rate;
            if (!rdsRate || rdsRate < 0) {
                rdsRate = 30;
            }
            $('select[name=rdsRate]').val(rdsRate);
            var rdsData = profile.rds.data;
            if (!rdsData || rdsData < 0) {
                rdsData = 0;
            }
            $('select[name=rdsData]').val(rdsData);
        }, disabledIfNotGlobal) +
        "Frame rate: <select name=rdsRate" + disabledIfNotGlobal + '>';
    var rdsRate = profile.rds.rate;
    if (!rdsRate || rdsRate < 0) {
        rdsRate = 30;
    }
    var RdsRateOptions = [1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 20, 24, 30, 50, 60];
    for (i = 0; i < RdsRateOptions.length; i++) {
        html += "<option";
        if (RdsRateOptions[i] === rdsRate) {
            html += " selected";
        }
        html += '>' + RdsRateOptions[i] + "</option>";
    }
    html += "</select> data: <select name=rdsData" + disabledIfNotGlobal + '>';
    var rdsData = profile.rds.data;
    if (!rdsData || rdsData < 0) {
        rdsData = 0;
    }
    var RdsDataOptions = [0, 128, 192, 256, 384, 512, 768, 1024, 1536, 2048, 3072, 4096];
    for (i = 0; i < RdsDataOptions.length; i++) {
        html += "<option";
        if (RdsDataOptions[i] === rdsData) {
            html += " selected";
        }
        html += '>' + (i === 0 ? "default" : RdsDataOptions[i]) + "</option>";
    }
    html += "</select> kbps " +
        get_default_restart('rdsDetect', function (profile) {
            var val = profile.rds.detect.type;
            if (val === 'target') val = 1;
            else if (val === 'color') val = 2;
            else if (val === 'color_mask') val = 3;
            else if (val === 'color_rect') val = 4;
            else if (val === 'rect') val = 5;
            else val = 0;   // 'none'
            $('input[name=rdsDetectT][value=' + val + ']').prop("checked", true);
            $('input[name=rdsDetectF]').val(profile.rds.detect.fill);
            $('input[name=rdsDetectC]').val(profile.rds.detect.color);
            $('input[name=rdsDetectInv]').prop("checked", profile.rds.detect.invert);
        }, disabledIfNotGlobal);
    val = profile.rds.detect.type;
    radio_name = namedElements ? " name=rdsDetectT" : "";
    html +=
        "Signature Detection: " +
        "<label><input type=radio value=0" + radio_name + checked_if(val === 'none') + disabledIfNotGlobal + "> None</label> &nbsp; " +
        "<label><input type=radio value=1" + radio_name + checked_if(val === 'target') + disabledIfNotGlobal + "> Target Image</label> &nbsp; " +
        "<label><input type=radio value=2" + radio_name + checked_if(val === 'color') + disabledIfNotGlobal + "> Color</label> &nbsp; " +
        "<label><input type=radio value=3" + radio_name + checked_if(val === 'color_mask') + disabledIfNotGlobal + "> Color Mask</label> &nbsp; " +
        "<label><input type=radio value=4" + radio_name + checked_if(val === 'color_rect') + disabledIfNotGlobal + "> Color Rect</label> &nbsp; " +
        "<label><input type=radio value=5" + radio_name + checked_if(val === 'rect') + disabledIfNotGlobal + "> Rect Detect</label>" +
        "<br/> &nbsp; Color to Fill: <input type='color' name=rdsDetectF maxlength=7 size=7 value=\"" + rwc_htmlescape(profile.rds.detect.fill) + "\"> &nbsp;" +
        "Color to Detect <input type='color' name=rdsDetectC maxlength=7 size=7 value=\"" + rwc_htmlescape(profile.rds.detect.color) + "\">" +
        "<label><input type=checkbox name=rdsDetectInv id=rdsDetectInv" + checked_if(profile.rds.detect.invert) + "> Invert Fill Logic</label>" +
        get_default_end();
    html += endTitle();



    html += getTitle('Cobrowsing', profrow++, openAll);
    val = profile.cobrowse.right;
    radio_name = namedElements ? " name=cobrowse" : "";
    html += get_default_start('cobrowse_rights', function (profile) {
        $('input[name=cobrowse][value=' + rightToNumber(profile.cobrowse.right) + ']').prop("checked", true);
    }) +
        "<label><input type=radio value=0" + radio_name + checked_if(val === "no") + "> No</label> &nbsp; " +
        "<label><input type=radio value=1" + radio_name + checked_if(val === "send") + "> Share</label> &nbsp; " +
        "<label><input type=radio value=2" + radio_name + checked_if(val === "recv") + "> View</label> &nbsp; " +
        "<label><input type=radio value=3" + radio_name + checked_if(val === "sendrecv") + "> Share/View</label>" +
        get_default_restart('cobrowseLogging', function (profile) {
            $('input[name=cobrowselog]').prop("checked", profile.cobrowse.logged);
        }) +
        "<label><input type=checkbox name=cobrowselog" + checked_if(profile.cobrowse.logged) + "> Log (<i>can be large</i>)</label>" +
        get_default_end();
    html += endTitle();


    if (profile.appointmentScheduling) {
        html += getTitle('Appointment Scheduling', profrow++, openAll);
        html += get_default_start('apptschdProvider', function (profile) {
            $('input[name=apptschdPrvdr]').prop("checked", profile.appointmentScheduling.provider);
        }) +
        "<label><input type=checkbox name=apptschdPrvdr" + checked_if(profile.appointmentScheduling.provider) + "> Provider (will be able to register as a service provider)</label>" +
            get_default_restart('apptschdAdmin', function (profile) {
            $('input[name=apptschdAdm]').prop("checked", profile.appointmentScheduling.admin);
        }) +
        "<label><input type=checkbox name=apptschdAdm" + checked_if(profile.appointmentScheduling.admin) + "> Administrator (can manage the Appointment Scheduling experience)</label>" +
        get_default_end();
        html += endTitle();
    }


    html += getTitle('Video Broadcasting', profrow++, openAll);
    val = profile.video.right;
    radio_name = namedElements ? " name=video" : "";
    html += get_default_start('video_rights', function (profile) {
        $('input[name=video][value=' + rightToNumber(profile.video.right) + ']').prop("checked", true);
    }) +
        "<label><input type=radio value=0" + radio_name + checked_if(val === "no") + "> No</label> &nbsp; " +
        "<label><input type=radio value=1" + radio_name + checked_if(val === "send") + "> Broadcast</label> &nbsp; " +
        "<label><input type=radio value=2" + radio_name + checked_if(val === "recv") + "> View</label> &nbsp; " +
        "<label><input type=radio value=3" + radio_name + checked_if(val === "sendrecv") + "> Broadcast/View</label>" +
        get_default_restart('videoUserAgents', function (profile) {
            $('input[name=videoUserAgents]').val(profile.video.userAgents);
        }) +
        "Disable specific User-Agents:<br/><input type=text name=videoUserAgents style='width: 90%; margin-left: 5%;' value=\"" + rwc_htmlescape(profile.video.userAgents) + "\">" +
        get_default_restart('videoLogging', function (profile) {
            $('input[name=videolog]').prop("checked", profile.video.logged);
        }) +
        "<label><input type=checkbox name=videolog" + checked_if(profile.video.logged) + "> Log (<i>can be very large</i>)</label>" +
        get_default_restart('videoLocation', function (profile) {
            $('input[name=videoLocation]').val(profile.video.location);
        }, disabledIfNotGlobal) +
        "Service Location: <input type=text name=videoLocation value=\"" + rwc_htmlescape(profile.video.location) + '\"' + disabledIfNotGlobal + '>' +
        get_default_restart('video_data', function (profile) {
            var videoSize = profile.video.size;
            if (!videoSize || videoSize <= 0) {
                videoSize = 230400;	// 640x360
            }
            $('select[name=videoSize]').val(videoSize);
            var videoRate = profile.video.rate;
            if (videoRate <= 0) {
                videoRate = 30;
            }
            $('select[name=videoRate]').val(videoRate);
            var videoData = profile.video.data;
            if (videoData <= 0) {
                videoData = 256;
            }
            $('select[name=videoData]').val(videoData);
        }, disabledIfNotGlobal) +
        "Frame size: <select name=videoSize" + disabledIfNotGlobal + '>';
    var videoSize = profile.video.size;
    if (!videoSize || videoSize <= 0) {
        videoSize = 230400;	// 640x360
    }
    var VideoSizeOptions = [
        { name: "128x96 4:3 SQCIF", pels: 12288 },
        { name: "160x90 16:9", pels: 14400 },
        { name: "160x100 8:5", pels: 16000 },
        { name: "160x120 4:3 QQVGA", pels: 19200 },
        { name: "176x144 5:4 QCIF", pels: 25344 },
        { name: "320x180 16:9", pels: 57600 },
        { name: "320x200 8:5 CGA", pels: 64000 },
        { name: "320x240 4:3 QVGA", pels: 76800 },
        { name: "352x288 5:4 CIF/VCD", pels: 101376 },
        { name: "432x240 16:9 WQVGA", pels: 103680 },
        { name: "640x360 16:9 nHD (default)", pels: 230400 },
        { name: "640x400 8:5", pels: 256000 },
        { name: "640x480 4:3 VGA/EDTV", pels: 307200 },
        { name: "768x480 8:5 WVGA DVD", pels: 368640 },
        { name: "800x448 16:9", pels: 358400 },
        { name: "800x500 8:5", pels: 400000 },
        { name: "800x600 4:3 SVGA", pels: 480000 },
        { name: "864x480 16:9", pels: 414720 },
        { name: "960x540 16:9 qHD", pels: 518400 },
        { name: "960x720 4:3 SMPTE", pels: 691200 },
        { name: "1280x720 16:9 HD 720p", pels: 921600 },
        { name: "1280x800 8:5 WXGA", pels: 1024000 },
        { name: "1280x1024 5:4 SXGA", pels: 1310720 },
        { name: "1600x900 16:9 HD+ 900p", pels: 1440000 },
        { name: "1600x1000 8:5", pels: 1600000 },
        { name: "1600x1200 4:3 UXGA", pels: 1920000 },
        { name: "1920x1080 16:9 FHD 1080p", pels: 2073600 }
    ];
    for (i = 0; i < VideoSizeOptions.length; i++) {
        html += "<option value=" + VideoSizeOptions[i].pels;
        if (VideoSizeOptions[i].pels === videoSize) {
            html += " selected";
        }
        html += '>' + VideoSizeOptions[i].name + "</option>";
    }
    html += "</select> rate: <select name=videoRate" + disabledIfNotGlobal + '>';
    var videoRate = profile.video.rate;
    if (videoRate <= 0) {
        videoRate = 30;
    }
    var VideoRateOptions = [1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 20, 24, 30, 50, 60];
    for (i = 0; i < VideoRateOptions.length; i++) {
        html += "<option";
        if (VideoRateOptions[i] === videoRate) {
            html += " selected";
        }
        html += '>' + VideoRateOptions[i] + "</option>";
    }
    html += "</select> data: <select name=videoData" + disabledIfNotGlobal + '>';
    var videoData = profile.video.data;
    if (videoData <= 0) {
        videoData = 256;
    }
    var VideoDataOptions = [16, 32, 64, 128, 192, 256, 384, 512, 768, 1024, 1536, 2048, 3072, 4096];
    for (i = 0; i < VideoDataOptions.length; i++) {
        html += "<option";
        if (VideoDataOptions[i] === videoData) {
            html += " selected";
        }
        html += '>' + VideoDataOptions[i] + "</option>";
    }
    html += "</select> kbps " +
        get_default_end();
    html += endTitle();



    html += getTitle('Web Chat/Presence', profrow++, openAll) +
        get_default_start('webConn', function (profile) {
            $('input[name=webConn]').prop("checked", profile.webConn);
        });
    html += "<label><input type=checkbox name=webConn" + checked_if(profile.webConn);
    html += "> Public availability (<i>see Profile help for security ramifications</i>)</label>" +
        get_default_end();
    html += endTitle();



    html += getTitle('Account Rights', profrow++, openAll) +
        get_default_start('ssoRights', function (profile) {
            $('input[name=ssoRights][value=' + profile.ssoRights + ']').prop("checked", true);
        });
    val = profile.ssoRights;
    radio_name = namedElements ? " name=ssoRights" : "";
    html += "Single-Sign-On Rights (OpenID/SAML2):&nbsp;" +
        "<label><input type=radio value=no" + radio_name + checked_if(val === 'no') + "> No</label> &nbsp; " +
        "<label><input type=radio value=access" + radio_name + checked_if(val === 'access') + "> Access</label> &nbsp; " +
        "<label><input type=radio value=create" + radio_name + checked_if(val === 'create') + "> Account Create</label>" +
        "<label><input type=radio value=global" + radio_name + checked_if(val === 'global') + "> Global Create</label>" +
        "<br/>" +
        get_default_restart('guestCreation', function (profile) {
            $('input[name=guestCreation]').prop("checked", profile.guestCreation);
            $('select[name=guestProfile]').val(profile.guestProfile);
        }) +
        "<label><input type=checkbox name=guestCreation" + checked_if(profile.guestCreation) + "> enable guest account creation using profile:</label> ";
    var anythingSelected = false;
    html += "<select id=guestProfile name=guestProfile size=1>";
    for (i = 0; i < profileNames.length; ++i) {
        html += "<option";
        if (!anythingSelected && profile.guestProfile === profileNames[i].name) {
            html += " selected";
            anythingSelected = true;
        }
        html += '>' + rwc_htmlescape(profileNames[i].name) + "</option>";
    }
    html += "</select>" +
        get_default_end();
    html += endTitle();



    html += getTitle('Password', profrow++, openAll) +
        get_default_start('passPolicy', function (profile) {
            $('select[name=passPolicy]').val(profile.passPolicy ? profile.passPolicy : "[default]");
        });
    html += "Policy: <select name=passPolicy>";
    var selectedPolicy = profile.passPolicy;
    anythingSelected = false;
    for (i = 0; i < passPolicies.length; ++i) {
        html += "<option";
        if (!anythingSelected) {
            if (!selectedPolicy && passPolicies[i] === "[default]") {
                html += " selected";
                anythingSelected = true;
            }
            else if (passPolicies[i] === selectedPolicy) {
                html += " selected";
                anythingSelected = true;
            }
        }
        html += '>' + rwc_htmlescape(passPolicies[i]) + "</option>";
    }
    if (selectedPolicy && !anythingSelected) {
        html += "<option disabled>--------</option><option selected>" + rwc_htmlescape(selectedPolicy) + "</option>";
    }
    html += "</select>" +
        get_default_restart('webPassResetDisable', function (profile) {
            $('input[name=webPassResetDisable]').prop("checked", profile.webPassResetDisable);
        }) +
        "<label><input type=checkbox name=webPassResetDisable" + checked_if(profile.webPassResetDisable);
    html += "> Disable web password reset access</label>" +
        get_default_end();
    html += endTitle();



    html += getTitle('Real-Time Text', profrow++, openAll) +
        get_default_start('allowLangViol', function (profile) {
            $('input[name=allowlangviol][value=' + rightToNumber(profile.allowLangViol.right) + ']').prop("checked", true);
        });
    val = profile.allowLangViol.right;
    radio_name = namedElements ? " name=allowlangviol" : "";
    html +=
        "Filter: " +
        "<label><input type=radio value=0" + radio_name + checked_if(val === "no") + "> Bidirectional</label> &nbsp; " +
        "<label><input type=radio value=1" + radio_name + checked_if(val === "send") + "> Receiving</label> &nbsp; " +
        "<label><input type=radio value=2" + radio_name + checked_if(val === "recv") + "> Sending</label> &nbsp; " +
        "<label><input type=radio value=3" + radio_name + checked_if(val === "sendrecv") + "> Bypass Filter</label>" +
        get_default_restart('language', function (profile) {
            $('select[name=language]').val(profile.language ? profile.language : 'en');
        }) +
        "Language: <select name=language>";
    let selected_language = profile.language;
    if (!selected_language) {
        selected_language = 'en';
    }
    anythingSelected = false;
    for (i = 0; i < languages.length; ++i) {
        html += "<option";
        if (!anythingSelected && languages[i].c === selected_language) {
            html += " selected";
            anythingSelected = true;
        }
        html += ' value="' + languages[i].c + '">' + rwc_htmlescape(languages[i].d) + ' (' + languages[i].c + ')</option>';
    }
    if (selected_language && !anythingSelected) {
        html += "<option disabled>--------</option><option selected>" + rwc_htmlescape(selected_language) + "</option>";
    }
    html += "</select>" +
        get_default_restart('languageTranslate', function (profile) {
            $('input[name=languageTranslate]').prop("checked", profile.languageTranslate);
        }) +
        "<label><input type=checkbox name=languageTranslate" + checked_if(profile.languageTranslate) + "> Enable language translation</label>" +
        get_default_end();
    html += endTitle();



    html += getTitle('Redirect', profrow++, openAll) +
        get_default_start('redirOffline', function (profile) {
            $('input[name=redirOffline]').val(profile.redirOffline);
        });
    html += "When offline: <input type=text name=redirOffline value=\"" + rwc_htmlescape(profile.redirOffline) + "\">" +
        get_default_restart('redirNoAns', function (profile) {
            $('input[name=redirNoAns]').val(profile.redirNoAns.target);
            $('input[name=redirNoAnsDelay]').val(profile.redirNoAns.delay);
        }) +
        "On no answer: <input type=text name=redirNoAns value=\"" + rwc_htmlescape(profile.redirNoAns.target) + "\"> <nobr>delay: <input type='number' min='0' max='999' name=redirNoAnsDelay maxlength=3 size=3 value=\"" + profile.redirNoAns.delay + "\"></nobr>" +
        get_default_restart('redirUncond', function (profile) {
            $('input[name=redirUncond]').val(profile.redirUncond);
        }) +
        "Unconditional: <input type=text name=redirUncond value=\"" + rwc_htmlescape(profile.redirUncond) + "\">" +
        get_default_end();
    html += endTitle();



    html += getTitle('Real-Time Communications', profrow++, openAll);
    radio_name = namedElements ? " name=sipDisabled" : "";
    html += get_default_start('sipDisabled', function (profile) {
        var val = profile.sipDisabled ? 1 : 0;
        $('input[name=sipDisabled][value=' + val + ']').prop("checked", true);
    }) +
        "Enable: " +
        "<label><input type=radio value=1" + radio_name + checked_if(profile.sipDisabled) + "> No</label> &nbsp; " +
        "<label><input type=radio value=0" + radio_name + checked_if(!profile.sipDisabled) + "> Yes</label>" +
        get_default_restart('enableSMS', function (profile) {
            $('input[name=enableSMS]').prop("checked", profile.enableSMS);
        }) +
        "<label><input type=checkbox id=enableSMS name=enableSMS" + checked_if(profile.enableSMS) + "> Enable SMS</label>";
    var sml_val = profile.sipMultiLogin;
    radio_name = namedElements ? " name=sipMultiLogin" : "";
    html +=
        get_default_restart('sipMultiLogin', function (profile) {
            var val = profile.sipMultiLogin;
            if (val === 'disconnect_first') val = 1;
            else if (val === 'reject_second') val = 2;
            else val = 0;   // 'yes'
            $('input[name=sipMultiLogin][value=' + val + ']').prop("checked", true);
        }) +
        "Multiple Log-In:&nbsp;" +
        "<label><input type=radio value=0" + radio_name + checked_if(sml_val === 'yes') + "> Yes</label> &nbsp; " +
        "<label><input type=radio value=1" + radio_name + checked_if(sml_val === 'disconnect_first') + "> No, disconnect first</label> &nbsp; " +
        "<label><input type=radio value=2" + radio_name + checked_if(sml_val === 'reject_second') + "> No, reject second</label>" +
        get_default_restart('stickyStatus', function (profile) {
            $('input[name=stickyStatus]').prop("checked", profile.stickyStatus);
        }) +
        "<label><input type=checkbox name=stickyStatus" + checked_if(profile.stickyStatus) + "> Enable ability to set Sticky Status</label>" +
        get_default_restart('maxChatSize', function (profile) {
            $('input[name=maxChatSize]').val(profile.maxChatSize);
        }) +
        "Maximum size of single chat message: <input type='number' min='0' max='65535' name=maxChatSize maxlength=5 size=5 value=\"" + profile.maxChatSize + "\">" +
        get_default_restart('maxContacts', function (profile) {
            $('input[name=maxContactWarn]').val(profile.maxContacts.warn);
            $('input[name=maxContactError]').val(profile.maxContacts.err);
        }) +
        "Maximum number of contacts to contact <nobr>before warning: <input type='number' min='2' max='999' name=maxContactWarn maxlength=3 size=3 value=\"" + profile.maxContacts.warn + "\"></nobr>,  <nobr>before error: <input type='number' min='2' max='999' name=maxContactError maxlength=3 size=3 value=\"" + profile.maxContacts.err + "\"></nobr>" +
        get_default_restart('clientWebLocation', function (profile) {
            $('input[name=weblocation]').val(profile.clientWebLocation);
        }) +
        "Client Web Resource Location:<br/><input type=text name=weblocation style='width: 90%; margin-left: 5%;' value=\"" + rwc_htmlescape(profile.clientWebLocation) + "\">" +
        get_default_restart('clientHelpLocation', function (profile) {
            $('input[name=helplocation]').val(profile.clientHelpLocation);
        }) +
        "Client Web Help Location:<br/><input type=text name=helplocation style='width: 90%; margin-left: 5%;' value=\"" + rwc_htmlescape(profile.clientHelpLocation) + "\">" +
        get_default_restart('userAgents', function (profile) {
            $('input[name=useragents]').val(profile.userAgents);
        }) +
        "Allowed User-Agents:<br/><input type=text name=useragents style='width: 90%; margin-left: 5%;' value=\"" + rwc_htmlescape(profile.userAgents) + "\">" +
        get_default_restart('remoteACL', function (profile) {
            $('input[name=remoteACL]').val(profile.remoteACL);
        }) +
        "Remote Access:<br/><input type=text name=remoteACL style='width: 90%; margin-left: 5%;' value=\"" + rwc_htmlescape(profile.remoteACL) + "\">" +
        get_default_restart('upgradeURL', function (profile) {
            $('input[name=upgradeurl]').val(profile.upgradeURL);
        }) +
        "Upgrade URL:<br/><input type=text name=upgradeurl style='width: 90%; margin-left: 5%;' value=\"" + rwc_htmlescape(profile.upgradeURL) + "\">" +
        get_default_restart('contactAlias', function (profile) {
            $('input[name=contactalias]').val(profile.contactAlias);
        }) +
        "Alias in Contact Directory:<br/><input type=text name=contactalias style='width: 90%; margin-left: 5%;' value=\"" + rwc_htmlescape(profile.contactAlias) + "\">" +
        get_default_restart('forcedContacts', function (profile) {
            $('input[name=forcedcontacts]').val(profile.forcedContacts ? profile.forcedContacts.contacts : "");
            $('input[name=forcedcontacts_ex]').prop("checked", profile.forcedContacts ? profile.forcedContacts.exclusive : false);
            $('input[name=forcedcontacts_ro]').prop("checked", profile.forcedContacts ? profile.forcedContacts.readOnly : false);
        }) +
        "Forced Contact Directories:<br/>" +
        "<input type=text name=forcedcontacts style='width: 90%; margin-left: 5%;' value=\"" + rwc_htmlescape(profile.forcedContacts ? profile.forcedContacts.contacts : "") + "\"><br/>" +
        "<div style='margin-left: 5%;'><label><input type=checkbox name=forcedcontacts_ex" + checked_if(profile.forcedContacts ? profile.forcedContacts.exclusive : false) + "> exclusive</label> &nbsp; " +
        "<label><input type=checkbox name=forcedcontacts_ro" + checked_if(profile.forcedContacts ? profile.forcedContacts.readOnly : false) + "> read-only properties</label></div>" +
        get_default_restart('statusMenu', function (profile) {
            $('input[name=statusmenu]').val(profile.statusMenu);
        }) +
        "Status Menu:<br/>" +
        "<input type=text name=statusmenu style='width: 90%; margin-left: 5%;' value=\"" + rwc_htmlescape(profile.statusMenu) + "\">" +
        get_default_restart('shortcutList', function (profile) {
            $('input[name=shortcutList]').val(profile.shortcutList);
        }) +
        "Shortcut List:<br/>" +
        "<input type=text name=shortcutList style='width: 90%; margin-left: 5%;' value=\"" + rwc_htmlescape(profile.shortcutList) + "\">" +
        get_default_restart('timeZoneName', function (profile) {
            $('select[name=tzName]').val(profile.timeZoneName ? profile.timeZoneName : timezoneInfo.server_zone);
        }) +
        "Time Zone: <select name=tzName>";
    val = profile.timeZoneName ? profile.timeZoneName : timezoneInfo.server_zone;
    for (i = 0; i < timezoneInfo.names.length; ++i) {
        html += "<option";
        if (val === timezoneInfo.names[i]) {
            html += " selected";
        }
        html += '>' + rwc_htmlescape(timezoneInfo.names[i]) + "</option>";
    }
    html += "</select>";
    // the array has static tool names that are set in the Profile::ClientTools constructor
	// and must match this list of tools
    var client_tools = [
        { title: "Emoticons", name: "emoticons" },
        { title: "File Transfer", name: "ftp" },
        { title: "Shortcuts", name: "shortcuts" },
        { title: "Transfers", name: "transfers" },
        { title: "Voice", name: "voice" },
        { title: "Push-to-Talk", name: "ptt" },
        { title: "Desktop Sharing", name: "rds" },
        { title: "Video", name: "video" },
        { title: "Markup", name: "markup" },
        { title: "Keypad", name: "keypad" },
        { title: "Chat", name: "chat" }
    ];
    html += get_default_restart('clientTools', function (profile) {
        for (var i = 0; i < client_tools.length; ++i) {
            var pi = 'enable';
            if (typeof profile.clientTools === 'object') {
                pi = profile.clientTools[client_tools[i].name];
            }
            $('select[name=ct_' + client_tools[i].name + ']').val(typeof pi === 'string' ? pi : 'enable');
        }
        }) +
        "Client Tools:<br/><div style='width: 90%; margin-left: 5%;'>";
    function ct_selected(name,state) {
        if (typeof profile.clientTools === 'object') {
            var pi = profile.clientTools[name];
            if (typeof pi === 'string' && pi === state) {
                return " selected";
            }
        }
        return "";
    }
    for (var i = 0; i < client_tools.length; ++i) {
        var name = client_tools[i].name;
        html += "<span style='white-space: nowrap; padding-right: 2em;'>" + client_tools[i].title + " <select name=ct_" + name + "><option" + ct_selected(name, 'enable') + ">enable</option><option" + ct_selected(name, 'disable') + ">disable</option><option" + ct_selected(name, 'hide') +">hide</option></select></span>";
    }
    html += "</div>" + get_default_restart('applications', function (profile) {
        var lis = $('#applications>li');
        for (var i = 0; i < lis.length - 1; ++i) {
            $(lis[i]).remove();
        }
        profileApplications.init(profile.applications);
    }) +
        "Applications:<br/><input type=hidden name=applications_max id=applications_max value=0/>" +
        "<ul id=applications name=applications style='width: 90%; list-style-type: none; padding: 0; margin-left: 5%; margin-bottom: 0;'>" +
        "<li><input type=button class='btn btn-secondary btn-sm' value='&#x271a;' onclick='profileApplications.add();return false;'/> add new application</li>" +
        "</ul>" +
        get_default_end();
    html += endTitle();



    function radio_named(name) {
        return namedElements ? ' name=' + name : '';
    }

    function colored_disabled(b) {
        return b ? ' disabled=disabled style="background-color: #d3d3d3; "' : '';
    }

    html += getTitle('Account Features', profrow++, openAll) +
        get_default_start('webmailDisabled', function (profile) {
            var val = profile.webmailDisabled ? 1 : 0;
            $('input[name=webmailDisabled][value=' + val + ']').prop("checked", true);
        }) +
        "Access to Mail Folders:&nbsp;" +
        "<label><input type=radio value=1" + radio_named('webmailDisabled') + checked_if(profile.webmailDisabled) + "> No</label> &nbsp; " +
        "<label><input type=radio value=0" + radio_named('webmailDisabled') + checked_if(!profile.webmailDisabled) + "> Yes</label>" +
        get_default_restart('sessionLogView', function (profile) {
            $('input[name=sessionLogView]').prop("checked", profile.sessionLogView);
        }) +
        "<label><input type=checkbox name=sessionLogView" + checked_if(profile.sessionLogView) + "> Allow access to Session logs</label>" +
        get_default_restart('optionsDisabled', function (profile) {
            $('input[name=optionsDisabled]').prop("checked", profile.optionsDisabled);
        }) +
        "<label><input type=checkbox id=optionsDisabled name=optionsDisabled" + checked_if(profile.optionsDisabled) + "> Disable access to Options</label>" +
        get_default_restart('eFolderCreation', function (profile) {
            $('input[name=eFolderCreation]').prop("checked", profile.eFolderCreation);
        }) +
        "<label><input type=checkbox id=eFolderCreation name=eFolderCreation onchange=\"eFolderSharingChanged();\"" + checked_if(profile.eFolderCreation) + "> Allow creation of eFolders</label>" +
        get_default_restart('eFolderProfileSharing', function (profile) {
            $('input[name=eFolderProfileSharing]').prop("checked", profile.eFolderProfileSharing);
        }) +
        "<label><input type=checkbox id=eFolderProfileSharing name=eFolderProfileSharing" + checked_if(profile.eFolderProfileSharing) + colored_disabled(!profile.eFolderCreation) + "> Allow eFolder owners to associate with profiles</label>" +
        get_default_restart('webShowInAutoList', function (profile) {
            $('input[name=webShowInAutoList]').prop("checked", profile.webShowInAutoList);
        }) +
        "<label><input type=checkbox name=webShowInAutoList" + checked_if(profile.webShowInAutoList) + "> Show account in auto-populate target lists</label>" +
        get_default_restart('logDelete', function (profile) {
            $('input[name=noLogDelete][value=' + profile.noLogDelete + ']').prop("checked", true);
        }) +
        "Log delete ability:&nbsp;" +
        "<label><input type=radio value=0" + radio_named('noLogDelete') + checked_if(profile.noLogDelete === 0) + "> Any</label> &nbsp; " +
        "<label><input type=radio value=1" + radio_named('noLogDelete') + checked_if(profile.noLogDelete === 1) + "> None</label> &nbsp; " +
        "<label><input type=radio value=2" + radio_named('noLogDelete') + checked_if(profile.noLogDelete === 2) + "> Not from Trash</label>" +
        get_default_restart('calendarOwnership', function (profile) {
            $('input[name=calendarOwnership]').prop("checked", profile.calendarOwnership);
        }) +
        "<label><input type=checkbox id=calendarOwnership name=calendarOwnership onchange=\"calendarOwnershipChanged();\"" + checked_if(profile.calendarOwnership) + "> Allow calendar ownership</label>" +
        get_default_restart('calendarProfileAssociation', function (profile) {
            $('input[name=calendarProfileAssociation]').prop("checked", profile.calendarProfileAssociation);
        }) +
        "<label><input type=checkbox id=calendarProfileAssociation name=calendarProfileAssociation" + checked_if(profile.calendarProfileAssociation) + colored_disabled(!profile.calendarOwnership) + "> Allow owned calendars to be automatically associated with profiles</label>" +
        get_default_restart('enableMMP', function (profile) {
            $('input[name=enableMMP]').prop("checked", profile.enableMMP);
        }) +
        "<label><input type=checkbox id=enableMMP name=enableMMP" + checked_if(profile.enableMMP) + "> Allow access to MMP</label>" +
        get_default_restart('enableMobileApp', function (profile) {
            $('input[name=enableMobileApp]').prop("checked", profile.enableMobileApp);
        }) +
        "<label><input type=checkbox id=enableMobileApp name=enableMobileApp" + checked_if(profile.enableMobileApp) + "> Allow access to Mobile Worker</label>" +
        get_default_restart('enableKW', function (profile) {
            $('input[name=enableKW]').prop("checked", profile.enableKW);
        }) +
        "<label><input type=checkbox id=enableKW name=enableKW" + checked_if(profile.enableKW) + "> Allow access to Knowledge Worker</label>" +
        get_default_restart('enableWFM', function (profile) {
            $('input[name=enableWFM]').prop("checked", profile.enableWFM);
        }) +
        "<label><input type=checkbox id=enableWFM name=enableWFM" + checked_if(profile.enableWFM) + "> Allow access to Workforce Management</label>" +
        get_default_end();
    html += endTitle();




    html += getTitle('Email', profrow++, openAll) +
        get_default_start('smtpDisabled', function (profile) {
            var val = profile.smtpDisabled ? 1 : 0;
            $('input[name=smtpDisabled][value=' + val + ']').prop("checked", true);
        }) +
        "Enable SMTP sending: " +
        "<label><input type=radio value=1" + radio_named('smtpDisabled') + checked_if(profile.smtpDisabled) + "> No</label> &nbsp; " +
        "<label><input type=radio value=0" + radio_named('smtpDisabled') + checked_if(!profile.smtpDisabled) + "> Yes</label>" +
        get_default_restart('imapDisabled', function (profile) {
            var val = profile.imapDisabled ? 1 : 0;
            $('input[name=imapDisabled][value=' + val + ']').prop("checked", true);
        }) +
        "Enable IMAP4/POP3 receiving: " +
        "<label><input type=radio value=1" + radio_named('imapDisabled') + checked_if(profile.imapDisabled) + "> No</label> &nbsp; " +
        "<label><input type=radio value=0" + radio_named('imapDisabled') + checked_if(!profile.imapDisabled) + "> Yes</label>" +
        get_default_restart('mailDelivery', function (profile) {
            $('input[name=mailibox]').prop("checked", !profile.mailSkipInbox);
            $('input[name=mailxsvr]').prop("checked", profile.mailForwardExt);
        }) +
        "Deliver secure mail to: " +
        "<label><input type=checkbox name=mailibox" + checked_if(!profile.mailSkipInbox) + "> Secure Inbox</label> &nbsp; " +
        "<label><input type=checkbox name=mailxsvr" + checked_if(profile.mailForwardExt) + "> External Server</label>" +
        get_default_restart('voiceMailSeparate', function (profile) {
            $('input[name=vmsep]').prop("checked", profile.voiceMailSeparate);
        }) +
        "<label><input type=checkbox name=vmsep" + checked_if(profile.voiceMailSeparate) + "> Deliver voicemails to a Voicemail folder instead of the Inbox</label>" +
        get_default_restart('chatsCallsSeparate', function (profile) {
            $('input[name=chatcallsep]').prop("checked", profile.chatsCallsSeparate);
        }) +
        "<label><input type=checkbox name=chatcallsep" + checked_if(profile.chatsCallsSeparate) + "> Deliver sessions to Chats and Calls folders instead of Sessions</label>" +
        get_default_restart('relayRights', function (profile) {
            var val = profile.relayRights.type;
            if (val === "sendermatch") val = 1;
            else if (val === "any") val = 2;
            else val = 0;   // "prohibited"
            $('input[name=relay][value=' + val + ']').prop("checked", true);
        }) +
        "Email Relaying:&nbsp;" +
        "<label><input type=radio value=0" + radio_named('relay') + checked_if(profile.relayRights.type === "prohibited") + "> Prohibited</label> &nbsp; " +
        "<label><input type=radio value=1" + radio_named('relay') + checked_if(profile.relayRights.type === "sendermatch") + "> Sender-Must-Match</label> &nbsp; " +
        "<label><input type=radio value=2" + radio_named('relay') + checked_if(profile.relayRights.type === "any") + "> Any</label>" +
        get_default_restart('mailRestrictFrom', function (profile) {
            $('input[name=relayrest]').val(profile.relayRights.relayRestriction);
        }) +
        "Email Relaying: &nbsp; restrict From: <input type=text name=relayrest value=\"" + rwc_htmlescape(profile.relayRights.relayRestriction) + "\">" +
        get_default_restart('mailRestrictTo', function (profile) {
            $('input[name=mailRestrictTo]').val(profile.mailRestrictTo);
        }) +
        "Email Targets: &nbsp; restrict To: <input type=text name=mailRestrictTo value=\"" + rwc_htmlescape(profile.mailRestrictTo) + "\">" +
        get_default_end();
    html += endTitle();



    html += getTitle('Voice Services', profrow++, openAll);
    radio_name = namedElements ? " name=voiceDisabled" : "";
    html += get_default_start('voiceDisabled', function (profile) {
            var val = profile.voice.right === "no" ? 1 : 0;
            $('input[name=voiceDisabled][value=' + val + ']').prop("checked", true);
        }) +
        "Enable: " +
        "<label><input type=radio value=1" + radio_name + checked_if(profile.voice.right === "no") + "> No</label> &nbsp; " +
        "<label><input type=radio value=0" + radio_name + checked_if(profile.voice.right === "sendrecv") + "> Yes</label>"+
        get_default_restart('voiceUserAgents', function (profile) {
            $('input[name=voiceUserAgents]').val(profile.voice.userAgents);
        }) +
        "Disable specific User-Agents:<br/><input type=text name=voiceUserAgents style='width: 90%; margin-left: 5%;' value=\"" + rwc_htmlescape(profile.voice.userAgents) + "\">" +
        get_default_restart('voiceLogging', function (profile) {
            $('input[name=voicelog]').prop("checked", profile.voice.logged);
        }) +
        "<label><input type=checkbox name=voicelog" + checked_if(profile.voice.logged) + "> Auto-start logging of voice conferences (<i>can be very large</i>)</label>" +
        get_default_restart('voiceLogMod', function (profile) {
            $('input[name=voiceLogMod][value=' + profile.voice.logmod + ']').prop("checked", true);
        });
    radio_name = namedElements ? " name=voiceLogMod" : "";
    html += "User can see/control voice logging: " +
        "<label><input type=radio value=no" + radio_name + checked_if(profile.voice.logmod === "no") + "> No</label> &nbsp; " +
        "<label><input type=radio value=can_view" + radio_name + checked_if(profile.voice.logmod === "can_view") + "> Can View</label> &nbsp; " +
        "<label><input type=radio value=can_control" + radio_name + checked_if(profile.voice.logmod === "can_control") + "> Can View and Control</label>" +
        get_default_restart('voiceLogAccess', function (profile) {
            $('input[name=voiceLogAccess]').prop("checked", profile.voice.logaccess);
        }) +
        "<label><input type=checkbox name=voiceLogAccess" + checked_if(profile.voice.logaccess) + "> Allow user to access their voice logs</label>"+
        get_default_restart('voiceMailPinAccess', function (profile) {
            $('input[name=voiceMailPinAccess]').prop("checked", profile.voiceMailPinAccess);
        }) +
        "<label><input type=checkbox name=voiceMailPinAccess" + checked_if(profile.voiceMailPinAccess) + "> Voicemail access via a PIN</label>"+
        get_default_restart('aVoice', function (profile) {
            $('input[name=aVoice]').prop("checked", profile.aVoice);
        }) +
        "<label><input type=checkbox name=aVoice" + checked_if(profile.aVoice) + "> Allow advanced voice services</label>"+
        get_default_restart('dtmfSearchable', function (profile) {
            $('input[name=dtmfSearchable]').prop("checked", !profile.dtmfSearchDisabled);
        }) +
        "<label><input type=checkbox name=dtmfSearchable" + checked_if(!profile.dtmfSearchDisabled) + "> User returned in search-by-DTMF queries</label>"+
        get_default_restart('voiceLocation', function (profile) {
            $('input[name=voiceLocation]').val(profile.voice.location);
        }, disabledIfNotGlobal) +
        "Service Location: <input type=text name=voiceLocation value=\"" + rwc_htmlescape(profile.voice.location) + '\"' + disabledIfNotGlobal + '>'+
        get_default_restart('voiceData', function (profile) {
            var voiceData = profile.voice.data;
            if (voiceData <= 0) {
                voiceData = 64;
            }
            $('select[name=voiceData]').val(voiceData);
        }, disabledIfNotGlobal) +
        "Data Rate: <select name=voiceData" + disabledIfNotGlobal + '>';
    var voiceData = profile.voice.data;
    if (voiceData <= 0) {
        voiceData = 64;
    }
    var VoiceDataOptions = [8, 12, 16, 24, 32, 48, 64, 96, 128, 192, 256, 0];
    for (i = 0; i < VoiceDataOptions.length; i++) {
        html += "<option";
        if (VoiceDataOptions[i] === voiceData) {
            html += " selected";
        }
        html += '>' + VoiceDataOptions[i] + "</option>";
    }
    html += "</select> kbps " +
        get_default_restart('callerID', function (profile) {
            $('input[name=callerID]').val(profile.callerID);
        }) +
        "Caller ID: <input type=text name=callerID maxlength=16 size=16 pattern='[0-9]{0,16}?' title='caller phone number, numbers only' value=\"" + rwc_htmlescape(profile.callerID) + "\">" + important_info("CallerID") +
        get_default_restart('callerID911', function (profile) {
            $('input[name=callerID911]').val(profile.callerID911);
        }) +
        "Caller ID 911: <input type=text name=callerID911 maxlength=16 size=16 pattern='[0-9]{0,16}?' title='caller emergency phone number, numbers only' value=\"" + rwc_htmlescape(profile.callerID911) + '\"' + (ar_e911clid ? "" : " disabled=disabled") + '>' + important_info("CallerID") +
        get_default_restart('dialPlan', function (profile) {
            $('input[name=dialPlan]').val(profile.dialPlan);
        }) +
        "Dial Plan: <input type=text name=dialPlan value=\"" + rwc_htmlescape(profile.dialPlan) + "\">" +
        get_default_restart('dialPlanMobile', function (profile) {
            $('input[name=dialPlanMobile]').val(profile.dialPlanMobile);
        }) +
        "Dial Plan Mobile: <input type=text name=dialPlanMobile value=\"" + rwc_htmlescape(profile.dialPlanMobile) + "\">" +
        get_default_restart('mapIncoming', function (profile) {
            $('input[name=mapIncoming]').val(profile.mapIncoming.map);
            $('input[name=mapIncomingRNM]').prop("checked", profile.mapIncoming.rejectNoMatch);
        }) +
        "Incoming Digit Map: <input type=text name=mapIncoming value=\"" + rwc_htmlescape(profile.mapIncoming.map) + "\">" +
        "<label><input type=checkbox name=mapIncomingRNM" + checked_if(profile.mapIncoming.rejectNoMatch) + "> reject calls if no match</label>" +
        get_default_restart('mapOutgoing', function (profile) {
            $('input[name=mapOutgoing]').val(profile.mapOutgoing);
        }) +
        "Outgoing Digit Map: <input type=text name=mapOutgoing value=\"" + rwc_htmlescape(profile.mapOutgoing) + "\">" +
        get_default_restart('mohURI', function (profile) {
            $('input[name=mohURI]').val(profile.mohURI);
        }) +
        "Music On Hold URI: <input type=text name=mohURI value=\"" + rwc_htmlescape(profile.mohURI) + "\">" +
        get_default_restart('callParkURI', function (profile) {
            $('input[name=callParkURI]').val(profile.callParkURI);
        }) +
        "Call Park URI: <input type=text name=callParkURI value=\"" + rwc_htmlescape(profile.callParkURI) + "\">" +
        get_default_end();
    html += endTitle();



    html += getTitle('Compliance', profrow++, openAll);
    html +=
        get_default_start('daysRetainChats', function (profile) {
            $('input[name=daysRetainChats]').val(profile.daysRetainChats);
        }) +
        "Days to Retain Chat Logs: <input type='number' min='0' max='65535' name=daysRetainChats maxlength=5 size=5 value=\"" + profile.daysRetainChats + "\">" +
        get_default_restart('daysRetainCalls', function (profile) {
            $('input[name=daysRetainCalls]').val(profile.daysRetainCalls);
        }) +
        "Days to Retain Call Logs: <input type='number' min='0' max='65535' name=daysRetainCalls maxlength=5 size=5 value=\"" + profile.daysRetainCalls + "\">" +
        get_default_restart('daysRetainVoicemails', function (profile) {
            $('input[name=daysRetainVoicemails]').val(profile.daysRetainVoicemails);
        }) +
        "Days to Retain Voicemail Logs: <input type='number' min='0' max='65535' name=daysRetainVoicemails maxlength=5 size=5 value=\"" + profile.daysRetainVoicemails + "\">" +
        get_default_restart('daysRetainMailItems', function (profile) {
            $('input[name=daysRetainMailItems]').val(profile.daysRetainMailItems);
        }) +
        "Days to Retain Mail Items: <input type='number' min='0' max='65535' name=daysRetainMailItems maxlength=5 size=5 value=\"" + profile.daysRetainMailItems + "\">" +
        get_default_restart('recordingCompliance', function (profile) {
            $('input[name=recordingComplianceURLs]').val(profile.recordingCompliance.urls);
            $('input[name=recordingCompliancePauseIfActiveOnly]').prop("checked", profile.recordingCompliance.pauseIfActiveOnly);
        }) +
        "Recording Restricted URLs:<br/><input type=text name=recordingComplianceURLs style='width: 90%; margin-left: 5%;' value=\"" + rwc_htmlescape(profile.recordingCompliance.urls) + "\">"+
        "<br/>" +
        "<label><input type=checkbox name=recordingCompliancePauseIfActiveOnly" + checked_if(profile.recordingCompliance.pauseIfActiveOnly) + "> Pause Recording if Active Only</label>" +
        get_default_end();
    html += endTitle();



    document.write(html);

    if (doInit) {
        profileApplications.init(profile.applications);
        profile_table_init(profile.defaults, profileDefault !== null, isNewProfile);
    }
}
