<?php
$revation->config('ldap');

include 'tableTop.php';
include 'groupPre.php';
echo 'LDAP Configuration';
include 'groupStart.php';

if($revation->adminGlobal()){
  echo'Please select a private group to edit LDAP settings.';
  include 'groupEnd.php';
  include 'tableBottom.php';
  exit();
}
$urlTokenArg=$revation->getUrlTokenArg();
?>

<form method='post' name='f' action='embed.php?<?=$urlTokenArg?>'><input type='hidden' name='php' value='LdapConfig' autocomplete='off'/>
<?php
	include 'groupPre.php';
	echo $title;
?>
<a href='#' alt='help on this' class='btn btn-info btn-sm rev-help' onclick="window.open('Help/Ldap.html','help','width=400,height=400,scrollbars=yes','alwaysRaised')">&#x1f6c8; Help on this</a>
<?php include 'groupStart.php';?>
<table>
		<tr><td><label for='enabled'>Enable LDAP:</label></td><td>
				<?="<input type='checkbox' id='enabled' name='enabled' {$revChecked['enabled']} /> {$revChanged['enabled']}"?>
		</td><td>current queue size: <?=htmlspecialchars($_REQUEST['queueSize'])?></td></tr>
		<tr><td>LDAP Domain Name:</td><td>
				<?php echo "<input type='text' name='domain' maxlength='256' size='30' value='".htmlspecialchars($_REQUEST['domain'])."' /> {$revChanged['domain']}";?>
		</td><td style='font-size: small;'>e.g. COMPANY</td></tr>
		<tr><td>LDAP Server Name:</td><td>
				<?php echo "<input type='text' name='server' maxlength='256' size='30' value='".htmlspecialchars($_REQUEST['server'])."' /> {$revChanged['server']}";?>
		</td><td style='font-size: small;'>e.g. ldap.company.com</td></tr>
		<tr><td>LDAP Server Port:</td><td>
				<?php echo "<input type='number' min='1' max='65535' name='port' maxlength='5' size='30' value='".htmlspecialchars($_REQUEST['port'])."' /> {$revChanged['port']}";?>
		</td><td style='font-size: small;'>e.g. 389 (TCP), or 636 or 3269 (SSL)</td></tr>
		<tr><td><label for='ssl'>Encrypted Connection:</label></td><td>
				<?="<input type='checkbox' id='ssl' name='ssl' {$revChecked['ssl']} /> {$revChanged['ssl']}"?>
		</td><td></td></tr>
		<tr><td><label for='nocheck'>Bypass Certificate Check:</label></td><td>
				<?="<input type='checkbox' id='nocheck' name='nocheck' {$revChecked['nocheck']} /> {$revChanged['nocheck']}"?>
		</td><td></td></tr>
		<tr><td>LDAP Distinguished Name:</td><td>
				<?php echo "<input type='text' name='dn' maxlength='256' size='30' value='".htmlspecialchars($_REQUEST['dn'])."' /> {$revChanged['dn']}";?>
		</td><td style='font-size: small;'>e.g. OU=Users,DC=company,DC=com</td></tr>
		<tr><td><label for='simple'>Use SIMPLE binding:</label></td><td>
				<?="<input type='checkbox' id='simple' name='simple' {$revChecked['simple']} /> {$revChanged['simple']}"?>
		</td><td style='font-size: small;'>warning! using simple binding without encryption<br/>will cause passwords to the LDAP server to be in the clear!</td></tr>
		<tr><td>Membership:</td><td>
				<?php echo "<input type='text' name='mo' maxlength='1024' size='30' value='".htmlspecialchars($_REQUEST['mo'])."' /> {$revChanged['mo']}";?>
		</td><td style='font-size: small;'>e.g. OU=RevationUsers</td></tr>
		<tr><td><label for='subtree'>Enable Sub-Tree Lookups:</label></td><td>
				<?="<input type='checkbox' id='subtree' name='subtree' {$revChecked['subtree']} /> {$revChanged['subtree']}"?>
		</td><td></td></tr>
		<tr><td>LDAP Username:</td><td>
				<?php echo "<input type='text' name='user' maxlength='256' size='30' value='".htmlspecialchars($_REQUEST['user'])."' autocomplete='off' /> {$revChanged['user']}";?>
		</td><td style='font-size: small;'>used for account searching features</td></tr>
		<tr><td>LDAP Password:</td><td>
				<?="<input type='password' name='pass' maxlength='256' size='30' value='__pass' autocomplete='off' /> {$revChanged['pass']}"?>
		</td></tr>
		<tr><td colspan='3'>&nbsp;</td></tr>
		<tr><td colspan='3' align='center'>
		<input type='submit' name='apply' value='Apply' class='btn btn-secondary btn-sm' />&nbsp;
		<input type='submit' name='cancel' value='Cancel' class='btn btn-secondary btn-sm' />&nbsp;
		<?php
			if($_SERVER['OS']=='WINDOWS'){
				echo"<input type='button' value='Connectivity Test' class='btn btn-secondary btn-sm' onclick=\"window.location='embed.php?doc=LdapTest.html&"+$urlTokenArg+"'\" "+$revDisabledIfNot['enabled']+" />&nbsp;";
			}
		?>
		<input type='button' value='Logon Test' class='btn btn-secondary btn-sm' onclick="window.location='embed.php?doc=LdapTest.html&<?=$urlTokenArg?>&logon'" <?=$revDisabledIfNot['enabled']?> />&nbsp;
		<input type='button' value='&#x21e6; Back' class='btn btn-dark btn-sm' onclick="window.location='embed.php?php=Tools&<?=$urlTokenArg?>'" />
		</td></tr>
</table>

<?php
	include 'groupEnd.php';
	include 'groupPre.php';
	echo 'LDAP Scheme';
	include 'groupStart.php';
?>

<table>
		<tr><td>Account:</td><td>
				<?php echo "<input type='text' name='scheme_account' maxlength='128' size='30' value='".htmlspecialchars($_REQUEST['scheme_account'])."' /> {$revChanged['scheme_account']}";?>
		</td><td style='font-size: small;'>required, e.g. sAMAccountName</td></tr>
		<tr><td>Email Primary:</td><td>
				<?php echo "<input type='text' name='scheme_email' maxlength='128' size='30' value='".htmlspecialchars($_REQUEST['scheme_email'])."' /> {$revChanged['scheme_email']}";?>
		</td><td style='font-size: small;'>required, e.g. mail</td></tr>
		<tr><td>Email Secondary:</td><td>
				<?php echo "<input type='text' name='scheme_upn' maxlength='128' size='30' value='".htmlspecialchars($_REQUEST['scheme_upn'])."' /> {$revChanged['scheme_upn']}";?>
		</td><td style='font-size: small;'>optional, e.g. userPrincipalName</td></tr>
		<tr><td>Membership:</td><td>
				<?php echo "<input type='text' name='scheme_memberof' maxlength='128' size='30' value='".htmlspecialchars($_REQUEST['scheme_memberof'])."' /> {$revChanged['scheme_memberof']}";?>
		</td><td style='font-size: small;'>optional (but required for to match profiles other than default), e.g. memberOf</td></tr>
		<tr><td>First Name:</td><td>
				<?php echo "<input type='text' name='scheme_firstname' maxlength='128' size='30' value='".htmlspecialchars($_REQUEST['scheme_firstname'])."' /> {$revChanged['scheme_firstname']}";?>
		</td><td style='font-size: small;'>optional (but required to allow name searches and name population in account), e.g. givenName</td></tr>
		<tr><td>Last Name:</td><td>
				<?php echo "<input type='text' name='scheme_lastname' maxlength='128' size='30' value='".htmlspecialchars($_REQUEST['scheme_lastname'])."' /> {$revChanged['scheme_lastname']}";?>
		</td><td style='font-size: small;'>optional (but required to allow name searches and name population in account), e.g. sn</td></tr>
		<tr><td>Telephone:</td><td>
				<?php echo "<input type='text' name='scheme_telephone' maxlength='128' size='30' value='".htmlspecialchars($_REQUEST['scheme_telephone'])."' /> {$revChanged['scheme_telephone']}";?>
		</td><td style='font-size: small;'>optional (but required for integration with phone networks), e.g. telephoneNumber</td></tr>
		<tr><td colspan='3'>&nbsp;</td></tr>
		<tr><td colspan='3' align='center'>
		<input type='submit' name='apply' value='Apply' class='btn btn-secondary btn-sm' />&nbsp;
		<input type='submit' name='cancel' value='Cancel' class='btn btn-secondary btn-sm' />&nbsp;
		<input type='button' value='&#x21e6; Back' class='btn btn-dark btn-sm' onclick="window.location='embed.php?php=Tools&<?=$urlTokenArg?>'" />
		</td></tr>
</table>

<?php include 'groupEnd.php';?>

</form>

<form method='post' name='f' action='embed.php?doc=LdapTest.html&<?=$urlTokenArg?>' autocomplete='off'>
<?php
	include 'groupPre.php';
	echo 'Client Logon Test';
	include 'groupStart.php';
?>
<table>
		<tr><td>Presence ID:</td><td>
				<input type='text' name='pid' maxlength='80' size='30' autocomplete='off' />, and/or:
		</td></tr>
		<tr><td>Account:</td><td>
				<input type='text' name='user' maxlength='80' size='30' autocomplete='off' />, and
		</td></tr>
		<tr><td>Password:</td><td>
				<input type='password' name='pass' maxlength='80' size='30' autocomplete='off' />
		</td></tr>
		<tr><td colspan='2'>&nbsp;</td></tr>
		<tr><td colspan='2' align='center'>
			<input type='submit' value='Logon Test' class='btn btn-secondary btn-sm' <?=$revDisabledIfNot['enabled']?> />
			&nbsp;
			<input type='button' value='&#x21e6; Back' class='btn btn-dark btn-sm' onclick="window.location='embed.php?php=Tools&<?=$urlTokenArg?>'" />
		</td></tr>
</table>
<?php include 'groupEnd.php';?>
</form>

<?php include 'tableBottom.php';?>