<?php
if(strpos($_REQUEST['callback'],'..')||strcspn($_REQUEST['callback'],'><:/&,?%*"\'\\')<strlen($_REQUEST['callback']))
	unset($_REQUEST['callback']);
if($_REQUEST['callback']){
    header('Content-Type: text/javascript');
    echo $_REQUEST['callback'].'(';
}
else{
    header('Content-Type: application/json');
}
echo '{';

if($_REQUEST['cmd']=='auth'||$_REQUEST['cmd']=='login'){
    echo'"results":"';
    if(isset($_REQUEST['pswd']))
        echo $revation->adminLogon($_REQUEST['user'],$_REQUEST['pswd']);
    else
        echo'LOGIN_FAILED';
    echo'"';
    if(isset($_SESSION)){
        echo',"groups":'.$revation->adminGroupOptions().
			',"display":'.json_encode($revation->adminDisplay()).
			',"rights":'.$revation->adminRights().
			','.$revation->getUrlTokenJson();
		if($_REQUEST['cmd']=='auth')
			$revation->adminLogout();
	}
}
else if($_REQUEST['cmd']=='logout'){
    if(isset($_SESSION)){
        $revation->adminLogout();
        echo'"results":"OKAY"';
    }
    else{
        echo'"results":"INVALID"';
    }
}
else if(isset($_SESSION)){
    echo'"groups":'.$revation->adminGroupOptions().
		',"display":'.json_encode($revation->adminDisplay()).
		',"rights":'.$revation->adminRights().
		','.$revation->getUrlTokenJson();
}
else{
	echo'"results":"INVALID"';
}

echo'}';
if($_REQUEST['callback']){
    echo');';
}
?>