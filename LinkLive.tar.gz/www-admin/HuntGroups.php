<?php
if(strpos($_REQUEST['callback'],'..')||strcspn($_REQUEST['callback'],'><:/&,?%*"\'\\')<strlen($_REQUEST['callback']))
	unset($_REQUEST['callback']);
if($_REQUEST['callback']){
    header('Content-Type: text/javascript');
    echo $_REQUEST['callback'].'(';
}
else{
    header('Content-Type: application/json');
}
if(!isset($_SESSION)){
	$revation->adminLogon($_REQUEST['admin'],$_REQUEST['pswd']);
	if($revation->adminGlobal()){
		$_REQUEST['groupselect']=$_REQUEST['group'];
		$revation->adminGlobalGroupSelect();
	}
}
echo $revation->huntGroups($_REQUEST['huntgroup']);
if($_REQUEST['callback']){
    echo');';
}
$revation->adminLogout();
?>