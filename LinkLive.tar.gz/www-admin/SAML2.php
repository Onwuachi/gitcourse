<?php
include 'tableTop.php';
include 'groupPre.php';
echo 'SAML2 Metadata for ';
if($revation->adminGlobal())
	echo"Global Groups";
else
	echo$revation->adminGroup();
include 'groupStart.php';
$urlTokenArg=$revation->getUrlTokenArg();
?>

<script type="text/javascript">
//<![CDATA[

function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
        results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

var SAML2 = {
	type: getParameterByName('type') === 'administrators' ? 'administrators' : 'users',

	loadMetadata: function() {
		$('#type').val(this.type);

		$.ajax({
			type: 'GET',
			url: 'json/saml2/metadata?type=' + this.type + '&'+getUrlTokenArg(),
			async: true,
			cache: false,
			success: function (json) {
				if(typeof json==='object' && json.results==='success' && typeof json.metadata==='object'){
					$('#enabled').prop("checked", json.metadata.enabled);
					$('#ACS_URL').val(json.metadata.ACS_URL||'');
					$('#Entity_ID').val(json.metadata.Entity_ID||'');
					$('#Redirect_URL').val(json.metadata.Redirect_URL||'');
					$('#POST_URL').val(json.metadata.POST_URL||'');
					$('#provider_name').val(json.metadata.provider_name||'');
					$('#unsigned_allowed').prop("checked", json.metadata.unsigned_allowed);
					$('#x509').val(json.metadata.x509||'');
					$('#Issuer').val(json.metadata.Issuer||'');
					$('#private_key').val(json.metadata.private_key||'');

					$('#attr_pid').val(json.metadata.attr_pid||'');
					$('#attr_group').val(json.metadata.attr_group||'');
					$('#attr_profile').val(json.metadata.attr_profile||'');
					$('#attr_email').val(json.metadata.attr_email||'');
					$('#attr_first_name').val(json.metadata.attr_first_name||'');
					$('#attr_last_name').val(json.metadata.attr_last_name||'');

					$('#login_title').val(json.metadata?.form_gui?.login_title||'');
					$('#cred_input').prop("checked", json.metadata?.form_gui?.cred_input);

					if(typeof json.metadata.unsigned_allowed==='boolean') {
						$('#unsigned_allowed').closest('tr').removeClass('display_none');
					}
				}
			}
		});
	},

	clearMetadata:function(){
		$('#saml2_form')[0].reset();
		change_made();
		return false;
	},

	updateMetadata:function(){
		// get our form into a nice json object
		var data={};
		var form_array=$("#saml2_form").serializeArray();
		$.each(form_array,function(){data[this.name]=this.value;});
		$.each($("#saml2_form").find(':checkbox'),function(){data[this.name]=$(this).prop('checked');})
		if(typeof data.private_key==='string' && data.private_key.length){
			var key=data.private_key.trim().replace(/\r\n/g,'\n');
			if(key.substr(0,6)!='-----B'){
				key='-----BEGIN RSA PRIVATE KEY-----\n'+key;
				if(key.charCodeAt(key.length-1)!=10) {
					key+='\n';
				}
				key+='-----END RSA PRIVATE KEY-----';
			}
			data.private_key=key;
		}
		if(typeof data.x509==='string' && data.x509.length){
			var x509=data.x509.trim().replace(/\r\n/g,'\n');
			if(x509.substr(0,6)!='-----B'){
				x509='-----BEGIN CERTIFICATE-----\n'+x509;
				if(x509.charCodeAt(x509.length-1)!=10) {
					x509+='\n';
				}
				x509+='-----END CERTIFICATE-----';
			}
			data.x509=x509;
		}
		// move the form_gui stuff into the sub-object
		data.form_gui={login_title:data.login_title,cred_input:data.cred_input};
		delete data.login_title;
		delete data.cred_input;

		// save it
		$.ajax({
			type: 'POST',
			url: 'json/saml2/metadata?type=' + this.type + '&' + getUrlTokenArg(),
			async: true,
			cache: false,
			dataType: 'json',
			data: JSON.stringify( data ),
			contentType: 'application/json;charset=UTF-8',
			success: function (json) {
				if(typeof json==='object' && json.results==='success'){
					change_saved();
					$('#invalid_config').removeClass('show');
					SAML2.loadMetadata();
				}
				else {
					$('#invalid_config').addClass('show');
				}
			}
		});
		return false;
	}
};

$(document).ready(function(){
	SAML2.loadMetadata();
});

function type_changed() {
	window.location='embed.php?php=SAML2&type='+$('#type').val()+'&'+getUrlTokenArg();
}

//]]>
</script>

<form method='post' id='saml2_form'>

<table>
	<tr><td>Type:</td><td>
		<select id='type' name='type' onchange="type_changed();"><option>users</option><option>administrators</option></select>
	</td></tr>
	<tr><td>Enabled:</td><td>
		<label><input type='checkbox' id='enabled' name='enabled' onchange="change_made();" /> enable SAML 2.0 use</label>
	</td></tr>
	<tr><td>ACS URL:</td><td>
		<input type='text' id='ACS_URL' name='ACS_URL' size='60' onchange="change_made();" oninput="change_made();" />
		<span class='small_note' title='SubjectConfirmation - SubjectConfirmationData - Recipient'>e.g. https://uc.revation.com/SAML2</span>
	</td></tr>
	<tr><td>Entity ID:</td><td>
		<input type='text' id='Entity_ID' name='Entity_ID' size='60' onchange="change_made();" oninput="change_made();" />
		<span class='small_note' title='Conditions - AudienceRestriction - Audience'>e.g. revation</span>
	</td></tr>
	<tr><td>Redirect URL:</td><td>
		<input type='text' id='Redirect_URL' name='Redirect_URL' size='60' onchange="change_made();" oninput="change_made();" />
		<span class='small_note'>e.g. https://accounts.google.com/o/saml2?idpid=12345abcd</span>
	</td></tr>
	<tr><td>POST URL:</td><td>
		<input type='text' id='POST_URL' name='POST_URL' size='60' onchange="change_made();" oninput="change_made();" />
		<span class='small_note'>e.g. https://accounts.google.com/o/saml2?idpid=12345abcd</span>
	</td></tr>
	<tr><td>Provider Name:</td><td>
		<input type='text' id='provider_name' name='provider_name' size='60' onchange="change_made();" oninput="change_made();" />
		<span class='small_note'>e.g. revation_connect</span>
	</td></tr>
	<tr class="display_none"><td><i>For diagnostics only</i>:</td><td>
		<label><input type='checkbox' id='unsigned_allowed' name='unsigned_allowed' onchange="change_made();" /> allows unsigned Response</label>
		&nbsp; <span class='small_note'>there is no account security with this enabled</span>
	</td></tr>
	<tr><td>Certificate:</td><td>
		<textarea id="x509" name="x509" rows="10" cols="120" onchange="change_made();" oninput="change_made();"></textarea>
		<br/>
		<span class='small_note'>e.g. -----BEGIN CERTIFICATE----- MII...</span>
	</td></tr>
	<tr><td>Issuer:</td><td>
		<input type='text' id='Issuer' name='Issuer' size='60' onchange="change_made();" oninput="change_made();" />
		<span class='small_note'>e.g. revation_connect</span>
	</td></tr>
	<tr><td>Private Key:</td><td>
		<textarea id="private_key" name="private_key" rows="10" cols="120" onchange="change_made();" oninput="change_made();"></textarea>
		<br/>
		<span class='small_note'>e.g. -----BEGIN RSA PRIVATE KEY----- MII...</span>
	</td></tr>
	<tr><td>Notes:</td><td>
		For IdP-initiated Responses, the <b>Redirect URL</b>, <b>POST URL</b>, and <b>Provider Name</b> are not needed, but the <b>Issuer</b> is required to uniquely identify the private group's configuration.<br/>
		For <i>Response &#5125; EncryptedAssertion</i> Responses, the IdP-configuration's matching certificate's <b>private_key</b> is required in order decrypt it.<br/>
		The <i>Response &#5125; Assertion &#5125; Subject &#5125; NameID </i> must be present and case-insensitively uniquely identify an account within a group/tenant.<br/>
		The <i>Response &#5125; Assertion &#5125; AttributeStatement</i> must contain an <i>Attribute</i> named <b>group</b>.  Optional names include <b>email</b>, <b>first_name</b>, <b>last_name</b>, and <b>profile</b>.
	</td></tr>
	<tr><td>Use instead of <i>NameId</i>:</td><td>
		<input type='text' id='attr_pid' name='attr_pid' size='32' onchange="change_made();" oninput="change_made();" />
		<span class='small_note'>use this Attribute for the presence identifier</span>
	</td></tr>
<?php 
if($revation->adminGlobal())
	echo "<tr><td>Use instead of <b>group</b>:</td><td><input type='text' id='attr_group' name='attr_group' size='32' onchange=\"change_made();\" oninput=\"change_made();\" /> <span class='small_note'>use this Attribute for the private group identifier</span></td></tr>";
?>
	<tr><td>Use instead of <b>profile</b>:</td><td>
		<input type='text' id='attr_profile' name='attr_profile' size='32' onchange="change_made();" oninput="change_made();" />
		<span class='small_note'>use this Attribute for the named profile in the private group (default is {group}-guest)</span>
	</td></tr>
	<tr><td>Use instead of <b>email</b>:</td><td>
		<input type='text' id='attr_email' name='attr_email' size='32' onchange="change_made();" oninput="change_made();" />
		<span class='small_note'>use this Attribute for the account's email notification address</span>
	</td></tr>
	<tr><td>Use instead of <b>first_name</b>:</td><td>
		<input type='text' id='attr_first_name' name='attr_first_name' size='32' onchange="change_made();" oninput="change_made();" />
		<span class='small_note'>use this Attribute for the given first name</span>
	</td></tr>
	<tr><td>Use instead of <b>last_name</b>:</td><td>
		<input type='text' id='attr_last_name' name='attr_last_name' size='32' onchange="change_made();" oninput="change_made();" />
		<span class='small_note'>use this Attribute for the surname</span>
	</td></tr>
	<tr><td>Login GUI title:</td><td>
		<input type='text' id='login_title' name='login_title' onchange="change_made();" oninput="change_made();" />
		<span class='small_note'>use this Attribute in the Login form, e.g. "Click to Log In with MyIdP" </span>
	</td></tr>
	<tr><td>Login GUI credentials:</td><td>
		<label><input type='checkbox' id='cred_input' name='cred_input' onchange="change_made();" /> enable username/password</label>
		<span class='small_note'>allow users to optionally use username and password</span>
	</td></tr>
	<tr><td colspan="2">
		<div id='change_happened' class='change_happened'>Changes made - press <b>Update Metadata</b> to save!</div>
		<div id='invalid_config' class='change_happened'>Error: Invalid configuration!</div>
	</td></tr>
</table>

</form>

<div style='text-align:center;'>
<?php
	echo'<input type=button name=add value="Update Metadata" class="btn btn-secondary btn-sm" id=apply_changes disabled=disabled ';
	if($revation->adminRight('ar_maincfg'))
		echo'onclick="return SAML2.updateMetadata();"';
	echo'>';
?>
<input type='button' value='Clear' class='btn btn-secondary btn-sm' onclick="return SAML2.clearMetadata();">
<input type='button' value='&#x21e6; Back' class='btn btn-dark btn-sm' onclick="window.location='embed.php?php=<?=$_SESSION['nav_back']?>&<?=$urlTokenArg?>';return false;">
</div>


<?php include 'groupEnd.php';?>
</form>

<?php include 'tableBottom.php';?>