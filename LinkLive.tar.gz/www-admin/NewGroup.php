<?php
if($revation->groupTamperingDetected()){exit();}
$urlTokenArg=$revation->getUrlTokenArg();
?>
<tr>
<td style='vertical-align: top;'>Domain Name:</td>
<td>
	<input type=text required='required' placeholder='domain name' name=domain maxlength=64 value='<?php echo htmlspecialchars($_REQUEST['domain']);?>' /><br/>
	<span style='font-style: italic; font-size: x-small;'>
		case-INsensitive {<span class=valch>a</span>-<span class=valch>z</span>,<span class=valch>0</span>-<span class=valch>9</span>,<span class=valch>.</span>,<span class=valch>-</span>}, e.g. company.com
	</span>
</td>
</tr>
<tr>
<td style='vertical-align: top;'>Group:</td>
<td>
	<input type=text required='required' placeholder='group' name=group maxlength=64 value='<?php echo htmlspecialchars($_REQUEST['group']);?>' /><br/>
	<span style='font-style: italic; font-size: x-small;'>
		case-sensitive {<span class=valch>a</span>-<span class=valch>z</span>,<span class=valch>A</span>-<span class=valch>Z</span>,<span class=valch>0</span>-<span class=valch>9</span>,<span class=valch>.</span>,<span class=valch>-</span>,<span class=valch>_</span>} e.g. company
	</span>
</td>
</tr>
<tr>
<td style='vertical-align: top;'>Group Location:</td>
<td>
	<input type=text placeholder='group location' name=grouploc maxlength=64 value='<?php echo htmlspecialchars($_REQUEST['grouploc']);?>' /><br/>
	<span style='font-style: italic; font-size: x-small;'>
		fully-qualified path of where this group will be located (group will be added to path).<br/>if unsure, leave this field blank.  Example: <span class=valch>/mnt/tenants</span>
	</span>
</td>
</tr>
<tr>
<td style='vertical-align: top;'>Short Group Description:</td>
<td>
	<input type=text placeholder='short group description' name=groupdesshort maxlength=64 value='<?php echo htmlspecialchars($_REQUEST['groupdesshort']);?>' /><br/>
	<span style='font-style: italic; font-size: x-small;'>
		optional short description of the group e.g. in drop-down selectors
	</span>
</td>
</tr>
<tr>
<td style='vertical-align: top;'>Long Group Description:</td>
<td>
	<input type=text placeholder='long group description' name=groupdeslong maxlength=1024 value='<?php echo htmlspecialchars($_REQUEST['groupdeslong']);?>' style='width: 100%;' /><br/>
	<span style='font-style: italic; font-size: x-small;'>
		optional informational longer description of the group
	</span>
</td>
</tr>
<tr>
<td align=center colspan=2>
	<br/>
	<input type=submit name=test value='Test' class='btn btn-secondary btn-sm' />&nbsp;
	<input type=submit name=create value='Create' class='btn btn-secondary btn-sm' />&nbsp;
	<input type=submit name=cancel value='Cancel' class='btn btn-secondary btn-sm' onclick="window.location='embed.php?doc=Config.html&<?=$urlTokenArg?>';return false;" />
</td>
</tr>