<?php
include 'tableTop.php';
include 'groupPre.php';
echo'New Service';
include 'groupStart.php';

if($revation->adminGlobal()){
  echo'Please select a private group to create a New Service.';
  include 'groupEnd.php';
  include 'tableBottom.php';
  exit();
}

?>

<table>
<tr><td style="vertical-align: top; width: 17em; font-weight: bold;">Select Service Type:</td><td>Description:</td></tr>
<tr><td style="vertical-align: top;"><select id="service_type" name="service_type" class="selectepicker"></select></td><td id="description"></td></tr>

<tr><td colspan=2>&nbsp;</td></tr>

<tr><td style="vertical-align: top;">
    <span style="font-weight: bold;">Create or Select Service Account:</span>
    <br/>
    <div class="dropdown">
        <input class="dropdown-toggle" style="width: 100%;" type="text" id="dropdown_account" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" placeholder="account" />
        <div id="account" class="dropdown-menu" style="max-height: 20rem; overflow-y: auto;" aria-labelledby="dropdown_account">
            <div id="menuItems">
                <div class="dropdown-header">Enter Account<div>
            </div>
        </div>
    </div>
</td><td>
    Each service must have an associated user account to function properly.
    You can create a new service user account, or you can use an existing one if you've already created one that's not in use by another service.
    If you select an existing account, you must know and enter the credentials on the service page.
</td></tr>

<tr><td colspan=2>&nbsp;</td></tr>

<tr><td style="vertical-align: top;">
    <span style="font-weight: bold;">Select Service Account Profile:</span>
    <br/>
    <select class="form-control form-control-sm" id="profile">
    </select>
</td><td>
    If you are creating a new service account, you must associate the account with a named profile. 
    This is ignored if you are using an existing account.
</td></tr>

<tr><td colspan=2>&nbsp;</td></tr>

<tr><td style="vertical-align: top;">
    <span style="font-weight: bold;">Enter a Display Name:</span>
    <br/>
    <input style="width: 100%;" type="text" id="display" placeholder="display" />
    </td><td>
    For a new service account, this will become the friendly display for the account.
    For an existing service account, leaving this blank will use the account's friendly display, or you can override it here.
</td></tr>

<tr><td colspan=2>&nbsp;</td></tr>

<tr><td colspan=2>
    <input type=button value='Create' class='btn btn-secondary btn-sm' onclick='return newServiceCreate();'>
    <input type=button id='cancel' value='Cancel' class='btn btn-secondary btn-sm'>
</td></tr>
</table>

<form id='create_form' method='post' class='display_none'></form>

<?php
include 'groupEnd.php';
include 'tableBottom.php';
?>

<script type="text/javascript" src="NewService.js"></script>
