var calMonths=new Array('January','February','March','April','May','June','July','August','September','October','November','December');

var dateStart = null;
var dateEnd = null;

var isShift = false;

document.onkeyup = function (event) {
    if (event == null && window.event) {
        event = window.event;
    }
    if (event.keyCode == 16) {
        isShift = false;
    }
};

document.onkeydown = function (event) {
    if (event == null && window.event) {
        event = window.event;
    }
    if (event.keyCode == 16) {
        isShift = true;
    }
};

function verifyForm(form, emailreq) {
	var days = parseInt(form.days.value);
	if (!dateStart || !dateEnd || days <= 0 || isNaN(days)) {
		alert("Not a valid date range for query.");
		return false;
	}
	if (days > 366) {
		alert("Ranges longer than one year are not supported.");
		return false;
	}
	if (form.addr.value.length == 0 && emailreq) {
		alert("Missing secure email address.");
		return false;
	}
	return true;
}

function onover(td) {
	td.style.backgroundColor = 'ffffff';
}

function onout(td){
	td.style.backgroundColor='';
}

function fullDate(y, m, d) {
	var str=''+y;
	m++;	// 0-11 -> 1-12
	if (m < 10)
		str += '0';
	str += m;
	if (d < 10)
		str += '0';
	str += d;
	return str;
}

function parseDays(input) {
	var days = parseInt(input.value);
	if (isNaN(days)||days<=0) {
		days = 1;
	}
	if (dateStart) {
		dateEnd = new Date(dateStart.getFullYear(), dateStart.getMonth(), dateStart.getDate() + days - 1);
	}
	else {
		dateEnd = null;
	}

	setInputs();
}

function parseDate(input, start) {
	// try to let Date object parse it
	var d = new Date();
	d.setTime(Date.parse(input.value));
	if (isNaN(d.getTime()) && input.value.length == 8){
		// let's see if it's all numeric
		d = new Date(parseInt(input.value.substring(0, 4)), parseInt(input.value.substring(4, 6)) - 1, parseInt(input.value.substring(6, 8)));
	}
	if (!isNaN(d.getTime())) {
		if (start) {
			dateStart = d;
		}
		else {
			dateEnd = d;
		}
	}
	else {
		if (start) {
			dateStart = null;
		}
		else {
			dateEnd = null;
		}
	}

	setInputs();
}

function setInputs() {
    var d = new Date();
    if (dateStart > d) {
        dateStart = d;
    }
    if (dateEnd > d) {
        dateEnd = d;
    }
    if (dateEnd && dateStart > dateEnd) {
        var temp = dateStart;
        dateStart = dateEnd;
        dateEnd = temp;
    }
    
	e = document.getElementById('start');
	e.value = !dateStart ? '' : fullDate(dateStart.getFullYear(), dateStart.getMonth(), dateStart.getDate());
	if (!dateEnd) {
		dateEnd = dateStart;
	}
	e = document.getElementById('end');
	e.value = !dateEnd ? '' : fullDate(dateEnd.getFullYear(), dateEnd.getMonth(), dateEnd.getDate());
	e = document.getElementById('days');
	e.value = '' + (!dateStart || !dateEnd ? 0 : Math.round((dateEnd.getTime() - dateStart.getTime()) / 86400000 + 1));

	dumpMonth('months', dateStart.getFullYear(), dateStart.getMonth());
}

function rangeSelected(date_start, days, date_end) {
	dateStart = date_start;
	//date_end might be null
	if (date_end) {
		dateEnd = date_end;
	}
	else{
		dateEnd = new Date(date_start.getFullYear(), date_start.getMonth(), date_start.getDate() + days - 1);
	}
	setInputs();
}

function dayclicked(event, y, m, d) {
	if (event == null && window.event) {
		event = window.event;
	}
	if (event.stopPropagation) {
		event.stopPropagation();
	}
	else {
		event.cancelBubble = true;
	} 
	if (dateStart == null || !isShift) {
		dateStart = new Date(y, m, d);
		dateEnd = null;
	}
	else {
		var d = new Date(y, m, d);
		if (!dateEnd) {
			if (d < dateStart) {
				dateEnd = dateStart;
				dateStart = d;
			}
			else {
				dateEnd = d;
			}
		}
		else {
			if (d < dateStart) {
				dateStart = d;
			}
			else {
				dateEnd = d;
			}
		}
	}
	setInputs();
}

function Calendar() {
	//private:
	var that = this;	// must use that in private methods

	// code being generated
	var html = "";
	var rowsWritten = 0;

	// current date being output
	var year = 0;
	var month = 0;
	var dom = 1;
	var dow = 6;

	// the month being written
	var dateWritten = 0;

	// the current date
	var today = null;

	function getWeek(y, m, d) {
		var dateInQuestion = new Date(y, m, d);
		var dateNewYearsDay = new Date(y, 0, 1);
		var dayOfWeekNYD = dateNewYearsDay.getDay();
		var dayOfYear = Math.floor((dateInQuestion.getTime() - dateNewYearsDay.getTime() - (dateInQuestion.getTimezoneOffset() - dateNewYearsDay.getTimezoneOffset()) * 60000) / 86400000) + 1;
		var weekNumber=Math.floor((dayOfYear + dayOfWeekNYD - 1) / 7);
		if (dayOfWeekNYD < 4) {	// as per ISO 8601
			if (++weekNumber > 52) {
				// it might be next year's week 1
				dateNewYearsDay = new Date(y + 1, 0, 1);
				weekNumber = dateNewYearsDay.getDay() < 4 ? 1 : 53;
			}
		}
		return weekNumber;
	}

	function addJs(y, m, d) {
		if (y == undefined) {
			y = year;
		}
		if (m == undefined) {
			m = month;
		}
		if (d == undefined) {
			d = dom;
		}
		html += ' onmouseover="onover(this)" onmouseout="onout(this)" onclick="dayclicked(event,' + y + ',' + m + ',' + d + ')"';
	}

	function isSelected() {
		if (that.dateSelectedStart) {
			var d = new Date(year, month, dom);
			if (that.dateSelectedEnd) {
				return d >= that.dateSelectedStart && d <= that.dateSelectedEnd;
			}
			else {
				return d.getTime() == that.dateSelectedStart.getTime();
			}
		}
		else {
			if (that.dateSelectedEnd) {
				var d = new Date(year, month, dom);
				return d.getTime() == that.dateSelectedEnd.getTime();
			}
			else {
				return false;
			}
		}
	}

	function isValid() {
		if (year > today.getFullYear() || (year == today.getFullYear() && (month > today.getMonth() || (month == today.getMonth() && dom > today.getDate())))) {
			return false;
		}
		if (that.dateInvalidBefore) {
			var d = new Date(year, month, dom);
			return d >= that.dateInvalidBefore;
		}
		return true;
	}

	function generateDay() {
		if (dow++ == 6) {
			rowsWritten++;
			dow = 0;
			html += '</tr><tr><td><a class=lnk href=# onclick="rangeSelected(new Date(' + year + ',' + month + ',' + dom + '),7);return false;">' + getWeek(year, month, dom) + '</a></td>';
		}
		html += '<td class=';
		if (isSelected()) {
			html += 'selected';
			if (isValid()) {
				addJs();
			}
		}
		else if (isValid()) {
			if (year == today.getFullYear() && month == today.getMonth() && dom == today.getDate()) {
				html += 'today';
			}
			else {
				if (year != dateWritten.getFullYear() || month != dateWritten.getMonth()) {
					html += 'daynotmonth';
				}
				else {
					html += 'day';
				}
			}
			addJs();
		}
		else {
			html += 'invalid';
			if (year != dateWritten.getFullYear() || month != dateWritten.getMonth()) {
				html += 'notmonth';
			}
			else {
				html += 'thismonth';
			}
		}
		html += '>' + dom + '</td>';
		dom++;
	}

// public:
	this.dateInvalidBefore = null;
	this.dateSelectedStart = null;
	this.dateSelectedEnd = null;

    this.generate = function (id, y, m) {
        today = new Date();
        year = y ? y : today.getFullYear();
        month = m == undefined ? today.getMonth() : m;
        dateWritten = new Date(year, month, 1);
        var startingDayOfWeek = dateWritten.getDay();
        if (startingDayOfWeek == 0) {
            // make sure we have at least one day from the previous month on top
            startingDayOfWeek = 7;
        }
        var dateLastMonth = new Date(year, month, 1 - startingDayOfWeek);
        var dateNextMonth = new Date(year, month + 1, 1);
        var daysInMonth = Math.round((dateNextMonth.getTime() - dateWritten.getTime()) / 86400000);

        // header
        html = '<table cellspacing="1" cellpadding="0" id="month" style="border: 1px solid silver;">';
        html += '<tr><td>&nbsp;</td><td class="header">';
        html += '<button class="btn btn-secondary btn-xs" onclick="dumpMonth(\'' + id + '\',' + dateLastMonth.getFullYear() + ',' + dateLastMonth.getMonth() + ');return false;">&lt;</button>';
        html += '</td><td colspan=5 class=header><a class=lnk href=# onclick="rangeSelected(new Date(' + year + ',' + month + ',1),' + daysInMonth + ',new Date(' + year + ',' + month + ',' + daysInMonth + '));return false;">' + calMonths[month] + ' ' + year + '</a></td><td class=header>';
        html += '<button class="btn btn-secondary btn-xs" ';
        if (dateNextMonth > today) {
            html += 'disabled';
        }
        else {
            html += 'onclick="dumpMonth(\'' + id + '\',' + dateNextMonth.getFullYear() + ',' + dateNextMonth.getMonth() + ');return false;"';
        }
        html += '>&gt;</button>';
        html += '</td></tr>';
        html += '<tr><td>&nbsp;</td><td class=dow>Sun</td><td class=dow>Mon</td><td class=dow>Tue</td><td class=dow>Wed</td><td class=dow>Thu</td><td class=dow>Fri</td><td class=dow>Sat</td>';

        // do days before this month
        dom = dateLastMonth.getDate();
        month = dateLastMonth.getMonth();
        year = dateLastMonth.getFullYear();
        startingDayOfWeek--;
        while (dow < startingDayOfWeek || rowsWritten == 0) {
            generateDay();
        }

        // do this month's day
        dom = 1;
        month = dateWritten.getMonth();
        year = dateWritten.getFullYear();
        while (dom <= daysInMonth) {
            generateDay();
        }

        // do days after this month
        dom = 1;
        if (++month == 12) {
            month = 0;
            year++;
        }
        while (dow < 6 || rowsWritten < 6) {
            generateDay();
        }
        html += '</tr>';

        // do today
        html += '<tr><td>&nbsp;</td><td colspan=7 align=center>Today is ';
        html += '<a href=# class=lnk onclick="dumpMonth(\'' + id + '\',0);return false;">' + today.toDateString() + '</a>';
        html += '</td></tr>';

        // done
        html += '</table>';
        return html;
    };
}

function dumpMonth(id, year, month) {
	e = document.getElementById(id);
	var cal = new Calendar();
	cal.dateSelectedStart = dateStart;
	cal.dateSelectedEnd = dateEnd;
	e.innerHTML = cal.generate(id, year, month);
}
