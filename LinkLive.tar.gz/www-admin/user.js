function editProfile() {
    window.location = 'embed.php?doc=ProfileAdd.html&' + getUrlTokenArg() + '&edit=' + encodeURIComponent($('#profile').val());
}

function make_pass() {
    var cs = [
        { i: 4, s: 'abcdefghijklmnopqrstuvwxyz' },
        { i: 4, s: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' },
        { i: 3, s: '0123456789' },
        { i: 3, s: '!#$ %&\'()*+,-.:;<=>?@[]^_`{|}~' }
    ];
    var p = '';
    while (true) {
        var r = Math.floor(Math.random() * 4);
        var i = -1;
        do {
            do {
                if (++i == 4) i = 0;
            } while (cs[i].i == 0);
        } while (r-- > 0);
        r = Math.floor(Math.random() * cs[i].s.length);
        p += cs[i].s[r];
        cs[i].s = cs[i].s.slice(0, r) + cs[i].s.slice(r + 1, cs[i].s.length);
        cs[i].i--;
        for (i = 0; i < 4; ++i) {
            if (cs[i].i != 0) break;
        }
        if (i == 4) return p;
    }
    return null;
}

function password_generate() {
    var p = make_pass();
    var e = document.getElementById('pass');
    e.style.display = 'none';
    e.value = p;
    e = document.getElementById('passg');
    e.value = p;
    e.style.display = 'inline';
    document.getElementById('passc').value = p;
    return false;
}


function routing_loadTable(url) {
    if (dataTable == null) {
        var config = {
            "bAutoWidth": false,
            responsive: true,
            "oLanguage": {
                "sEmptyTable": "(none set)"
            },
            "aoColumns": [
                {responsivePriority: 1},
                {responsivePriority: 2},
                {},
                {},
                { "bSearchable": false, "bSortable": false, "mRender": routing_renderButtons }
            ],
            "fnRowCallback": function (nRow, aaData, iDisplayIndex) {
                if (aaData[4]) {
                    $(nRow).css("color", "silver");
                }
            }
        };
        tableConfigLoad("userroute", config);
        dataTable = $('#main_data_table').dataTable(config);
    }

    $.ajax({
        type: 'GET',
        url: url,
        async: true,
        cache: false,
        dataType: 'xml',
        success: function (xml) {
            $('#route_src_default').val('');
            $('#route_dst_default').val('');
            var data = [];
            if (xml.childNodes.length === 1) {
                var patterns = xml.childNodes[0];
                for (var i = 0; i < patterns.attributes.length; ++i) {
                    if (patterns.attributes[i].name === 'src') {
                        $('#route_src_default').val(patterns.attributes[i].value);
                    }
                    else if (patterns.attributes[i].name === 'dst') {
                        $('#route_dst_default').val(patterns.attributes[i].value);
                    }
                }
                var p = patterns.childNodes;
                for (var i = 0; i < p.length; ++i) {
                    if (p[i].nodeName === 'pattern') {
                        var src = null, dst = null, priority = null, comment = null, deleted = false;
                        for (var j = 0; j < p[i].attributes.length; ++j) {
                            if (p[i].attributes[j].name === 'deleted') {
                                if (p[i].attributes[j].value === 'true') {
                                    deleted = true;
                                }
                            }
                        }
                        for (var j = 0; j < p[i].childNodes.length; ++j) {
                            if (p[i].childNodes[j].nodeName === 'src') {
                                src = p[i].childNodes[j].textContent;
                            }
                            else if (p[i].childNodes[j].nodeName === 'dst') {
                                dst = p[i].childNodes[j].textContent;
                            }
                            else if (p[i].childNodes[j].nodeName === 'priority') {
                                priority = p[i].childNodes[j].textContent;
                            }
                            else if (p[i].childNodes[j].nodeName === 'comment') {
                                comment = p[i].childNodes[j].textContent;
                            }
                        }
                        if (src || dst || priority || comment) {
                            data.push([src, dst, priority, comment, deleted]);
                        }
                    }
                }
            }
            dataTable.fnClearTable();
            if (data.length) {
                dataTable.fnAddData(data);
            }
        },
        error: function (e) {
            $('#load_fail').css('display', 'inherit');
        }
    });
}


function escapeXmlAttr(unsafe) {
    return unsafe.replace(/["<&]/g, function (c) {
        switch (c) {
            case '"': return '&quot;';
            case '<': return '&lt;';
            case '&': return '&amp;';
        }
    });
}


function escapeXml(unsafe) {
    return unsafe.replace(/[<>&'"]/g, function (c) {
        switch (c) {
            case '<': return '&lt;';
            case '>': return '&gt;';
            case '&': return '&amp;';
            case '\'': return '&apos;';
            case '"': return '&quot;';
        }
    });
}



function routing_saveTable(url) {
    var xml = '<patterns';
    var p = $('#route_src_default').val();
    if (p.length) {
        xml += ' src="' + escapeXmlAttr(p) + '"';
    }
    p = $('#route_dst_default').val();
    if (p.length) {
        xml += ' dst="' + escapeXmlAttr(p) + '"';
    }
    xml += '>\r\n';

    var data = dataTable.fnGetData();
    if (data != null) {
        for (var i = 0; i < data.length; ++i) {
            if (data[i].length == 5) {
                xml += '<pattern';
                if (data[i][4]) {
                    xml += ' deleted="true"';
                }
                xml += '>';
                if (data[i][0] && data[i][0].length) {
                    xml += '<src>' + escapeXml(data[i][0]) + '</src>';
                }
                if (data[i][1] && data[i][1].length) {
                    xml += '<dst>' + escapeXml(data[i][1]) + '</dst>';
                }
                if (data[i][2] && data[i][2].length) {
                    xml += '<priority>' + escapeXml(data[i][2]) + '</priority>';
                }
                if (data[i][3] && data[i][3].length) {
                    xml += '<comment>' + escapeXml(data[i][3]) + '</comment>';
                }
                xml += '</pattern>\r\n';
            }
        }
    }
    xml += '</patterns>';

    $.ajax({
        type: 'PUT',
        url: url,
        async: true,
        cache: false,
        data: xml,
        contentType: 'text/xml; charset=utf-8',
        success: function (results) {
            change_saved();
        },
        error: function (e) {
            $('#save_fail').css('display', 'inherit');
        }
    });
}



function routing_pattern(p) {
    if (p && p.length) {
        var m = p.match(/[0123456789*#NZPXA.!]*/i);
        return m[0].length === p.length ? 1 : -1;
    }
    return 0;
}



function integer_pattern(p) {
    if (p && p.length) {
        var m = p.match(/[0123456789]*/i);
        return m[0].length === p.length ? 1 : -1;
    }
    return 0;
}



function routing_addCheck() {
    var okay_src = routing_pattern($('#route_src').val());
    $('#route_src_okay').css('visibility', okay_src >= 0 ? 'hidden' : 'inherit');
    var okay_dst = routing_pattern($('#route_dst').val());
    $('#route_dst_okay').css('visibility', okay_dst >= 0 ? 'hidden' : 'inherit');
    var okay_pri = integer_pattern($('#route_pri').val());
    $('#route_pri_okay').css('visibility', okay_pri >= 0 ? 'hidden' : 'inherit');
    // check if src/dst/pri are valid and at least one of src/dst is set
    $('#route_save').prop('disabled', okay_src < 0 || okay_dst < 0 || okay_pri < 0 || (okay_src === 0 && okay_dst === 0));
}



function routing_enableRow(_this) {
    var tr = $(_this).parents('tr')[0];
    var data = dataTable.fnGetData(tr);
    dataTable.fnUpdate(false, tr, 4);
    $(tr).css("color", "inherit");
    change_made();
}



function routing_disableRow(_this) {
    var tr = $(_this).parents('tr')[0];
    var data = dataTable.fnGetData(tr);
    dataTable.fnUpdate(true, tr, 4);
    $(tr).css("color", "silver");
    change_made();
}



function routing_doDelete() {
    var dlg = $("#routing_delete");
    dataTable.fnDeleteRow(dlg.data('index'));
    dlg.modal('hide');
    change_made();
    return false;
}



function routing_showDelete(_this) {
    var tr = $(_this).parents('tr')[0];
    var data = dataTable.fnGetData(tr);
    $('#delete_src').html(data[0]);
    $('#delete_dst').html(data[1]);
    $('#delete_pri').html(data[2]);
    $('#delete_cmt').html(data[3]);
    var dlg = $("#routing_delete");
    dlg.data('index', tr._DT_RowIndex);
    dlg.modal('show');
    return false;
}



function routing_showAdd() {
    $('#route_src').val('');
    $('#route_dst').val('');
    $('#route_pri').val('');
    $('#route_cmt').val('');
    var dlg = $("#routing_add");
    dlg.modal('show');
    return false;
}



function routing_doAdd() {
    dataTable.fnAddData([$('#route_src').val(), $('#route_dst').val(), $('#route_pri').val(), $('#route_cmt').val(), null]);
    $('#routing_add').modal('hide');
    change_made();
    return false;
}



function routing_renderButtons(data, type, full) {
    var buttons = '<div style="white-space: nowrap;">';
    buttons += '<button class="btn btn-secondary btn-xs" title="Delete"';
    if (view_only)
        buttons += ' disabled=disabled';
    else
        buttons += ' onclick="return routing_showDelete(this);"';
    buttons += '>&#x267a;&#xFE0E;</button> <button class="btn btn-secondary btn-xs" title="Disable"';
    if (view_only || full[4])
        buttons += ' disabled=disabled';
    else
        buttons += ' onclick="return routing_disableRow(this);"';
    buttons += '>&#x26d4;&#xFE0E;</button> <button class="btn btn-secondary btn-xs" title="Enable"';
    if (view_only || !full[4])
        buttons += ' disabled=disabled';
    else
        buttons += ' onclick="return routing_enableRow(this);"';
    buttons += '>&#x2714;&#xFE0E;</button></div>';
    return buttons;
}



function tel_buttons(focus) {
    var tel = $('#telephone');
    if (focus) {
        if (!tel.prop('disabled') && tel.val() && tel.val().length) {
            // parse for filename in the value
            var t = tel.val();
            var l = t.length;
            var i = 0;
            var html = '';
            while (i < l) {
                var src = '', dst = '';
                while (t.charAt(i) == ' ') {
                    ++i;
                }
                while (i < l && t.charAt(i) != ';' && t.charAt(i) != ',') {
                    src += t.charAt(i++);
                }
                if (i < l && t.charAt(i) == ',') {
                    ++i;
                    while (i < l && t.charAt(i) != ';') {
                        dst += t.charAt(i++);
                    }
                }
                else {
                    dst = src;
                    src = '';
                }
                if (i < l && t.charAt(i) == ';') {
                    ++i;
                }
                if (src.length == 0 && dst.charAt(0) == '@') {
                    var last_slash = dst.lastIndexOf('/');
                    if (last_slash < 0) {
                        dst.lastIndexOf('\\');
                        if (last_slash < 0) {
                            last_slash = 0; // the '@' actually...
                        }
                    }
                    var file = dst.substr(last_slash + 1);
                    html += "<input type=button value='Edit " + rwc_htmlescape(file) + "' class='btn btn-secondary btn-sm' onclick=\"window.location='embed.php?php=UserRouting&key=" + encodeURIComponent($('#key').val()) + "&" + getUrlTokenArg() + "&file=" + encodeURIComponent(file) + "&pg=" + encodeURIComponent($('#privateGroup').val()) + "';return false;\">&nbsp;";
                }
            }
            $('#tel_buttons').html(html);
        }
    }
    else {
        //$('#tel_buttons').html('');
    }
    return false;
}

