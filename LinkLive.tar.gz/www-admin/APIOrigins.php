<?php
include 'tableTop.php';
$urlTokenArg=$revation->getUrlTokenArg();
$file_changes=$revation->config('trunkRestrictions');
?>

<script type="text/javascript">
//<![CDATA[
var g_data = null;
var dataTable = null;
var view_only = true;
<?php
if($revation->adminRight('ar_trunkrestrict'))echo'view_only = false;';
?>

function loadTable(parms){
	$.ajax({
		type: 'GET',
		url: 'json/APIOrigins?<?=$urlTokenArg?>',
		async: true,
		cache: false,
		data: parms,
		success: function (json) {
			g_data = json;
			var data = [];
			if (json.origins){
				for(let i=0;i<json.origins.length;i++){
					if(typeof json.origins[i]==='object') {
						let groups='';
						for(let j=0;j<json.origins[i].groups.length;j++){
							if(groups.length) {
								groups+=' ';
							}
							groups+=json.origins[i].groups[j];
						}
						data.push( [ json.origins[i].origin, groups, i ] );
					}
					else {
						data.push( [ json.origins[i], '', i ] );
					}
				}
			}
			if ( dataTable == null ) {
				var config = {
					"aaData": data,
					"bAutoWidth":false,
					responsive: true,
					"oLanguage": {
						"sEmptyTable": "(none set)"
					},
					"aoColumns": [
						{ /* "Origin" */ "mRender": $.fn.dataTable.render.text(), responsivePriority: 1 },
						{ /* "Group" */ "bVisible": admin_global },
						{ /* button */ "bVisible": !admin_global, "bSearchable": false, "bSortable": false, "mRender": renderButtons }
					],
				};
				tableConfigLoad("apiorigins", config);
				dataTable = $('#main_data_table').dataTable(config);
			}
			else {
				dataTable.fnClearTable();
				if ( data.length ) {
					dataTable.fnAddData( data );
				}
			}
		}
	});
}

$(document).ready(function(){
	loadTable();
});

$(window).on('unload',function() {
	tableConfigStore("apiorigins",dataTable.fnSettings());
});

function addNumber(){
	var num=$("#number").val();
	if(num && num.length){
		$("#number").val("");
		loadTable('add='+encodeURIComponent(num));
	}
}

function deleteItem(i) {
	$('#delete_id').text(i);
	$("#delete_input_id").attr('onclick', 'loadTable(\'del='+encodeURIComponent(i)+'\');$(\'#patternDelete\').modal(\'hide\');');

	var dlg = $('#patternDelete');
	dlg.modal('show');
}

function renderButtons( data, type, full ) {
	var buttons = '<div style="white-space: nowrap;">';

	// delete button
	buttons += '<input type=button value=delete class="btn btn-secondary btn-sm"';
	if(view_only || admin_global) {
		buttons+=' disabled=disabled';
	}
	else {
		buttons += ' onclick="return deleteItem(\''+full[0]+'\')"';
	}
	buttons += '>';
	buttons += '</div>';

	return buttons;
}
//]]>
</script>

<div class='legend'><?php if($revation->adminGlobal())echo'Global Administrators';else echo$revation->adminGroup();?> API Origins</div>
<table cellpadding="0" cellspacing="0" border="0" class="display table-striped table-bordered nowrap w-100" id="main_data_table">
  <thead>
    <tr>
      <th title="Origins from where APIs with credentials are allowed">Allowed Origins</th>
	  <th title="The private group of the Origin" style="text-align: left;">Group</th>
      <th>&nbsp;</th>
    </tr>
  </thead>
</table>
<br/>
  <div style='text-align:center;' class='small_note'>
    API calls from Origins not in this list <span style='text-decoration: underline;'>do not accept credentials</span>
  </div>
<div style='text-align:center;'>
  <div style='font-size: smaller;'>
    Example: <span class="valch">https://app.mycompany.com</span>
  </div>
<?php
if(!$revation->adminGlobal()){
	echo'<form style="display:inline-block;"><input name="number" id="number"> <input type=submit name=add value="Add Origin" class="btn btn-secondary btn-sm" ';
	if($revation->adminRight('ar_trunkrestrict'))
		echo'onclick="addNumber();return false;"';
	else
		echo'disabled';
	echo'></form>';
}
?>
<input type='button' value='&#x21e6; Back' class='btn btn-dark btn-sm' onclick="window.location='embed.php?php=<?=$_SESSION['nav_back']?>&<?=$urlTokenArg?>';return false;">
</div>

<div class="modal fade text-center" id="patternDelete" role="dialog">
    <div class="modal-dialog" role="document" style="padding-top: 15%; text-align: left; max-width: 100%; width: auto !important; display: inline-block;">
        <div class="modal-content" style="overflow: auto;">
            <div class="modal-header light-background">
                <h5 class="modal-title">Delete Origin</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete the Origin '<span id='delete_id' style="font-weight: bold;"></span>'?</p>
                <div style="text-align: center;">
                    <input id="delete_input_id" type=button value=Delete class='btn btn-secondary btn-sm' />
                    <input type=button value=Cancel class='btn btn-secondary btn-sm' data-dismiss="modal" />
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'tableBottom.php';?>