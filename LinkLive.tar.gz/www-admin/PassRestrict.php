<?php
include 'tableTop.php';
include 'groupPre.php';
echo 'Restricted Passwords';
include 'groupStart.php';
?>
<script>
function disable(button,bool) {
	if(bool){
		$(button).prop('disabled', true).addClass('disabled');
	}
	else{
		$(button).prop('disabled', false).removeClass('disabled');
	}
}
function showClear() {
	$('#results').removeClass('hilight_green hilight_red hilight_orange').html('');
	disable('#restrict',true);
	disable('#unrestrict',true);
}

function showWeak() {
	$('#results').html('TOO WEAK').addClass('hilight_orange');
	disable('#restrict',true);
	disable('#unrestrict',true);
}

function showRestrict(text,allow_unrestrict) {
	$('#results').html(text).addClass('hilight_red');
	disable('#restrict',true);
	disable('#unrestrict',!allow_unrestrict);
}

function showNoRestrict() {
	$('#results').html('no restriction').addClass('hilight_green');
	disable('#restrict',false);
	disable('#unrestrict',true);
}

function passwordRestrict() {
	showClear();
	if(!$('#test').val().length){
		return;
	}
	$.ajax({
		type: 'POST',
		url: 'api/passwords/restricted/'+encodeURIComponent($('#test').val())+'?restricted=true&'+urlTokenArg,
		async: true,
		cache: false,
		success: function (json) {
			if (typeof json.results==='boolean'){
				if(json.results){
					showRestrict('RESTRICTED',true);
				}
				else{
					showNoRestrict();
				}
			}
		},
		error: function(json){
		}
	});
}

function passwordUnrestrict() {
	showClear();
	if(!$('#test').val().length){
		return;
	}
	$.ajax({
		type: 'POST',
		url: 'api/passwords/restricted/'+encodeURIComponent($('#test').val())+'?restricted=false&'+urlTokenArg,
		async: true,
		cache: false,
		success: function (json) {
			if (typeof json.results==='boolean'){
				if(json.results){
					showNoRestrict();
				}
			}
		},
		error: function(json){
		}
	});
}

function passwordTest() {
	showClear();
	let val=$('#test').val();
	if(!val.length){
		return;
	}
	if(val.length<6){
		showWeak();
		return;
	}
	let letters=0,numbers=0;
	for(let i=0;i<val.length;++i){
		if((val[i]>='a'&&val[i]<='z')||(val[i]>='A'&&val[i]<='Z')) {
			++letters;
		}
		else if(val[i]>='0'&&val[i]<='9'){
			++numbers;
		}
	}
	if(letters==0||numbers==0){
		showWeak();
		return;
	}

	$.ajax({
		type: 'GET',
		url: 'api/passwords/restricted/'+encodeURIComponent($('#test').val())+'?'+urlTokenArg,
		async: true,
		cache: false,
		success: function (json) {
			if (typeof json.results==='boolean'){
				if(json.results){
					var results='RESTRICTED';
					if(json.global){
						results+= ' (global)';
					}
					showRestrict(results,!json.global||admin_global);
				}
				else{
					showNoRestrict();
				}
			}
		},
		error: function(json){
		}
	});
}
</script>

<form>
<div class="form-group">
	<label for="text">Enter a Password</label>
	<input type="text" class="form-control" id="test" placeholder="password">
	<small class="form-text text-muted">
	Press Test to check if it's in the restricted list.
	Note: passwords without at least 1 letter and 1 number and at least 6 in length are not stored
	because such a weak policy is not effective.
	Restricted passwords are stored case-insensitive<?php if($revation->adminGlobal())echo', and cannot be removed from the global list'; ?>.
	</small>
</div>
<div class="form-group" id="results">
</div>
<button type="submit" class="btn btn-primary btn-sm" onclick="passwordTest();return false;">Test</button>
<button type="button" id="restrict" class="btn btn-success btn-sm disabled" disabled onclick="passwordRestrict();return false;">Restrict</button>
<button type="button" id="unrestrict" class="btn btn-danger btn-sm disabled" disabled onclick="passwordUnrestrict();return false;">Remove Restriction</button>
</form>

<br/>
<br/>

<button type="button" class="btn btn-dark btn-sm" onclick="window.location='embed.php?php=Tools&<?=$urlTokenArg?>';return false;">&#x21e6; Back to Tools</button>
<?php
include 'groupEnd.php';
include 'tableBottom.php';
?>