var g_data = null;
var dataTable = null;

function output_line(title, data) {
    var html = '<tr><td style="text-align: right;">' + title + ':</td><td>';
    if (typeof data == 'string') {
        html += rwc_htmlescape(data);
    }
    if (typeof data == 'number' && data > 0) {
        var date = new Date(data * 1000);
        if (date) {
            html += date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
        }
        else {
            html += '(unknown)';
        }
    }
    html += '</td></tr>';
    return html;
}

function detail_format(oTable, nTr) {
    var entry = g_data.delUsers[oTable.fnGetData(nTr)[3]];
    var sOut = '<table class="no_max_width" cellpadding="0" cellspacing="0" border="0">';

    if (entry.exists) {
        sOut += '<tr><td colspan="2" class="hilight_red">This deleted account is duplicate with a currently active account</td></tr>';
    }
    else {
        sOut += '<tr><td style="text-align: right;">Undelete this account:</td><td><input type=button value="Un-Delete Account" class="btn btn-secondary btn-sm" onclick="if(confirm(\'Are you sure you want to undelete the account ' + entry.user.emails[0] + '?\'))loadTable(\'cmd=user-undelete&folder=' + entry.folder + '\');return false;"></td></tr>';
    }

    sOut += output_line('First Name', entry.user.firstName);
    sOut += output_line('Last Name', entry.user.lastName);
    sOut += output_line('User Name', entry.user.username);
    sOut += output_line('Telephone Route', entry.user.telephones);
    sOut += output_line('Telephone Caller ID', entry.user.callerid);
    sOut += output_line('Telephone Caller ID 911', entry.user.callerid911);
    sOut += output_line('Telephone MAC', entry.user.macAddr);
    sOut += output_line('Location', entry.user.location);
    sOut += output_line('Comments', entry.user.comments);
    sOut += output_line('Created', entry.user.timeCreated);
    sOut += output_line('Last Authenticated', entry.user.timeLastAuthenticated);

    sOut += '</table>';
    return sOut;
}


function eclick(_this) {
    var t = $(_this);
    var tr = t.parents('tr')[0];
    var span = t.children('span')[0];
    if (dataTable.fnIsOpen(tr)) {
        span.innerHTML = "&#x25B6;";
        dataTable.fnClose(tr);
    }
    else {
        span.innerHTML = "&#x25BC;";
        dataTable.fnOpen(tr, detail_format(dataTable, tr), 'details');
    }
    return false;
}


function renderFolder(data, type, full) {
    if (type == 'display') {
        return "<a href='#' onclick='return eclick(this);'><span>&#x25B6;</span> " + rwc_htmlescape(data) + "</a>";
    }
    else {
        return data;
    }
}


function renderDate(data, type, full) {
    if (type == 'display') {
        var date = new Date(data * 1000);
        return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
    }
    else {
        return data;
    }
}


function loadTable(parms) {
    $.ajax({
        type: 'POST',
        url: 'json/delUsers?' + getUrlTokenArg(),
        async: true,
        cache: false,
        data: parms,
        success: function (json) {
            g_data = json;
            var data = [];
            if (json.delUsers) {
                for (var i = 0; i < json.delUsers.length; i++) {
                    if (json.delUsers[i].user.emails.length) {
                        data.push([
                            json.delUsers[i].folder,
                            json.delUsers[i].user.emails[0],
                            json.delUsers[i].modified,
                            i]);
                    }
                }
            }
            if (dataTable == null) {
                var config = {
                    "aaData": data,
                    "bAutoWidth": false,
                    responsive: true,
                    "oLanguage": {
                        "sEmptyTable": "(none set)"
                    },
                    "aoColumns": [
						{ "mRender": renderFolder },
                        { "mRender": $.fn.dataTable.render.text(), responsivePriority: 1 },
						{ "mRender": renderDate },
						{ "bSearchable": false, "bVisible": false }
                    ]
                };
                tableConfigLoad("docres", config);
                dataTable = $('#main_data_table').dataTable(config);
            }
            else {
                dataTable.fnClearTable();
                if (data.length) {
                    dataTable.fnAddData(data);
                }
            }
        }
    });
}

$(document).ready(function () {
    loadTable();
});

$(window).on('unload', function () {
    tableConfigStore("docres", dataTable.fnSettings());
});