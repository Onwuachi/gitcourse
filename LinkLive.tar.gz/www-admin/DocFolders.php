<?php
$urlTokenArg=$revation->getUrlTokenArg();
include 'tableTop.php';
?>

<div id="userRightsDialog" style="display: none;" title="User Rights">
</div>

<script type="text/javascript">
var privateGroup = "<?php echo $revation->adminGroup();?>";
</script>
<script type="text/javascript" src="DocFolders.js"></script>

<div class='legend'>Document Folders for <?php echo $revation->adminGroup();?></div>
<table cellpadding="0" cellspacing="0" border="0" class="display table-striped table-bordered nowrap w-100" id="main_data_table">
  <thead>
    <tr>
      <th title="Friendly Name of the Folder">Folder Name</th>
      <th title="Number of Users with Access to the Folder">Users</th>
      <th title="Number of Files in the Folder">Files</th>
      <th title="Accounts of the Users with Access to the Folder">Usernames</th>
      <th title="Names of the Files in the Folder">Filenames</th>
      <th>&nbsp;</th>
    </tr>
  </thead>
  <tfoot>
    <tr>
      <th>&nbsp;</th>
      <th>&nbsp;</th>
      <th>&nbsp;</th>
      <th>&nbsp;</th>
      <th>&nbsp;</th>
      <th>&nbsp;</th>
    </tr>
  </tfoot>
</table>
<br/>
<input type='button' value='&#x21e6; Back' class='btn btn-dark btn-sm' onclick="window.location='embed.php?php=Tools&<?=$urlTokenArg?>';return false;">

<?php include 'tableBottom.php';?>