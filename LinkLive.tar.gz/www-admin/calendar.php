<?php
$title='Report Generation';
$urlTokenArg=$revation->getUrlTokenArg();
?>
<link rel="stylesheet" type='text/css' href='calendar.css'>
<script type="text/javascript" src='calendar.js'></script>

<?php
include 'tableTop.php';
?>

<form method='post' name='f' action='embed.php?<?=$urlTokenArg?>' onsubmit="return verifyForm(this,true);">
<input type='hidden' name='doc' value='LogViewDay.html'/>

<?php
if(!empty($_REQUEST['privateGroup'])){
	echo'<input type="hidden" name="privateGroup" value="'.htmlspecialchars($_REQUEST['privateGroup']).'"/>';
}
include 'groupPre.php';
echo $title;
if(!empty($_REQUEST['privateGroup'])){
	echo' for "'.htmlspecialchars($_REQUEST['privateGroup']).'"';
}
include 'groupStart.php';
?>

<table class="form-layout">
	<tr>
		<td>
			<table cellpadding="0" cellspacing="0">
				<tr>
					<td>
						Start:
					</td>
					<td>
						<input name="start" id="start" type="text" maxlength="20" onchange="parseDate(this,1);" />
					</td>
				</tr>
				<tr>
					<td>
						End:
					</td>
					<td>
						<input name="end" id="end" type="text" maxlength="20" onchange="parseDate(this,0);" />
					</td>
				</tr>
				<tr>
					<td>
						Days:
					</td>
					<td>
						<input name="days" id="days" type="text" maxlength="4" value="0" onchange="parseDays(this);" />
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<br />
						Email the resulting reports to:
						<br />
						<input name="addr" id="addr" size="30" type="text" />
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<br />
						Default format is HTML
						<br />
						<label>Output as PDF <input name="pdf" id="pdf" type="checkbox" /></label>
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<br />
						Include all Hunt Groups, or only these:
						<br />
						<input name="huntgroups" id="huntgroups" size="30" type="text" />
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<br />
						Run as this timezone:
						<br />
						<select name=tzName><?=$revation->getTimezoneOptions($_REQUEST['tzName'])?></select>
					</td>
				</tr>
				<tr>
					<td colspan="2" align="center">
						<br />
						<input type="submit" value="Run Report" class='btn btn-secondary btn-sm' /> &nbsp;
						<button class='btn btn-dark btn-sm' onclick="window.location='embed.php?doc=HuntGroupReports.html&<?=$urlTokenArg?>';return false;">&#x21e6; Back</button>
					</td>
				</tr>
			</table>
		</td>
		<td>
			<div id="months">
			</div>
		</td>
	</tr>
	<tr>
		<td colspan="2" style="text-align:center; font-size: smaller;">
			<br />
			* In the Calendar, click on the <i>month name</i> or a <i>week number</i> to select<br />
			a range, or hold SHIFT while clicking for an arbitrary range.
		</td>
	</tr>
</table>
<?php include 'groupEnd.php';?>
</form>

<script type="text/javascript">
	dumpMonth('months');
</script>

<?php include 'tableBottom.php';?>