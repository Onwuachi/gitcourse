﻿$(window).on('beforeunload', function () {
    if (change_happened) {
        return 'You have unsaved changes and are navigating away, are you sure?';
    }
});

var nextRow = 1;

function parseTime(tm) {
    if (typeof tm == 'string' && tm.toUpperCase() == 'MIDNIGHT') {
        return 0;
    }
    else if (typeof tm == 'string' && tm.toUpperCase() == 'NOON') {
        return 720;
    }
    else {
        var off = 0;
        var h = 0, m = 0;
        var n;
        if (!isNaN(n = parseInt(tm.charAt(off)))) {
            h = n;
            off++;
            if (!isNaN(n = parseInt(tm.charAt(off)))) {
                h = h * 10 + n;
                off++;
            }
        }
        if (tm.charAt(off) == ':') {
            off++;
        }
        if (!isNaN(n = parseInt(tm.charAt(off)))) {
            m = n;
            off++;
            if (!isNaN(n = parseInt(tm.charAt(off)))) {
                m = m * 10 + n;
                off++;
            }
        }
        if (tm.substr(off, 2) == 'pm') {
            if (h != 12) {
                h += 12;
            }
        }
        else {
            if (h == 12) {
                h = 0;
            }
        }
        return h * 60 + m;
    }
}

function marshalEsc(str) {
    if (typeof str != 'string') {
        return '';
    }
    return str.replace(/\\/g, '\\\\').replace(/,/g, '\\,').replace(/\//g, '\\/');
}

function deleteRow(e,type) {
    if (confirm('Are you sure you want to delete this row?')) {
        $(e).closest(type).remove();
        change_made();
    }
    return false;
}

function escapeValue(value) {
    if (value) {
        return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&apos;");
    }
    else {
        return '';
    }
}

function update_name_field(id, inputId) {
    var index = id.slice(-1);
    var selectId = $("#" + id);
    var inpId = $("#" + inputId);
    if (selectId.val() == 'language') {
        inpId.replaceWith(doLangSelect('sknm'+index, 'name', null, 1));
    } else {
        inpId.replaceWith(resetNameInput('sknm'+index, 'name', null, 30));
    }
}

function resetNameInput(name, title, value, max) {
    var i = "<input onchange='change_made();' name=" + name + " id=" + name;
    i += " type='text' placeholder='" + title + "' size=" + (max < 60 ? max : 60) + " maxlength=" + max;
    if (value) {
        i += " value='" + escapeValue(value) + "'";
    }
    return i + " /> &nbsp; ";
}

function doInput(name, id, title, value, max) {
    var i = "<input onchange='change_made();' oninput='change_made();' name=" + name + id + " id=" + name + id;
    i += " type='text' placeholder='" + title + "' size=" + (max < 60 ? max : 60) + " maxlength=" + max;
    if (value) {
        i += " value='" + escapeValue(value) + "'";
    }
    return i + " /> &nbsp; ";
}

function doSelect(name, id, title, value, max) {
    var arg1 = 'skcg' + id;
    var arg2 = 'sknm' + id;
    var i = "<select onchange=change_made();update_name_field('" + arg1 + "','" + arg2 + "'); name=" + name + id + " id=" + name + id;
    i += " type='text' placeholder='" + title + "' size=" + (max < 60 ? max : 60) + " maxlength=" + max;
    if (value) {
        i += " value='" + escapeValue(value) + "'";
    } 
    i += ">";
    i += "<option " + (value ? '' : 'selected') + " value='unselected'>unselected</option>";
    i += "<option " + (value == 'language' ? 'selected' : '') + " value='language'>Language</option>";
    i += "<option " + (value == 'region' ? 'selected' : '') + " value='region'>Region</option>";
    i += "<option " + (value == 'role' ? 'selected' : '') + " value='role'>Role</option>";
    i += "</select > &nbsp; ";
    return i;
}

function doLangSelect(name, title, value, max) {
    var i = "<select onchange='change_made();' name=" + name + " id=" + name;
    i += " type='text' placeholder='" + title + "' size=" + (max < 60 ? max : 60) + " maxlength=" + max;
    if (value) {
        i += " value='" + escapeValue(value) + "'";
    }
    i += ">";
    i += "<option " + (value ? '' : 'selected') + " value='unselected'>unselected</option>";
    i += "<option " + (value == 'en-US' ? 'selected' : '') + " value='en-US'>English (en-US)</option>";
    i += "<option " + (value == 'de-DE' ? 'selected' : '') + " value='de-DE'>German (de-DE)</option>";
    i += "<option " + (value == 'es-ES' ? 'selected' : '') + " value='es-ES'>Spanish (es-ES)</option>";
    i += "<option " + (value == 'fr-FR' ? 'selected' : '') + " value='fr-FR'>French (fr-FR)</option>";
    i += "<option " + (value == 'it-IT' ? 'selected' : '') + " value='it-IT'>Italian (it-IT)</option>";
    i += "<option " + (value == 'pt-BR' ? 'selected' : '') + " value='pt-BR'>Portuguese (pt-BR)</option>";
    i += "</select > &nbsp; ";
    return i;
}

function getTimeStr(m) {
    if (m <= 0 || m >= 1440) {
        return 'midnight';
    }
    else if (m == 720) {
        return 'noon';
    }
    else {
        var h = Math.floor(m / 60);
        var t = '';
        if (h == 0) {
            t += '12';
        }
        else if (h <= 12) {
            t += h;
        }
        else {
            t += h - 12;
        }
        t += ':';
        m = m - h * 60;
        if (m < 10) {
            t += '0';
        }
        t += m;
        if (h < 12) {
            t += 'am';
        }
        else {
            t += 'pm';
        }
        return t;
    }
}

function marshalSkills(saving) {
    // if there were no changes, don't set the input
    if (change_happened) {
        if (saving) {
            // pass the page change without warning
            change_happened = false;
        }

        var s = $('#skills_list').find('li');
        var results = '/';
        for (var i = 0; i < s.length; i++) {
            var li = $(s[i]);
            if (li.find('input[name^=sknm]').eq(0).val()) {
                results += marshalEsc(li.find('input[name^=sknm]').val());
            } else {
                results += marshalEsc(li.find('select[name^=sknm]').val());
            }
            results += ',';
            results += marshalEsc(li.find('input[name^=skdt]').val());
            results += ',';
            results += marshalEsc(li.find('select[name^=skcg]').val());
            results += ',';
            results += marshalEsc(li.find('input[name^=sknt]').val());
            results += '/';
        }

        // put order results in form
        document.form.order.value = results;
    }
    return true;
}

function doRowSkillHTML(f) {
    var line = '<li class="sortable-state-default">';
    if (f) {
        if (f['category'] == 'language') {
            line += 'name: ' + doLangSelect("sknm" + nextRow, "name", f ? f.name : null, 1);
        } else {
            line += 'name: ' + doInput("sknm", nextRow, "name", f ? f.name : null, 30);
        }
    } else {
        line += 'name: ' + doInput("sknm", nextRow, "name", f ? f.name : null, 30);
    }
    line += '<br/>';
    line += 'DTMF: ' + doInput("skdt", nextRow, "dtmf", f ? f.dtmf : null, 3);
    line += '<br/>';
    line += 'category: ' + doSelect("skcg", nextRow, "category", f ? f.category : null, 1);
    line += '<br/>';
    line += 'notes: ' + doInput("sknt", nextRow, "notes", f ? f.notes : null, 300);
    line += "<input type=button value='&#x1F5D1;' class='btn btn-secondary btn-sm' onclick='return deleteRow(this,\"li\");'/></li>";
    return line;
}

function addSkillRow(e, f) {
    var s = $('#skills_list');
    s.append(doRowSkillHTML(f));
    change_made();
    nextRow++;

    $("input, select, textarea").bind('mousedown.ui-disableSelection selectstart.ui-disableSelection', function (e) {
        e.stopImmediatePropagation();
    });
}



// for editing HUNT GROUP skills
function skillsHuntGroupPopulate() {
    var sl = $('#skills_list');
    if (sl.length) {
        for (var e = 0; e < skills.length; e++) {
            sl.append(doRowSkillHTML(skills[e]));
            nextRow++;
        }
        var s = Sortable.create(sl[0], {
            animation: 150,
            onUpdate: function (evt) {
                change_made();
            }
        });
    }
}


function skillsHuntGroupEdit() {
    if (typeof Sortable === 'function') {
        skillsHuntGroupPopulate();
    }
    else {
        $.getScript("js/Sortable.min.js").done(function (script, textStatus) {
            skillsHuntGroupPopulate();
        });
    }
    return false;
}



// for editing AGENT skills
var skills_hunt_group = {};

function skillLine(skill) {
    if (typeof skill.priority != 'number') {
        skill.priority = 0;
    }
    return skill.name + '<span> (priority: <input type="text" size="3" maxlength="3" value="' + skill.priority + '" onchange="change_made();" />)</span>';
}

function skillsGetAgents(skill_editing) {
    var skills = JSON.parse($('#' + skill_editing).val());
    if ($.isArray(skills) && $.isArray(skills_hunt_group[skill_editing])) {
        // check if all agent skills are part of the hunt group skill set
        var arr = skills_hunt_group[skill_editing];
        for (var i = 0; i < skills.length;) {
            var okay = false;
            for (var j = 0; j < arr.length; j++) {
                if (skills[i].name == arr[j].name) {
                    okay = true;
                }
            }
            if (okay) {
                i++;
            }
            else {
                skills.splice(i, 1);
            }
        }
        // check if all hunt group skills are listed in agent
        for (var i = 0; i < arr.length;) {
            var okay = false;
            for (var j = 0; j < skills.length; j++) {
                if (arr[i].name == skills[j].name) {
                    okay = true;
                }
            }
            if (okay) {
                i++;
            }
            else {
                skills.push({ name: arr[i].name });
            }
        }
    }
    else {
        skills = [];
    }
    return skills;
}


function skillsAdd(sortable, skills, set) {
    for (var i = 0; i < skills.length; i++) {
        if (set == (typeof skills[i].set == 'boolean' && skills[i].set)) {
            sortable.append($("<li class='sortable-state-default'/>").html(skillLine(skills[i])));
        }
    }
}


function skillsPopulate(skill_editing) {
    $('#' + skill_editing + '_display').css('visibility', 'hidden');
    var sl = $('#' + skill_editing + '_list');
    if (sl.length) {
        var skills = skillsGetAgents(skill_editing);
        skillsAdd(sl, skills, true);
        sl.append($("<li class='sortable-state-default sortable-state-disabled'/>").html('Available Skills:'));
        skillsAdd(sl, skills, false);
        var s = Sortable.create(sl[0], {
            animation: 150,
            onUpdate: function (evt) {
                change_made();
            }
        });
    }
}


function skillsEdit(skill_editing) {
    var ea = $('#'+skill_editing+'_edit_area');
    if (ea.css('display') == 'block') {
        skillsClose(skill_editing);
    }
    else if ( typeof Sortable === 'function' ) {
        skillsPopulate(skill_editing);
        ea.css('display', 'block');
    }
    else {
        $.getScript("js/Sortable.min.js").done(function (script, textStatus) {
            skillsPopulate(skill_editing);
            ea.css('display', 'block');
        });
    }
    return false;
}

function skillsDisplay(skill_editing, skills) {
    var html = '';
    for (var i = 0; i < skills.length; i++) {
        if (typeof skills[i].set == 'boolean' && skills[i].set) {
            html += '<span class="sortable-state-default skills_display">' + skills[i].name;
            if (typeof skills[i].priority == 'number' && skills[i].priority > 0) {
                html += ' <span class="badge">' + skills[i].priority + '</span>';
            }
            html += '</span>';
        }
    }
    $('#' + skill_editing + '_display').html(html);
}

function skillsSetFromEditor(skill_editing) {
    var s = $('#' + skill_editing + '_list').find('li');
    var skills = [];
    var set = true;
    for (var i = 0; i < s.length; i++) {
        var li = $(s[i]);
        if (li.hasClass('sortable-state-disabled')) {
            set = false;
        }
        else {
            var categ = null;
            Object.keys(skills_hunt_group).forEach(function (prop) {
                var sk_gp = skills_hunt_group[prop];
                for (var k = 0; k < sk_gp.length; k++) {
                    if (sk_gp[k]['name'] == li.text().split(' ')[0]) {
                        if (sk_gp[k]['category']) {
                            categ = sk_gp[k]['category'];
                        }
                    } 
                }
            });
            var p = parseInt(li.find('input').val());
            if (isNaN(p) || p < 0) {
                p = 0;
            }
            li.find('span').remove();
            skills.push({ name: li.text(), category: categ, priority: p, set: set });
        }
        li.remove();
    }
    $('#' + skill_editing).val(JSON.stringify(skills));
    skillsDisplay(skill_editing, skills);
}

function skillsClose(skill_editing) {
    if ($('#' + skill_editing + '_edit_area').css('display') == 'block') {
        skillsSetFromEditor(skill_editing);
        $('#' + skill_editing + '_edit_area').css('display', 'none');
        $('#' + skill_editing + '_display').css('visibility', 'inherit');
    }
    return false;
}

function skillsInitAll() {
    var inputs = $('input[id^=skills]');
    for (var i = 0; i < inputs.length; i++) {
        skillsDisplay(inputs[i].id, skillsGetAgents(inputs[i].id));
    }
}

function skillsCloseAll() {
    var inputs = $('input[id^=skills]');
    for (var i = 0; i < inputs.length; i++) {
        skillsClose(inputs[i].id);
    }
}



function Groupings(groupings) {
    var doHTML = function (f) {
        var line = '<div class="sortable-state-default">';
        line += 'name: ' + doInput("gpnm", nextRow, "name", f ? f.name : null, 30);
        line += '<br/>';
        line += 'comment: ' + doInput("gpnt", nextRow, "comment", f ? f.notes : null, 300);
        line += "<input type=button value='&#x1F5D1;' class='btn btn-secondary btn-sm' onclick='return deleteRow(this,\"div\");'/></div>";
        return line;
    };

    this.addRow = function (e, f) {
        var s = $('#groupings_list');
        s.append(doHTML(f));
        change_made();
        nextRow++;

        $("input, select, textarea").bind('mousedown.ui-disableSelection selectstart.ui-disableSelection', function (e) {
            e.stopImmediatePropagation();
        });
        return false;
    };

    this.marshal = function (saving) {
        // if there were no changes, don't set the input
        if (change_happened) {
            if (saving) {
                // pass the page change without warning
                change_happened = false;
            }

            var s = $('#groupings_list').find('div');
            var obj = { groupings: [] };
            for (var i = 0; i < s.length; i++) {
                var div = $(s[i]);
                var o = { name: div.find('input[name^=gpnm]').val().replaceAll(',', '-'), notes: div.find('input[name^=gpnt]').val() };
                if (typeof o.name === 'string' && o.name.length) {
                    obj.groupings.push(o);
                }
            }

            // put results in form
            document.form.groupings.value = JSON.stringify(obj);
        }
        return true;
    };

    if (groupings === null) {
        $('#groupings_list').after("<div style='text-align: center;'>(please select a group)</div>");
    }
    else {
        var sl = $('#groupings_list');
        if (sl.length) {
            for (var e = 0; e < groupings.length; e++) {
                sl.append(doHTML(groupings[e]));
                nextRow++;
            }
        }
    }
}



function GroupEdit(groupings) {
    $('input[type=radio][name="dist"]').change(function () {
        if ($('#dist_broadcast').is(':checked'))
            $('#dist_broadcast_options').removeClass('display_none');
        else
            $('#dist_broadcast_options').addClass('display_none');
    });

    if (groupings === null) {
        $('#grouping').after("(there are no configured groupings)");
    }
    else {
        // parse up what we have in grouping
        var grouping = $('#grouping').val().split(',');
        for (var i = 0; i < grouping.length; i++) {
            grouping[i].trim();
        }

        // create a select with all configured groupings
        var select = "<select id=grouping_select multiple>";
        for (var i = 0; i < groupings.length; i++) {
            select += "<option";
            for (var j = 0; j < grouping.length; j++) {
                if (grouping[j] === groupings[i].name) {
                    select += " selected";
                    break;
                }
            }
            select += " title='" + rwc_htmlescape(groupings[i].notes) + "'>" + rwc_htmlescape(groupings[i].name) + "</option>";
        }
        select += "</select>";
        $('#grouping').after(select);
        $('#grouping_select').change(function () {
            // update the hidden field with the selections
            $('#grouping').val($('#grouping_select').val().join(','));
        })
    }
}



function ScheduleExceptions(exceptions) {
    var nextRow = 1;

    this.deleteRow = function (e) {
        if (confirm('Are you sure you want to delete this row?')) {
            $(e).closest('div').remove();
            change_made();
        }
        return false;
    };

    this.marshal = function (saving) {
        // if there were no changes, don't set the input
        if (change_happened) {
            if (saving) {
                // pass the page change without warning
                change_happened = false;
            }

            // get all the rows
            var rows = $("[id^=exception_row_]");
            var results = '/';
            for (var i = 0; i < rows.length; i++) {
                var num = $(rows[i]).attr('id').substr(14);   // remove 'exception_row_'
                var e = document.getElementById("exdt" + num);
                if (e && e.value) {
                    var d = Date.parse(e.value);
                    if (d) {
                        var d = new Date(d);
                        if (d) {
                            results += d.getFullYear();
                            if (d.getMonth() + 1 < 10) {
                                results += '0';
                            }
                            results += d.getMonth() + 1;
                            if (d.getDate() < 10) {
                                results += '0';
                            }
                            results += d.getDate();
                            results += ',';

                            results += $('input[name="exon' + num + '"]:checked').val();
                            results += ',';

                            e = document.getElementById("exst" + num);
                            var mins = 0;
                            if (e) {
                                mins += parseTime(e.value);
                            }
                            results += '' + mins + ',';
                            e = document.getElementById("exnd" + num);
                            mins = 0;
                            if (e) {
                                mins += parseTime(e.value);
                                if (mins == 0) {
                                    // midnight is end of the day for end
                                    mins = 1440;
                                }
                            }
                            results += mins + ',';
                            e = document.getElementById("exnt" + num);
                            if (e && e.value && e.value.length) {
                                results += marshalEsc(e.value);
                            }
                            results += ',';

                            e = document.getElementById("exsc" + num);
                            if (e && e.value && e.value.length) {
                                results += marshalEsc(e.value);
                            }

                            results += '/';
                        }
                    }
                }
            }

            // put order results in form
            document.form.order.value = results;
        }
        return true;
    };

    var availabilityRadio = function (name, availability) {
        name += nextRow;
        var i = "Availability: ";
        i += "<label><input type=radio onchange='change_made();' name=" + name;
        if (availability == 'available') {
            i += " checked=checked";
        }
        i += " value=available /> Yes</label> &nbsp; ";
        i += "<label><input type=radio onchange='change_made();' name=" + name;
        if (availability == 'unavailable') {
            i += " checked=checked";
        }
        i += " value=unavailable /> No</label> &nbsp; ";
        i += "<label><input type=radio onchange='change_made();' name=" + name;
        if (availability == 'unchanged') {
            i += " checked=checked";
        }
        i += " value=unchanged /> Unchanged</label>";
        return i;
    };

    var doRowHTML = function (f) {
        var date = null;
        if (f && f.year && f.month && f.day) {
            date = '' + f.month + '/' + f.day + '/' + f.year;
        }
        var line = '<span id="datechooser' + nextRow + '"><a id="datelink' + nextRow + '" href="#"><img src="imgs/datechooser.png"/></a>' + doInput("exdt", nextRow, "date", date, 10) + '</span> from: ';
        line += doInput("exst", nextRow, "start-time", f ? getTimeStr(f.start) : null, 8);
        line += ' to: ';
        line += doInput("exnd", nextRow, "end-time", f ? getTimeStr(f.end) : null, 8);
        line += '<br/>';
        line += availabilityRadio('exon', f ? f.availability : 'unavailable');
        line += '<br/>&nbsp; notes: ' + doInput("exnt", nextRow, "notes", f ? f.notes : null, 300) + '<br/>&nbsp; script: ' + doInput("exsc", nextRow, "script", f ? f.script : null, 300);
        line += "<input type=button value='&#x1F5D1;' class='btn btn-secondary btn-sm' onclick='return scheduleExceptions.deleteRow(this,\"tr\");'/>";
        return line;
    };

    var setpicker = function (id) {
        var ndExample1 = document.getElementById('datechooser' + id);
        ndExample1.DateChooser = new DateChooser();
        if (!ndExample1.DateChooser.display) {
            return false;
        }
        ndExample1.DateChooser.setCloseTime(350);
        ndExample1.DateChooser.setUpdateFunction(function (objDate) {
            document.getElementById('exdt' + id).value = objDate.getPHPDate('m/d/Y');
            change_made();
            return true;
        });
        document.getElementById('datelink' + id).onclick = function () {
            var d = Date.parse(document.getElementById('exdt' + id).value);
            if (d) {
                ndExample1.DateChooser.setSelectedDate(new Date(d));
            }
            ndExample1.DateChooser.display();
        };
    };

    var append = function (e) {
        $('#exception_list').append('<div class="sortlist sortlist_item" id="exception_row_' + nextRow + '">' + doRowHTML(e) + '</div>');
        setpicker(nextRow);
        nextRow++;
    };

    this.add = function () {
        append();
        change_made();
        return false;
    };

    var sl = $('#exception_list');
    if (sl.length) {
        for (var e = 0; e < exceptions.length; e++) {
            append(exceptions[e]);
        }
        var s = Sortable.create(sl[0], {
            animation: 150,
            onUpdate: function (evt) {
                change_made();
            }
        });
    }
}
