<script type="text/javascript">
var logFetch = 64000;
var logOffset = 0;
var dataTable = null;
var lastTimestamp = 0;
var lastBump = 0;

function getDateTime(gmt) {
	var dt = '';
	try{
		var d = new Date(gmt * 1000);
		dt += (d.getMonth() + 1) + "/" + d.getDate() + "/" + d.getFullYear() + ' ' + d.toLocaleTimeString();
	}
	catch(e) {
		dt += gmt;
	}
	return dt;
}

function renderDateTime( data, type, full ) {
	if(type=='display'){
		return getDateTime(data);
	}
	else{
		return data;
	}
}

function loadTable() {
    idleReset();
	logOffset += logFetch;
    $.ajax({
	    type: 'GET',
		url: 'json/eventData?' + urlTokenArg,
		async: true,
		cache: false,
		data: 'offset='+logOffset+'&fetch='+logFetch,
		success: function (evts) {
			if (!evts || !evts.events) {
				return;
			}
			if ( evts.last ) {
				$('#lastEvent').text( 'Events through ' + getDateTime(evts.last) );
			}
			else {
				$("#getMoreButton").prop('disabled', true);
			}
			// add a small fraction of a second to events with the same timestamp (seconds) to keep the events in order
			// note that they come in oldest to most recent, so we need to parse them backwards so that if more are fetched, the lastTimestamp is correct
			for(var i = evts.events.length-1; i >= 0; --i){
				if(lastTimestamp !== evts.events[i][0]){
					lastTimestamp = evts.events[i][0];
					lastBump = 0.000999;
				}
				evts.events[i][0] += lastBump;
				lastBump -= 0.000001;
			}
			if ( dataTable == null ) {
				var config = {
					"aaData": evts.events,
					"aaSorting": [[0,"desc"]],
					"bAutoWidth": false,
					responsive: true,
					"aoColumns": [
						{ /* "Date/Time" */ "mRender": renderDateTime, "sWidth": "10em", responsivePriority: 1 },
						{ /* "Type" */ "sWidth": "10em", responsivePriority: 2 },
						{ /* "Group" */ "sWidth": "7em", "bVisible": admin_global },
						{ /* "Event" */ "sClass": "cellwrap", "mRender": $.fn.dataTable.render.text() }
					],
					"createdRow": function( row, data, dataIndex ) {
						if ( data[1] ==  'CRITICAL'){
							$(row).addClass('ecritical');
						}
						else if ( data[1] ==  'WARN'){
							$(row).addClass('ewarn');
						}
					}
				};
				tableConfigLoad("events", config);
				dataTable = $('#main_data_table').dataTable(config);
			}
			else {
				if (evts.events.length) {
					dataTable.fnAddData( evts.events );
				}
			}
		}
	});
}

$(document).ready(function(){
	loadTable();
});

$(window).on('unload',function() {
	tableConfigStore("events",dataTable.fnSettings());
});

//# sourceURL=EventLog.php.js
</script>

<?php include 'tableTop.php';?>
	<div class='legend'>Events<?php if($revation->adminGlobal())
    echo"<a href='#' alt='help on this' class='btn btn-info btn-sm rev-help' onclick=\"window.open('Help/events.html','help','width=600,height=600,scrollbars=yes','alwaysRaised')\">&#x1f6c8; Help on this</a>";
  ?></div>
<table cellpadding="0" cellspacing="0" border="0" class="display table table-striped table-bordered nowrap" id="main_data_table" style="padding-top:2em;">
<thead><tr>
	<th title="Date and Time of event" style="text-align: left;">Date/Time</th>
	<th title="The event type and class" style="text-align: left;">Type</th>
	<th title="The private group of the event, or global" style="text-align: left;">Group</th>
	<th title="The full text of the event" style="text-align: left;">Event</th>
</tr></thead>
</table>
<br/>
<div style='text-align:center;'>
<br/>
<input type=button id=getMoreButton value="Fetch More" class='btn btn-secondary btn-sm' onclick="loadTable();return false;">
<span id=lastEvent></span>
</div>

<?php include 'tableBottom.php';?>