<?php
include 'tableTop.php';
include 'groupPre.php';
echo 'Shared Authentication for ';
if($revation->adminGlobal())
	echo"Global Groups";
else
	echo$revation->adminGroup();
include 'groupStart.php';
$urlTokenArg=$revation->getUrlTokenArg();
?>

<script type="text/javascript">
//<![CDATA[

var SharedAuth = {
	loaddata: function() {
		$.ajax({
			type: 'GET',
			url: 'json/sharedauth/data?'+getUrlTokenArg(),
			async: true,
			cache: false,
			success: function (json) {
				if(typeof json==='object' && json.results==='success' && typeof json.data==='object'){
					$('#enabled').prop("checked", json.data.enabled);
					$('#secret').val(json.data.secret||'');
					$('#iv').val(json.data.iv||'');
					$('#token_name').val(json.data.token_name||'');
					$('#datetime_name').val(json.data.datetime_name||'');
					$('#version_name').val(json.data.version_name||'');
					$('#allowUnauthorized').prop("checked", json.data.allowUnauthorized);
					$('#maxTimeDeltaMins').val(json.data.maxTimeDeltaMins||0);
					$('#failDuplicateTokenUse').prop("checked", json.data.failDuplicateTokenUse);

					$('#attr_group').val(json.data.attr_group||'');
					$('#attr_profile').val(json.data.attr_profile||'');
					$('#attr_email').val(json.data.attr_email||'');
					$('#attr_first_name').val(json.data.attr_first_name||'');
					$('#attr_last_name').val(json.data.attr_last_name||'');
				}
			}
		});
	},

	cleardata:function(){
		$('#shareddata_form')[0].reset();
		change_made();
		return false;
	},

	updatedata:function(){
		// get our form into a nice json object
		var data={};
		var form_array=$("#shareddata_form").serializeArray();
		$.each(form_array,function(){data[this.name]=this.value;});
		$.each($("#shareddata_form").find(':checkbox'),function(){data[this.name]=$(this).prop('checked');})
		data.maxTimeDeltaMins=parseInt(data.maxTimeDeltaMins);

		// save it
		$.ajax({
			type: 'POST',
			url: 'json/sharedauth/data?'+getUrlTokenArg(),
			async: true,
			cache: false,
			dataType: 'json',
			data: JSON.stringify( data ),
			contentType: 'application/json;charset=UTF-8',
			success: function (json) {
				if(typeof json==='object' && json.results==='success'){
					change_saved();
					$('#invalid_config').removeClass('show');
					SharedAuth.loaddata();
				}
				else {
					$('#invalid_config').addClass('show');
				}
			}
		});
		return false;
	},

	verify:function(){
		// run the verify
		$.ajax({
			type: 'POST',
			url: 'json/sharedauth/verify?'+getUrlTokenArg()+'&create=false&url='+encodeURIComponent($('#url').val()),
			async: true,
			cache: false,
			dataType: 'json',
			success: function (json) {
				if(typeof json==='object' && typeof json.results==='string'){
					var html='';
					if(json.results==='LOGIN_OK') {
						html += "<div style='color: green;'>CONTINUE</div>";
					}
					else {
						html += "<div style='color: red;'>FAIL</div>";
					}
					html += "<div style='border: silver solid 1px;'>";
					if(typeof json.authmsg==='string'){
						html +=  json.authmsg;
					}
					else if(typeof json.info==='string'){
						html +=  json.info;
					}
					html += "</div>";
					$('#test_results').html(html);
				}
				else {
					$('#test_results').html('FAILED');
				}
			},
			error: function(){
				$('#test_results').html('ERROR');
			}
		});
		return false;
	},

	verify_clear:function(){
		$('#url').val('');
		$('#test_results').html('');
	},

	create:function(){
		// run the create
		$.ajax({
			type: 'GET',
			url: 'json/sharedauth/create?'+getUrlTokenArg()+'&clear='+encodeURIComponent($('#create_clear').val())+'&encode='+encodeURIComponent($('#create_encode').val()),
			async: true,
			cache: false,
			dataType: 'json',
			success: function (json) {
				if(typeof json==='object' && typeof json.results==='string'){
					if(json.results==='success' && typeof json.url==='string') {
						$('#create_results').val('?'+json.url);
					}
					else {
						$('#create_results').val('FAILED');
					}
				}
				else {
					$('#create_results').val('FAILED');
				}
			},
			error: function(){
				$('#create_results').val('ERROR');
			}
		});
		return false;
	},

	create_clear:function(){
		$('#create_clear').val('');
		$('#create_encode').val('');
		$('#create_results').val('');
	}
};

$(document).ready(function(){
	SharedAuth.loaddata();
});

//]]>
</script>

<form method='post' id='shareddata_form'>

<table>
	<tr><td>Enabled:</td><td>
		<label><input type='checkbox' id='enabled' name='enabled' onchange="change_made();" /> enable Shared Auth for user accounts</label>
	</td></tr>
	<tr><td>Encryption Key:</td><td>
		<input type='text' id='secret' name='secret' size='100' onchange="change_made();" oninput="change_made();" />
	</td></tr>
	<tr><td>Encryption IV:</td><td>
		<input type='text' id='iv' name='iv' size='100' onchange="change_made();" oninput="change_made();" />
	</td></tr>
	<tr><td>Token Name:</td><td>
		<input type='text' id='token_name' name='token_name' size='32' onchange="change_made();" oninput="change_made();" />
		<span class='small_note'>e.g. llssotoken</span>
	</td></tr>
	<tr><td>Date-Time Name:</td><td>
		<input type='text' id='datetime_name' name='datetime_name' size='32' onchange="change_made();" oninput="change_made();" />
		<span class='small_note'>e.g. llssodatetime</span>
	</td></tr>
	<tr><td>Version Name:</td><td>
		<input type='text' id='version_name' name='version_name' size='32' onchange="change_made();" oninput="change_made();" />
		<span class='small_note'>e.g. llssoversion</span>
	</td></tr>
	<tr><td><i>Allow Unauthorized</i>:</td><td>
		<label><input type='checkbox' id='allowUnauthorized' name='allowUnauthorized' onchange="change_made();" /> pass verification even if failed</label>
		&nbsp; <span class='small_note'>this is only useful for protected data in unauthenticated sessions</span>
	</td></tr>
	<tr><td>Maximum Time:</td><td>
		<input type='text' id='maxTimeDeltaMins' name='maxTimeDeltaMins' size='32' onchange="change_made();" oninput="change_made();" />
		<span class='small_note'>maximum number of minutes the time can be off for the verification; default is 30 minutes</span>
	</td></tr>
	<tr><td><i>Fail Duplicate Tokens</i>:</td><td>
		<label><input type='checkbox' id='failDuplicateTokenUse' name='failDuplicateTokenUse' onchange="change_made();" /> fail verification if a token is used more than once</label>
		&nbsp; <span class='small_note'>do not use this is the user can click the same link twice</span>
	</td></tr>
	<tr><td style="vertical-align: top;">Notes:</td><td>
		<i>Encryption Key/IV</i> can be input as any of:
		<ul>
		<li>hex <b>=0x58 0x1c</b>... or <b>=0x58,0x1c</b>... or <b>=58 1c</b>...</li>
		<li>decimal <b>=88 28</b>... or <b>=88,28</b>...</li>
		<li>base-64 encoded <b>=WBwTY</b>...</li>
		</ul>
	</td></tr>
	<tr><td colspan="2">
		<div id='change_happened' class='change_happened'>Changes made - press <b>Update Data</b> to save!</div>
		<div id='invalid_config' class='change_happened'>Error: Invalid configuration!</div>
	</td></tr>
</table>

</form>

<div style='text-align:center;'>
<?php
	echo'<input type=button name=add value="Update Data" class="btn btn-secondary btn-sm" id=apply_changes disabled=disabled ';
	if($revation->adminRight('ar_maincfg'))
		echo'onclick="return SharedAuth.updatedata();"';
	echo'>';
?>
<input type='button' value='Clear' class='btn btn-secondary btn-sm' onclick="return SharedAuth.cleardata();">
<input type='button' value='&#x21e6; Back' class='btn btn-dark btn-sm' onclick="window.location='embed.php?php=<?=$_SESSION['nav_back']?>&<?=$urlTokenArg?>';return false;">
</div>


<?php
include 'groupEnd.php';

include 'groupPre.php';
echo 'Test a URL';
include 'groupStart.php';
?>


<form name='config' onsubmit='return SharedAuth.verify();'>
<input type='text' id='url' name='url' style='width: 100%;' />
<br/>
<br/>
<input type='submit' value='Test URL' class='btn btn-secondary btn-sm' /> &nbsp; <input type='button' value='Clear' class='btn btn-secondary btn-sm' onclick='return SharedAuth.verify_clear();'/>
</form>
<br/>
<div id="test_results"></div>



<?php include 'groupEnd.php';?>
</form>

<?php
include 'groupEnd.php';

include 'groupPre.php';
echo 'Create a URL';
include 'groupStart.php';
?>


<form name='create' onsubmit='return SharedAuth.create();'>
Clear Parameter List &nbsp; <span class='small_note'>e.g. group=company&brand=company&im=huntgroup@company.com</span>
<input type='text' id='create_clear' name='create_clear' style='width: 100%;' />
<br/>
Encoded Parameter List &nbsp; <span class='small_note'>e.g. account=user@company.com&profile=company-guest&group=company&rwc_givenname=The&rwc_surname=User</span>
<input type='text' id='create_encode' name='create_encode' style='width: 100%;' />
<br/>
<br/>
<input type='submit' value='Create URL' class='btn btn-secondary btn-sm' /> &nbsp; <input type='button' value='Clear' class='btn btn-secondary btn-sm' onclick='return SharedAuth.create_clear();'/>
</form>
<br/>
<input type='text' id='create_results' name='create_results' style='width: 100%;' />
<br/>
<br/>
Notes on parameters:
<ul>
<li>One or more of "account", "profile", or "institution" in Encoded list is required for a valid token decode.</li>
<li>If "account" is missing, a token will not be tied to an account, even if the token is valid.</li>
<li>"profile" is only used when creating an account, and defaults to "<i>GROUP</i>-guest" if not present during create.</li>
<li>"email" is set/updated as a traditional notification email address for an account.</li>
<li>"rwc_givenname" and "rwc_surname" is set/updated as a display name for an account.</li>
</ul>


<?php include 'groupEnd.php';?>
</form>

<?php include 'tableBottom.php';?>