<?php
if($revation->groupTamperingDetected()){exit();}
$revation->config('groupcleanpolicy');
$urlTokenArg=$revation->getUrlTokenArg();
?>
<?php include 'tableTop.php';?>
<form method='post' name='f' action='embed.php?php=GroupCleaner&<?=$urlTokenArg?>'>
<input type='hidden' name='privateGroup' value="<?=htmlspecialchars($_REQUEST['privateGroup'])?>"/>
		<?php
		include 'groupPre.php';
		echo 'Group Cleaner: '.htmlspecialchars($_REQUEST['privateGroup']);
		echo"<a href='#' alt='help on this' class='btn btn-info btn-sm rev-help' onclick=\"window.open('Help/GroupCleaners.html','help','width=600,height=600,scrollbars=yes','alwaysRaised')\">&#x1f6c8; Help on this</a>";
		include 'groupStart.php';
		?>
				<table>
				<?php echo
					"<tr><td><label><input type='checkbox' name='do_ageDocs' {$revChecked['do_ageDocs']} /> handle <i>eFolder</i> documents older than:</label></td><td><input type='number' min='0' max='10000' name='ageDocs' value='".htmlspecialchars($_REQUEST['ageDocs'])."' /> days {$revChanged['ageDocs']}</td></tr>".
					"<tr><td><label><input type='checkbox' name='do_ageMail' {$revChecked['do_ageMail']} /> handle <i>mail</i> items older than:</label></td><td><input type='number' min='0' max='10000' name='ageMail' value='".htmlspecialchars($_REQUEST['ageMail'])."' /> days {$revChanged['ageMail']}</td></tr>".
					"<tr><td><label><input type='checkbox' name='do_ageVoicemail' {$revChecked['do_ageVoicemail']} /> handle <i>Voicemail</i> items older than:</label></td><td><input type='number' min='0' max='10000' name='ageVoicemail' value='".htmlspecialchars($_REQUEST['ageVoicemail'])."' /> days {$revChanged['ageVoicemail']}</td></tr>".
					"<tr><td><label><input type='checkbox' name='do_ageChats' {$revChecked['do_ageChats']} /> handle <i>Chat</i> items older than:</label></td><td><input type='number' min='0' max='10000' name='ageChats' value='".htmlspecialchars($_REQUEST['ageChats'])."' /> days {$revChanged['ageChats']}</td></tr>".
					"<tr><td><label><input type='checkbox' name='do_ageCalls' {$revChecked['do_ageCalls']} /> handle <i>Calls</i> items older than:</label></td><td><input type='number' min='0' max='10000' name='ageCalls' value='".htmlspecialchars($_REQUEST['ageCalls'])."' /> days {$revChanged['ageCalls']}</td></tr>".
					"<tr><td><label><input type='checkbox' name='do_ageAccounts' {$revChecked['do_ageAccounts']} /> handle <i>User Accounts</i> older than:</label></td><td><input type='number' min='0' max='10000' name='ageAccounts' value='".htmlspecialchars($_REQUEST['ageAccounts'])."' /> days {$revChanged['ageAccounts']}</td></tr>";
				?>
					<tr><td>Action to take:</td><td>
					<label><input type="radio" name="action" value="0" <?php if($_REQUEST['action']=='0') echo' checked="checked"';?>> Delete</label>,
					<label><input type="radio" name="action" value="1" <?php if($_REQUEST['action']=='1') echo' checked="checked"';?>> Rename prepend $</label>,
					<label><input type="radio" name="action" value="3" <?php if($_REQUEST['action']=='3') echo' checked="checked"';?>> Test mode</label>, or
					<label><input type="radio" name="action" value="2" <?php if($_REQUEST['action']=='2') echo' checked="checked"';?>> Move to: <?php echo $revChanged['action'];?></label>
					</td></tr>
					<tr><td>&nbsp;</td><td><input name='movePath' style='width: 98%;' value='<?php echo htmlspecialchars($_REQUEST['movePath']);?>'/> <?php echo $revChanged['movePath'];?></td></tr>
					<tr><td valign="top">Comments:</td><td><textarea rows='5' cols='40' name='comments'><?php echo htmlspecialchars($_REQUEST['comments']);?></textarea> <?php echo $revChanged['comments'];?></td></tr>
				</table>
		<?php include 'groupEnd.php';?>
		<div style="text-align:center;" class="mt-2">
				<?php
				if(isset($_REQUEST['readonly']))
						$isDisabled=' disabled';
				else
						$isDisabled='';
				echo'<input type="submit" name="apply" value="Apply Changes" class="btn btn-secondary btn-sm"'.$isDisabled.' />&nbsp;<input type="submit" name="cancel" value="Cancel Changes" class="btn btn-secondary btn-sm" />&nbsp;';
				echo"<input type='button' value='&#x21e6; Back' class='btn btn-dark btn-sm' onclick=\"window.location='embed.php?doc=GroupCleaners.html&".$urlTokenArg."';return false;\"/><br/>";
		echo'</div><div style="text-align:center;" class="mt-2">';
				if(isset($_REQUEST['add'])||isset($_REQUEST['name_ro']))
					$isDisabled=' disabled';
				echo'<input type="button" value="Delete Policy" class="btn btn-secondary btn-sm" '.$isDisabled.' onclick="if(confirm(\'Are you sure you want to delete this Cleaner Policy?\'))window.location=\'embed.php?doc=GroupCleaners.html&'.$urlTokenArg.'&delete&privateGroup='.urlencode($_REQUEST['privateGroup']).'\';return false;" />&nbsp;';
				echo'<input type="button" value="Clean Now" class="btn btn-secondary btn-sm" '.$isDisabled.' onclick="if(confirm(\'Are you sure you want to run this Cleaner Policy now?\'))window.location=\'embed.php?doc=GroupCleaners.html&'.$urlTokenArg.'&clean&privateGroup='.urlencode($_REQUEST['privateGroup']).'\';return false;" />&nbsp;';
				?>
		</div>
</form>
<?php include 'tableBottom.php';?>