var login_focusset = false;

function setLoginError(text) {
	if (text) {
		$('#error_area').removeClass('display_none').text(text);
	}
	else {
		$('#error_area').addClass('display_none');
	}
}

function submitJWT(jwt) {
	// send the token to the server and hopefully we get a session
	localStorage.removeItem('nonce');
	localStorage.removeItem('group');
	$("<input type='hidden' name='jwt' value='" + rwc_htmlescape(jwt) + "' />").appendTo("#sso_form");
	$("#sso_form").off('submit').submit();
}

function enableUserPswd() {
	$('#cred_display').removeClass('display_none');
	$('#user, #pswd').attr('required', 'required');
}


function cryptoRandomString(length) {
	var charset = '0123456789ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvwxyz'
	var result = '';
	if (length > 0) {
		var bytes = new Uint8Array(length);
		var crypto = window.crypto || window.msCrypto;
		var random = crypto.getRandomValues(bytes);
		for (var i = 0; i < random.length; i++) {
			result += charset[random[i] % charset.length];
		}
	}
	return result;
}


// document ready
$(function () {
	// set focus as needed
	if (!login_focusset) {
		$($('#user').val() != '' ? '#pswd' : '#user').focus();
	}

	// show any errors
	if (auth_results == 'LOGIN_LOCKED') {
		setLoginError('Sorry, too many invalid attempts has forced a temporary lockout.');
	}
	else if (auth_results == 'LOGIN_FAILED') {
		setLoginError('Sorry, invalid user name and/or password.');
	}
	else if (auth_results == 'LOGIN_DUPLICATE') {
		setLoginError('Sorry, settings prevent multiple simultaneous administrative logins; log out of other session or wait for it to time out.');
	}
	else if (auth_results == 'LOGON_TIMEOUT') {
		setLoginError('Sorry, the administration session has timed out; please log on again.');
	}

	// we might have group in local storage
	if (!group) {
		group = localStorage.getItem('group');
	}

	// add the group to our forms
	$('#cred_form input[name=group], #sso_form input[name=group]').val(group);
	if (typeof dbid === 'string' && dbid.length) {
		$('#cred_form, #sso_form').append("<input type='hidden' name='dbid' value='" + rwc_htmlescape(dbid) + "'>");
	}

	// query to see if we're doing OIDC or SAML2
	$.ajax({
		type: 'GET',
		url: 'json/sso/public?use=admin&group=' + encodeURIComponent( group ),
		async: true,
		cache: false,
		success: function (json) {
			if (!json || typeof json !== 'object') {
				enableUserPswd();
			}
			else if (typeof json.oauth2 === 'object' && json.oauth2 && typeof json.oauth2.client_id === 'string') {
				// check if we are in the response with a jwt
				var hash_parms = window.location.hash.substr(1).split('&').reduce(function (result, item) {
					var parts = item.split('=');
					result[parts[0]] = parts[1];
					return result;
				}, {});
				if (typeof hash_parms === 'object' && typeof hash_parms.id_token === 'string' && hash_parms.id_token.length) {
					// we are in a response check the nonce
					// split into header, payload and signature
					var ts = hash_parms.id_token.split('.');
					if (ts.length === 3) {
						// convert from url to normal base64
						var payload_string = atob(ts[1].replace('-', '+').replace('_', '/'));
						try {
							var payload_obj = JSON.parse(payload_string);
							if (typeof payload_obj.nonce === 'string') {
								if (localStorage.getItem('nonce') === payload_obj.nonce) {
									submitJWT(hash_parms.id_token);
									return;
								}
							}
						}
						catch (e) {
						}
					}
					hash_parms = null;
					setLoginError('Error processing the Single-Sign-On; please try again later.');
				}
				else {
					hash_parms = null;
				}
				if (!hash_parms) {
					// show the log-in dialog
					$('#form_sso').removeClass('display_none');
					if (typeof json.oauth2.form_gui === 'object') {
						if (typeof json.oauth2.form_gui.login_title === 'string') {
							$('#sso_title_area').text(json.oauth2.form_gui.login_title);
						}
						if (json.oauth2.form_gui.cred_input) {
							enableUserPswd();
						}
					}
					$('#sso_log_in_button').removeClass('display_none').on('click', function (e) {
						e.preventDefault();
						var nonce = cryptoRandomString(32);
						localStorage.setItem('group', group);
						localStorage.setItem('nonce', nonce);
						var redirect_uri = typeof json.oauth2.redirect_uri === 'string' ? json.oauth2.redirect_uri : window.location.protocol + '//' + window.location.hostname;
						// launch the sso which comes back with a jwt in the id_token
						window.location = json.oauth2.auth_uri + '?client_id=' + json.oauth2.client_id + '&nonce=' + nonce + '&scope=openid%20profile%20email&response_type=id_token&redirect_uri=' + encodeURIComponent(redirect_uri);
					});
				}
			}
			else if (typeof json.saml2 === 'object' && json.saml2) {
				// show the log-in dialog
				$('#form_sso').removeClass('display_none');
				if (typeof json.saml2.form_gui === 'object') {
					if (typeof json.saml2.form_gui.login_title === 'string') {
						$('#sso_title_area').text(json.saml2.form_gui.login_title);
					}
					if (json.saml2.form_gui.cred_input) {
						enableUserPswd();
					}
				}
				$('#sso_log_in_button').removeClass('display_none').on('click', function (e) {
					e.preventDefault();
					$.ajax({
						type: 'GET',
						url: '/json/saml2/redirect?type=administrators&group=' + encodeURIComponent(group),
						async: true,
						cache: false,
						success: function (json) {
							if (typeof json === 'object' && typeof json.results === 'string' && json.results === 'success' && typeof json.metadata === 'object') {
								// redirect to the IdP
								var url = json.metadata.Redirect_URL;
								if (url.indexOf('?') !== -1) {
									if (url.charAt(url.length - 1) != '?') {
										url += '&';
									}
								}
								else {
									url += '?';
								}
								url += 'SAMLRequest=' + encodeURIComponent(json.metadata.SAMLRequest) + '&RelayState=' + encodeURIComponent('admin');
								window.location = url;
							}
						}
					});
				});
			}
			else {
				enableUserPswd();
			}
		}
	});
});