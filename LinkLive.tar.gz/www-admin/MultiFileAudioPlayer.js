function getResourceDateStr(gmt) {
    // convert to a date object
    var d = new Date(gmt * 1000);
    if (!isNaN(d)) {
        // if it's today
        var now = new Date();
        if (d.getFullYear() == now.getFullYear() && d.getMonth() == now.getMonth() && d.getDate() == now.getDate()) {
            // output a "today" string
            return "Today, " + d.toLocaleTimeString();
        }
        else {
            // just output the date
            var s = "" + d.getFullYear() + "-";
            if (d.getMonth() + 1 < 10) {
                s += "0";
            }
            s += (d.getMonth() + 1) + "-";
            if (d.getDate() < 10) {
                s += "0";
            }
            s += d.getDate();
            return s + " " + d.toLocaleTimeString();
        }
    }
    return '';
}



function RevationAudioPlayer(playeridentifier) {
    // private members
    var nextButtonId = 1;

    // private functions; e.g. function privateFunction(index) { // no this.member required

    // privileged functions; e.g. this.privilegedFunction = function(index) { // no this.member required
    this.play = function (button, id) {
        var e = document.getElementById('rap_' + id);
        button.style.display = 'none';
        e.style.display = 'inline';
        e.play();
    };

    this.writeButton = function (file, query) {
        if (window.HTMLAudioElement) {
            try {
                var dot = file.lastIndexOf('.');
                if (dot != -1) {
                    var ext = file.substr(dot + 1);
                    var type = null;
                    if (ext == 'opus')
                        type = 'audio/ogg';
                    else
                        type = 'audio/' + ext;
                    if (type && new Audio().canPlayType(type)) {
                        if (navigator.userAgent.indexOf("iPad") != -1 || navigator.userAgent.indexOf("iPhone") != -1) {
                            document.write('<audio id="rap_' + nextButtonId + '" controls="" preload="none" src="download.php?filename=' + file + '&' + query + '"></audio>');
                        }
                        else {
                            document.write('<audio id="rap_' + nextButtonId + '" controls="" preload="none" style="display: none;" src="download.php?filename=' + file + '&' + query + '"></audio>');
                            document.write('&nbsp;<input type="button" style="display: inline;" class="btn btn-secondary btn-sm" onclick="audioPlayer.play(this,' + nextButtonId + ');" value="Play"/>');
                        }
                        nextButtonId++;
                    }
                }
            }
            catch (e) {
                // show error in developer tools if available
                if (window.console) {
                    console.error("Error:" + e);
                }
            }
        }
    };
}

// main player
var audioPlayer = new RevationAudioPlayer();