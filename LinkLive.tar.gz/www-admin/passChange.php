<?php
if(!isset($_SESSION)){
	include'/index.php';
	exit();
}
if(!$revation->adminExpired()){
	include'/index.php';
	exit();
}
if(isset($_REQUEST['pwd'])&&isset($_REQUEST['pwdc'])){
	$results=$revation->adminPassChange($_REQUEST['pwd'],$_REQUEST['pwdc']);
	if($results=='OK'){
		if(isset($_REQUEST['dbid'])||$revation->adminAccessType()!=0){
			$_REQUEST['vtop']='1';
			$_REQUEST['php']='mail/dbitem';
		}
		else if($revation->adminGlobal())
			$doc='Status.html';
		else
			$_REQUEST['php']='users';
		include 'embed.php';
		exit();
	}
$urlTokenArg=$revation->getUrlTokenArg();
}
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>LinkLive</title>
  <script type="text/javascript">
	focusset = false;
  </script>
<link rel='stylesheet' href='js/bootstrap.min.css' type='text/css'/>
<link rel='stylesheet' href='skin.css' type='text/css' />
<script type='text/javascript'>
function idleTooLong(s){
  window.location='logout.php?LOGON_TIMEOUT&session='+s;
}
var idleTid=null;
function idleReset(){
  if(idleTid)
	clearTimeout(idleTid);
  idleTid=setTimeout("idleTooLong('<?=$_SESSION?>')",<?=$revation->adminTimeout()?> * 1000);
}
idleReset();
</script>
</head>
<body class='login-body light-background' style='display: none; width: 100%; height: 100%;'>
<script type="text/javascript"> 
if (self == top) {
	var theBody = document.getElementsByTagName('body')[0];
	theBody.style.display = "block";
} else { 
	top.location = self.location; 
}
</script>
<div class="login-copy">&copy; 2023 LinkLive</div>

<div class="container-login">
	<div class="branding-login"><img src="imgs/logo-sm.png" alt="LinkLive 9"></div>

	<form method='post' name='form' action='passChange.php?<?=$urlTokenArg?>'>
	<div class='login-form'>
		<div class='login'>Password Change Required!</div>
		<div class='login_field_desc'>User Name</div>
		<div class='login_field'><?=$revation->adminUsername()?></div>
		<div class='login_field_desc' style="color: red;"><?php
		if($results=='INV_MATCH')
			echo'The password fields did not match!<br/>';
		if($results=='INV_POLICY')
			echo'The password did not meet policy!<br/>'.$revation->adminPolicy().'<br/>';
		echo'This password has expired and you must change it now!';
		?></div>
		<div class='login_field_desc'>New Password</div>
		<div class='login_field'><input type='password' required='required' placeholder='new password' name='pwd' id='pwd' tabindex='1' autofocus='autofocus' onchange='idleReset();'></div>
		<div class='login_field_desc'>Confirm New Password</div>
		<div class='login_field'><input type='password' required='required' placeholder='confirm new password' name='pwdc' id='pwdc' tabindex='2' onchange='idleReset();'></div>
		<div class='login_field_desc'>
			<input style='min-width:6em;' type='submit' value='Submit' class='btn btn-primary btn-sm' tabindex='3'>
		</div>
	</div>

	<?php
		if(isset($_REQUEST['dbid']))
			echo '<input type="hidden" name="dbid" value="'.htmlspecialchars($_REQUEST['dbid']).'"/>';
	?>
	</form>
</div>

</body>
</html>