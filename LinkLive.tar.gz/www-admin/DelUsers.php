<?php
include 'tableTop.php';
$urlTokenArg=$revation->getUrlTokenArg();
?>

<div id="userRightsDialog" style="display: none;" title="User Rights">
</div>

<script type="text/javascript">
var privateGroup = "<?php echo $revation->adminGroup();?>";
</script>
<script type="text/javascript" src="DelUsers.js"></script>

<div class='legend'>Deleted Users for <?php echo $revation->adminGroup();?></div>
<table cellpadding="0" cellspacing="0" border="0" class="display table-striped table-bordered nowrap w-100" id="main_data_table">
  <thead>
    <tr>
      <th title="Location of the Delete Folder">Folder</th>
      <th title="Account associated to the Deleted Folder">Account</th>
      <th title="Last Modification Time of the Account">Modified</th>
      <th>&nbsp;</th>
    </tr>
  </thead>
  <tfoot>
    <tr>
      <th>&nbsp;</th>
      <th>&nbsp;</th>
      <th>&nbsp;</th>
    </tr>
  </tfoot>
</table>
<br/>
<input type='button' value='&#x21e6; Back' class='btn btn-dark btn-sm' onclick="window.location='embed.php?php=Tools&<?=$urlTokenArg?>';return false;">

<?php include 'tableBottom.php';?>