<?php
header('Location: https://'+urlencode($_REQUEST['server'])+'/examples/presence.php?'+$revation->getUrlTokenArg()+'&'+$_SERVER['QUERY_STRING']);
?>