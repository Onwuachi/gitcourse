<?php
include 'tableTop.php';
$urlTokenArg=$revation->getUrlTokenArg();
$file_changes=$revation->config('telRouting');
?>

<script type="text/javascript">
//<![CDATA[
var dataTable = null;
<?php
echo'var is_global='.json_encode($revation->adminGlobal()).';';
echo'var view_only='.json_encode($revation->adminPrivateView()).';';
?>

function renderButton( data, type, full ) {
	if(type=='display'){
		// delete button
		var b = '<input type=button value=delete class="btn btn-secondary btn-sm"';
		if(view_only) {
			b +=' disabled=disabled';
		}
		else {
			b +=' onclick="return deleteItem(\''+rwc_htmlescape(full[0])+'\',\''+rwc_htmlescape(full[1])+'\')"';
		}
		b += '>';
		return b;
	}
	else {
		return data;
	}
}

function loadTable(parms){
	$.ajax({
		type: 'GET',
		url: 'json/telRouting?<?=$urlTokenArg?>',
		async: true,
		cache: false,
		data: parms,
		success: function (json) {
			let data = [];
			if (json.routing){
				if(is_global) {
					for(let i=0;i<json.routing.length;i++){
						data.push( [ json.routing[i].n, json.routing[i].g, null ] );
					}
				}
				else if(!view_only){
					for(let i=0;i<json.routing.length;i++){
						data.push( [ json.routing[i], null ] );
					}
				}
				else {
					for(let i=0;i<json.routing.length;i++){
						data.push( [ json.routing[i] ] );
					}
				}
			}

			if (dataTable == null) {
				let config = {
					"aaData": data,
					"bAutoWidth":false,
					responsive: true,
					"oLanguage": {
						"sEmptyTable": "(none set)"
					},
					"aoColumns": [
						{"sTitle": "Number", "mRender": $.fn.dataTable.render.text(), responsivePriority: 1}
					]
				};
				if(is_global){
					config.aoColumns.push({"sTitle": "Group", "mRender": $.fn.dataTable.render.text()});
				}
				if(!view_only){
					config.aoColumns.push({"sTitle": "&nbsp;", "mRender": renderButton});
				}
				tableConfigLoad("smsres", config);
				dataTable = $('#main_data_table').dataTable(config);
			}
			else {
                dataTable.fnClearTable();
                if (data.length) {
                    dataTable.fnAddData(data);
                }
			}
		}
	});
}

$(document).ready(function(){
	if(!view_only){
		$('#info,#number,#number_add_btn,#config,#upload').removeClass('display_none');
	}
	loadTable();
});

$(window).on('unload',function() {
	tableConfigStore("smsres",dataTable.fnSettings());
});

function addNumber(){
	let pg=$('select[name="pg"]');
	if(pg.val()==='*'){
		alert('You must select a private group for the number!');
	}
	else{
		let num=$("#number").val();
		if(num && num.length){
			$("#number").val("");
			let params='add='+encodeURIComponent(num);
			if(pg.length){
				params+='&pg='+encodeURIComponent(pg.val());
			}
			loadTable(params);
		}
	}
}

function deleteItem(n,g) {
	$('#delete_id').text(n);
	$("#delete_input_id").attr('onclick', 'loadTable(\'del='+encodeURIComponent(n)+'&pg='+encodeURIComponent(g)+'\');$(\'#del_dialog\').modal(\'hide\');');

	let dlg = $('#del_dialog');
	dlg.modal('show');
}
//]]>
</script>

<div class='legend'>Telephone Group Routing <?php echo $revation->adminGroup();?></div>
<table cellpadding="0" cellspacing="0" border="0" class="display table-striped table-bordered nowrap w-100" id="main_data_table"></table>
<br/>
  <div style='text-align:center;' class='small_note'>
    Incoming Calls and SMS messages <span style='text-decoration: underline;'>to these numbers </span> will be routed into the group.
	<br/>
	Outgoing Calls and SMS messages <span style='text-decoration: underline;'>from these numbers </span> will be allowed from the group.
  </div>
<div style='text-align:center;' id='info' class='display_none'>
  <a class="btn btn-light btn-block service_accordion" data-toggle="collapse" href="#formatting_accordion" role="button" aria-controls="formatting_accordion" aria-expanded="false" style="text-align: left; font-weight: 500;" >formatting<span></span></a>
  <div id="formatting_accordion" class="collapse">
  <div style='font-size: smaller;'>
    Valid chars are: <span class="valch">0123456789*#</span>
    <br/>
    Visual separators are ignored: <span class="valch">+SPACE-.()/</span>
    <br/>
	Multiple numbers can be entered at once using a comma or semicolon separator.
    <br/>
	When uploading a .CSV file, prepend a line with a tilde (~) to delete the number.
  </div>
  </div>
<textarea name="number" id="number" rows="1" cols="40" class="display_none"></textarea>
<?php if($revation->adminGlobal()){
	$_REQUEST['pg']='*';
	echo' in group '.$revation->control('group_select');
}
?>
<br/>
<input type=button name=add id="number_add_btn" value="Add Number" class="btn btn-secondary btn-sm display_none" onclick="addNumber();return false;">
<input type=button name=add id="config" value="Configure..." class="btn btn-secondary btn-sm display_none" onclick="window.location='embed.php?php=SMSConfig&<?=$urlTokenArg?>';return false;">
</div>

<div style="text-align:center;" class="mt-2">
    <form method='post' action="embedalone.php?doc=TelephoneGroupRouting.csv&<?=$urlTokenArg?>" target='_blank' style='display: inline;'>
    <input type="hidden" name="pg" value="<?=$revation->adminGroup()?>" />
    <input type="submit" name="save" value="Download .CSV" class="btn btn-secondary btn-sm" />
    </form>
    <form method='post' id="form_upload" action='embed.php?php=TelephoneGroupRouting&<?=$urlTokenArg?>' enctype='multipart/form-data' style='display: inline;'>
    <input type="hidden" name="pg" value="<?=$revation->adminGroup()?>" />
	<label id="upload" class="btn btn-secondary btn-sm display_none" style="margin-bottom: 0;">
    <input hidden title='Upload .CSV' type='file' name='filename' id='uploadButton' onchange='if(this.value){if(this.value.search(/\.csv/i)==-1){alert("file not of correct extension!");this.form.reset();return false;}else{this.form.submit();return true;}}' />
	Upload .CSV...
	</label>
    </form>
	<button class='btn btn-dark btn-sm' onclick="window.location='embed.php?doc=Config.html&<?=$urlTokenArg?>';return false;">&#x21e6; Back</button>
	<?php if($file_changes)echo'<br/>'.$file_changes;?>
</div>


<div class="modal fade text-center" id="del_dialog" role="dialog">
    <div class="modal-dialog" role="document" style="padding-top: 15%; text-align: left; max-width: 100%; width: auto !important; display: inline-block;">
        <div class="modal-content" style="overflow: auto;">
            <div class="modal-header light-background">
                <h5 class="modal-title">Delete Number</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete the number '<span id='delete_id' style="font-weight: bold;"></span>'?</p>
                <div style="text-align: center;">
                    <input id="delete_input_id" type=button value=Delete class='btn btn-secondary btn-sm' />
                    <input type=button value=Cancel class='btn btn-secondary btn-sm' data-dismiss="modal" />
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'tableBottom.php';?>