<?php
$revation->config('huntGroup');
include 'tableTop.php';
$urlTokenArg=$revation->getUrlTokenArg();
?>

<style>
.ui-button .ui-button-text {
	line-height: 1.0;
}
</style>
<script>

var huntGroups = null;
var dataTable = null;

function renderPID( data, type, full ) {
	if(type=='display'){
		var html = '<div class="dropdown">' +
			'<button class="btn btn-secondary btn-xs" id="menub-'+data+'" data-toggle="dropdown" title="Menu for '+rwc_htmlescape(huntGroups[data].huntgroup)+'" href="#">&#x2699;</button>' +
			'</div>'+
			'<a href="embed.php?doc=Group.html&<?=$urlTokenArg?>&edit='+encodeURIComponent(huntGroups[data].huntgroup)+'&pg='+encodeURIComponent(huntGroups[data].group)+'"';
		if(full[0]=='offline'){
			html += ' style="color: Red;"';
		}
		html += '>'+ rwc_htmlescape(huntGroups[data].huntgroup) + '</a>';
		return html;
	}
	else {
		return huntGroups[data].huntgroup;
	}
}

function renderStatus( data, type, full ) {
	if(type=='display'){
		return statusImage(data);
	}
	else {
		return data;
	}
}

function renderTotal( data, type, full ) {
	if(type=='display'){
		return '<button class="btn btn-secondary btn-xs" onclick="window.location=\'embed.php?doc=GroupActive.html&<?=$urlTokenArg?>&hg='+huntGroups[full[1]].huntgroup+'&pg='+huntGroups[full[1]].group+'\';return false;">'+data+'</button>';
	}
	else {
		return data;
	}
}

function closeMenus(){
  if(!huntGroups)
    return;
	for(var i=0;i<=huntGroups.length;++i){
		$('#menu-'+i).css('display','none');
	}
}

function openPopup(event,i) {
	closeMenus();
	event.stopImmediatePropagation();
	var mb=$('#menub-'+i);
	var m=$('#menu-'+i);

	if (m.length) {
		m.remove();
		closeMenus();
	}
	else {
		var html=
			'<ul id="menu-'+i+'" class="dropdown-menu" role="menu" onclick="closeMenus();">'+
			'<li class="dropdown-header menu-header">Hunt Group</li>'+
			'<li class="dropdown-item addCursorPointer hover" onclick="closeMenus(); window.location=\'embed.php?php=Agents&<?=$urlTokenArg?>&hg='+encodeURIComponent(huntGroups[i].huntgroup)+'&pg='+encodeURIComponent(huntGroups[i].group)+'\';return false;\">Agents</li>'+
			'<li class="dropdown-item addCursorPointer hover" onclick="closeMenus(); window.location=\'embed.php?doc=Group.html&<?=$urlTokenArg?>&edit='+encodeURIComponent(huntGroups[i].huntgroup)+'&pg='+encodeURIComponent(huntGroups[i].group)+'\';return false;\">Settings</li>'+
			'<li class="dropdown-item addCursorPointer hover" onclick="closeMenus(); window.location=\'embed.php?doc=GroupActive.html&<?=$urlTokenArg?>&hg='+encodeURIComponent(huntGroups[i].huntgroup)+'&pg='+encodeURIComponent(huntGroups[i].group)+'\';return false;">Activity</li>'+
			'<li class="dropdown-item addCursorPointer hover"><a data-href="/gen/GroupQuickReport.html?pid='+encodeURIComponent(huntGroups[i].huntgroup)+'&pg='+encodeURIComponent(huntGroups[i].group)+'" >Quick Report</a></li>';
		if(huntGroups[i].userRestricted){
			html+='<li class="dropdown-item" onclick="closeMenus();">User</li>';
		}
		else {
			html+=userAccountPopupMenu(huntGroups[i].group,huntGroups[i].huntgroup);
		}
		html += '</ul>';

		$(function() {
			$('a:contains("Quick Report")').click(function(){
				closeMenus();
				window.open($(this).data('href'));
				location.reload();
			});
		});

		mb.after(html);
		$('#menu-'+i).click(function (e) { e.stopPropagation(); }).dropdown().css('display', 'block');
	}
}

function loadTable() {
	idleReset();
	$.ajax({
		type: 'GET',
    url: 'json/huntGroups?<?=$urlTokenArg?>',
		async: true,
		cache: false,
		data: 'grouping=*',
		success: function (json) {
			if (json.huntGroups){
				huntGroups = json.huntGroups;
				var data = [];
				for(var i=0;i<huntGroups.length;i++){
					var hg = huntGroups[i];
					data.push( [ 
						hg.status, 
						i, 
						hg.display, 
						hg.grouping, 
						hg.priority, 
						hg.mail,
						hg.pending, 
						hg.auto, 
						hg.queued, 
						hg.active, 
						hg.outbound, 
						hg.wrapup,
						hg.pending + hg.auto + hg.queued + hg.active + hg.outbound + hg.wrapup 
					] );
				}
				if ( dataTable == null ) {
					var config = {
						"aaData": data,
						"aaSorting":[[1,"asc"]],
						"bAutoWidth":false,
						responsive: true,
						"aoColumns": [
							{ /* "Status" */ "bSearchable": false, "sClass": "right", "sWidth": "14px", "mRender": renderStatus },
							{ /* "Presence Id" */ "sClass": "nowrapellipsis", "mRender": renderPID, responsivePriority: 1 },
							{ /* "Display" */ "mRender": $.fn.dataTable.render.text() },
							{ /* "Grouping" */ "bVisible": false, "mRender": $.fn.dataTable.render.text() },
							{ /* "Priority" */ "bSearchable": false, "bVisible": false, "sClass": "right" },
							{ /* "Mail */ "bSearchable": false, "sClass": "right" },
							{ /* "Pend */ "bSearchable": false, "sClass": "right" },
							{ /* "Auto */ "bSearchable": false, "sClass": "right" },
							{ /* "Queue */ "bSearchable": false, "sClass": "right" },
							{ /* "Active */ "bSearchable": false, "sClass": "right" },
							{ /* "Out */ "bSearchable": false, "sClass": "right" },
							{ /* "Wrap */ "bSearchable": false, "sClass": "right" },
							{ /* "Load */ "bSearchable": false, "mRender": renderTotal, "sClass": "right" }
						],
						"fnFooterCallback": function ( nRow, aaData, iStart, iEnd, aiDisplay ) {
							// do total for only what's displayed
							var mail = 0;
							var pending = 0;
							var auto = 0;
							var queued = 0;
							var active = 0;
							var outbound = 0;
							var wrap = 0;
							for ( var i=0; i<aiDisplay.length; i++ ) {
								var hg = huntGroups[aiDisplay[i]];
								mail += hg.mail;
								pending += hg.pending;
								auto += hg.auto;
								queued += hg.queued;
								active += hg.active;
								outbound += hg.outbound;
							}
							
							var p=0;
							var s=this.fnSettings();
							for (var iCol=0;iCol<5;iCol++){
								if(s.aoColumns[iCol].bVisible){
									p++;
								}
							}
							var nCells = nRow.getElementsByTagName('th');
							nCells[p++].innerHTML = '' + mail;
							nCells[p++].innerHTML = '' + pending;
							nCells[p++].innerHTML = '' + auto;
							nCells[p++].innerHTML = '' + queued;
							nCells[p++].innerHTML = '' + active;
							nCells[p++].innerHTML = '' + outbound;
							nCells[p++].innerHTML = '' + wrap;
							nCells[p++].innerHTML = '' + ( pending + auto + queued + active + outbound + wrap );
						},
						"fnInfoCallback": function( oSettings, iStart, iEnd, iMax, iTotal, sPre ) {
							for(var row=iStart-1;row<iEnd;++row){
								var i=oSettings.aiDisplay[row];
								$('#menub-'+i).click(function(i){
									return function(event){
										openPopup(event,i);
									}
								}(i));
							}
							return sPre;
						}
					};
					tableConfigLoad("groups", config);
					dataTable = $('#main_data_table').dataTable(config);
				}
				else {
					dataTable.fnClearTable();
					if (data.length) {
						dataTable.fnAddData( data );
					}
				}
			}
		}
	});
}

$(document).ready(function(){
	loadTable();
});

$(document).on('click',function(){
	$('ul[id^="menu-"]').remove();
});

$(window).on('unload',function() {
	tableConfigStore("groups",dataTable.fnSettings());
});

function showColumn(_this,e){
	e.preventDefault();
	var iCol = $(_this).attr('data-column');
	var bVis = dataTable.fnSettings().aoColumns[iCol].bVisible;
	dataTable.fnSetColumnVis( iCol, bVis ? false : true );
}
//# sourceURL=Groups.php.js
</script>

<div class='legend'>Hunt Groups</div>
<table cellpadding="0" cellspacing="0" border="0" class="display table table-striped table-bordered nowrap" id="main_data_table" style="padding-top:2em;">
<thead><tr>
	<th><div class="head_rot" title="Status of the Hunt Group">Status</div></th>
	<th title="Presence Id of the Hunt Group Account">Presence Id</th>
	<th title="Display of Hunt Group Account">Display</th>
	<th title="Optional Name(s) of Groups of Hunt Groups">Grouping</th>
	<th><div class="head_rot" title="Priority of this Hunt Group versus others">Priority</div></th>
	<th><div class="head_rot" title="Mail Messages Waiting">Mail</div></th>
	<th><div class="head_rot" title="Chat Sessions Pending Initial Customer Input">Pending</div></th>
	<th><div class="head_rot" title="Sessions getting Automatically Handled (IVR) and not in Queue">Auto</div></th>
	<th><div class="head_rot" title="Sessions Awaiting Agents in Queue">Queue</div></th>
	<th><div class="head_rot" title="Inbound Sessions Actively with Agents">Active</div></th>
	<th><div class="head_rot" title="Outbound Sessions Actively with Agents">Outbound</div></th>
	<th><div class="head_rot" title="Sessions in Wrap-Up State with Agents">Wrapup</div></th>
	<th><div class="head_rot" title="Total Session Load on the Hunt Group">Load</div></th>
</tr></thead>
<tfoot><tr>
	<th>&nbsp;</th>
	<th class='colselect'>show:
		<a data-column='2' onclick='showColumn(this,event);'>Display</a>
		<a data-column='3' onclick='showColumn(this,event);'>Grouping</a>
		<a data-column='4' onclick='showColumn(this,event);'>Priority</a>
	</th>
	<th>&nbsp;</th>
	<th>&nbsp;</th>
	<th>&nbsp;</th>
	<th>0</th>
	<th>0</th>
	<th>0</th>
	<th>0</th>
	<th>0</th>
	<th>0</th>
	<th>0</th>
	<th>0</th>
</tr></tfoot>
</table>
<br/>
<div style='text-align:center;'>
<input type=button value=Reports class='btn btn-secondary btn-sm' onclick="window.location='embed.php?doc=HuntGroupReports.html&<?=$urlTokenArg?>';return false;">
<input type=button value='MMP Access' class='btn btn-secondary btn-sm' onclick="window.location='embed.php?doc=ReportAccess.html&<?=$urlTokenArg?>';return false;">
<input type=button value='Schedules' class='btn btn-secondary btn-sm' onclick="window.location='embed.php?doc=HuntGroupSchedules.html&<?=$urlTokenArg?>';return false;">
<input type=button value='Groupings' class='btn btn-secondary btn-sm' onclick="window.location='embed.php?doc=HuntGroupGroupings.html&<?=$urlTokenArg?>';return false;">
<input type=button name=add value="All Agents" class='btn btn-secondary btn-sm' onclick="window.location='embed.php?php=AgentsAll&<?=$urlTokenArg?>';return false;">
</div>
<div style='text-align:center;' class='mt-2'>
<?php
if($revation->adminGlobalView()){
	echo'<input type=button value="Queue Options" class="btn btn-secondary btn-sm" ';
	if($revation->adminRight('ar_huntgroups'))
		echo'onclick="window.location=\'embed.php?doc=QueueService.html&'.$urlTokenArg.'\';return false;"';
	else
		echo'disabled';
	echo'> <input type="button" name="add" value="Add New Hunt Group" class="btn btn-secondary btn-sm" ';
	if($revation->adminRight('ar_huntgroups'))
		echo'onclick="window.location=\'embed.php?php=NewService&'.$urlTokenArg.'&type=hg&add\';return false;"';
	else
		echo'disabled';
	echo'> ';
}?>
<input type=button value="Refresh" class='btn btn-secondary btn-sm' onclick="loadTable();return false;">
</div>

<?php include 'tableBottom.php';?>