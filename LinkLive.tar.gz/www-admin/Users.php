<?php
include 'tableTop.php';
$urlTokenArg=$revation->getUrlTokenArg();
?>

<link rel='stylesheet' href='common/datechooser.css' type='text/css'>
<script type="text/javascript" src="common/datechooser.js"></script>

<script>

var users = null;
var dataTable = null;

function closeMenus(){
	if(!users)
		return;
	for(var i=0;i<=users.length;++i){
		$('#menu-'+i).css('display','none');
	}
}

function renderStatus( data, type, full ) {
	if(typeof data=='string'){
		if(type=='display'){
			return statusImage(data);
		}
		else {
			return data;
		}
	}
	else {
		return '';
	}
}

function renderPID( data, type, full ) {
	if(typeof data=='number'){
		if(type=='display'){
			var html = '<div class="dropdown">' +
				'<button class="btn btn-secondary btn-xs" id="menub-'+data+'" data-toggle="dropdown" title="Menu for '+rwc_htmlescape(users[data].pid)+'" href="#">&#x2699;</button>' +
				'</div>';
			html += '<a href="embed.php?doc=UserEdit.html&amp;'+getUrlTokenArg()+'&amp;edit='+encodeURIComponent(users[data].pid)+'&amp;privateGroup='+encodeURIComponent(users[data].pg)+'">' + rwc_htmlescape(users[data].pid) + '</a>';
			return html;
		}
		else {
			return users[data].pid;
		}
	}
	else {
		return '';
	}
}

function renderProfile( data, type, full ) {
	if(typeof data=='string'){
		if(type=='display'){
			return '<a href="embed.php?doc=ProfileAdd.html&amp;'+getUrlTokenArg()+'&amp;edit='+encodeURIComponent(data)+'">' + rwc_htmlescape(data) + '</a>';
		}
		else {
			return data;
		}
	}
	else {
		return '';
	}
}

function openPopup(event,i) {
	closeMenus();
	event.stopImmediatePropagation();
	var mb=$('#menub-'+i);
	var m=$('#menu-'+i);

	if (m.length) {
		m.remove();
	}
	else {
		var html='<ul id="menu-'+i+'" class="dropdown-menu" onclick="closeMenus();">';

		if(users[i].userRestricted){
			html+='<li class="dropdown-header menu-header">User</li>';
		}
		else {
			html+=userAccountPopupMenu(users[i].pg,users[i].pid);
		}
		html += '</ul>';
		mb.after(html);
		$('#menu-'+i).click(function (e) { e.stopPropagation(); }).dropdown().css('display', 'block');
	}
}

function loadTable(commands) {
	idleReset();
	$.ajax({
		type: 'GET',
    url: 'json/users?<?=$urlTokenArg?>',
		async: true,
		cache: false,
		data: commands,
		success: function (json) {
			if (json.users){
				users = json.users;
				var data = [];
				$('#results_truncated').css('display',(typeof json.results_truncated=='boolean'&&json.results_truncated)?'':'none');
				for(var i=0;i<users.length;i++){
					var user = users[i];
					data.push( [
						user.status,
						i,
						user.fname,
						user.lname,
						user.profile,
						user.tel,
						user.comments ? rwc_htmlescape(user.comments) : null
						] );
				}
				if ( dataTable == null ) {
					var config = {
						"aaData": data,
						"aaSorting":[[1,"asc"]],
						"bAutoWidth":false,
						responsive: true,
						"aoColumns": [
							{ /* "Status" */ "bSearchable": false, "sClass": "right", "sWidth": "14px", "mRender": renderStatus },
							{ /* "Presence Id" */ "sClass": "nowrapellipsis", "mRender": renderPID, responsivePriority: 1 },
							{ /* "First" */ "mRender": $.fn.dataTable.render.text() },
							{ /* "Last" */ "mRender": $.fn.dataTable.render.text() },
							{ /* "Profile" */ "mRender": renderProfile },
							{ /* "Telephone" */ "bVisible": false, "mRender": $.fn.dataTable.render.text() },
							{ /* "Comments" */ "bVisible": false, "mRender": $.fn.dataTable.render.text() }
						],
						"fnInfoCallback": function( oSettings, iStart, iEnd, iMax, iTotal, sPre ) {
							for(var row=iStart-1;row<iEnd;++row){
								var i=oSettings.aiDisplay[row];
								$('#menub-'+i).click(function(i){
									return function(event){
										openPopup(event,i);
									}
								}(i));
							}
							return sPre;
						}
					};
					tableConfigLoad("users", config);
					dataTable = $('#main_data_table').dataTable(config);

					// set up column searching
					dataTable.api().columns().every( function () {
						var that = this;
						$( 'input', this.footer() ).on( 'keyup change', function () {
							if ( that.search() !== this.value ) {
								that.search( this.value ).draw();
							}
						} );
					} );
				}
				else {
					dataTable.fnClearTable();
					if(data.length) {
						dataTable.fnAddData( data );
					}
				}
			}
		}
	});
}

var search_items = ['profile','key','first','last','user','tel','cid','cid911','mac','loc','comment','exdt_from','exdt_to'];

// set in any stored search criteria
$(document).ready(function(){
	var show = false;
	if(typeof(Storage)!=="undefined"){
		for (var i=0; i<search_items.length; i++) {
			if(v = sessionStorage.getItem('users_'+search_items[i])){
				if ( v!='*' || i >= 2 ) {
					$("#advanced_filter :input[name="+search_items[i]+"]").val(v);
					show = true;
				}
			}
		}
	}
	if ( show ) {
		advancedDisplay();
	}
	refreshData();
});

$(document).on('click',function(){
	$('ul[id^="menu-"]').remove();
});

$(window).on('unload',function() {
	tableConfigStore("users",dataTable.fnSettings());
	if(typeof(Storage)!=="undefined"){
		for (var i=0; i<search_items.length; i++) {
			sessionStorage.setItem( 'users_'+search_items[i], $("#advanced_filter :input[name="+search_items[i]+"]").val() );
		}
	}
});

function refreshData() {
	var f = $("#advanced_filter_display");
	if ( f.css("display")!="none" ) {
		loadTable("advanced&"+$("#advanced_filter").serialize());
	}
	else {
		loadTable();
	}
	return false;
}

function advancedDisplay() {
	var f = $("#advanced_filter_display");
	if ( f.css("display")=="none" ) {
		f.css("display","block");
		$("#advanced_filter_toggle").html('&#x25BC;');
	}
	else {
		f.css("display","none");
		$("#advanced_filter_toggle").html('&#x25B6;');
		$("#advanced_filter")[0].reset();
		$("#advanced_filter :input[name=profile]").val('*');
		loadTable("resetadv");
	}
	return false;
}

//# sourceURL=Users.php.js
</script>

<div class='legend'>Users</div>
<table cellpadding="0" cellspacing="0" border="0" class="display table-striped table-bordered nowrap w-100" id="main_data_table" style="padding-top:2em;">
<thead><tr>
	<th><div class="head_rot" title="Status of the User">Status</div></th>
  <th title="Presence Id of the User Account">Presence Id</th>
  <th title="First Name of the User">First</th>
  <th title="Last Name of the User">Last</th>
  <th title="Profile the User belongs to">Profile</th>
  <th title="Telephone Route Destinations of the User">Telephone</th>
  <th title="Comments about the User Account">Comments</th>
</tr></thead>
	<tfoot>
		<tr>
			<th></th>
			<th><input type="text" placeholder="Search PIDs" /></th>
			<th><input type="text" placeholder="Search First" /></th>
			<th><input type="text" placeholder="Search Last" /></th>
			<th><input type="text" placeholder="Search Profiles" /></th>
			<th><input type="text" placeholder="Search Tel" /></th>
			<th><input type="text" placeholder="Search Comments" /></th>
		</tr>
		<tr style="display: none;" id="results_truncated">
			<td colspan="7" style="text-align: center;" class="hilight_red">Results truncated!</td>
		</tr>
	</tfoot>
</table>


<div class='legend'><a href='#' style='text-decoration: none; color: inherit;' onclick='return advancedDisplay();'><span id='advanced_filter_toggle'>&#x25B6;</span> Advanced Filter</a></div>

<form id='advanced_filter' onsubmit="return refreshData();">
<div id='advanced_filter_display' style='display: none;'>
<table>
<tr><td>Account:</td><td><input type=text name=key maxlength=120 size=40></td></tr>
<tr><td>First Name:</td><td><input type=text name=first maxlength=40 size=40></td></tr>
<tr><td>Last Name:</td><td><input type=text name=last maxlength=40 size=40></td></tr>
<tr><td>User Name:</td><td><input type=text name=user maxlength=40 size=40></td></tr>
<tr><td>Telephone Route:</td><td><input type=text name=tel maxlength=40 size=40></td></tr>
<tr><td>Telephone Caller ID:</td><td><input type='text' name='cid' size='16' pattern='[0-9]{0,16}' title='caller phone number, numbers only'/></td></tr>
<tr><td>Telephone Caller ID 911:</td><td><input type='text' name='cid911' size='16' pattern='[0-9]{0,16}' title='caller emergency phone number, numbers only'/></td></tr>
<tr><td>Telephone MAC:</td><td><input type=text name=mac maxlength=104 size=20></td></tr>
<tr><td>Location:</td><td><input type=text name=loc maxlength=40 size=40></td></tr>
<tr><td>Comment:</td><td><input type=text name=comment maxlength=120 size=40></td></tr>
<tr><td>Last Authenticated:</td><td>
	from: <span id="datechooser_from"><a id="datelink_from" href="#"><img src="imgs/datechooser.png"/></a><input name="exdt_from" id="exdt_from" type="text" size="10" maxlength="10"/></span>
	to: <span id="datechooser_to"><a id="datelink_to" href="#"><img src="imgs/datechooser.png"/></a><input name="exdt_to" id="exdt_to" type="text" size="10" maxlength="10"/></span>
</td></tr>
<?php
echo'<tr><td>Profile Name:</td><td>'.$revation->control('profile_search').'</td></tr>';
if(!$revation->adminGlobal())
	echo $revation->externalRightsHtml();
?>
	<tr>
		<td>&nbsp;</td>
		<td>
			<input type='button' style='min-width:6em;' value='Reset' class='btn btn-secondary btn-sm' onclick='return advancedDisplay();'>
				&nbsp;<input type='submit' value="Search" class='btn btn-secondary btn-sm'>
		</td>
	</tr>
	<tr>
		<td colspan='2' class='small_note'>Advanced Filter runs a search on the server; the top Search field searches only within existing results.</td>
	</tr>
</table>
</div>

<br/>
<?php
	echo'<input type=button value="Add User" class="btn btn-secondary btn-sm" ';
	if($revation->adminRight('ar_users'))
		echo'onclick="window.location=\'embed.php?doc=UserAdd.html&'.$urlTokenArg.'\';return false;"';
	else
		echo'disabled';
	echo'>';
?>
<input type=submit value="Refresh" class='btn btn-secondary btn-sm' onclick="return refreshData();">
</form>

<script>
	function setpicker(id) {
			var ndExample1 = document.getElementById('datechooser'+id);
			ndExample1.DateChooser = new DateChooser();
			if (!ndExample1.DateChooser.display) {
					return false;
			}
			ndExample1.DateChooser.setCloseTime(350);
			ndExample1.DateChooser.setUpdateFunction(function (objDate) {
					document.getElementById('exdt' + id).value = objDate.getPHPDate('m/d/Y');
					return true;
			});
			document.getElementById('datelink' + id).onclick = function () {
					var d = Date.parse(document.getElementById('exdt' + id).value);
					if (d) {
							ndExample1.DateChooser.setSelectedDate(new Date(d));
					}
					ndExample1.DateChooser.display();
			}
	}
	setpicker('_from');
	setpicker('_to');
</script>

<?php include 'tableBottom.php';?>