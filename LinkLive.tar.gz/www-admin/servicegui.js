﻿// session object must be defined for audio playback (inst,pid,pg)
// config object will be the existing configuration, if set
// resourceFiles will be any available resources for the document

var fileCurrentlyPlaying = null;



function fileStop() {
    if (fileCurrentlyPlaying) {
        fileSelect(fileCurrentlyPlaying);
        fileCurrentlyPlaying = null;
    }
}



function fileSelect(id) {
    var file = $('#' + id + ' option:selected').val();
	if (typeof file !== 'undefined') {
		var dot = file.lastIndexOf('.');
		var player = '';
		if (dot != -1) {
			var ext = file.substr(dot + 1);
			var type = null;
			if (ext == 'opus')
				type = 'audio/ogg';
			else
				type = 'audio/' + ext;
			if (type && new Audio().canPlayType(type)) {
                player = "<button class='btn btn-secondary btn-sm' onclick='filePlay(\"" + id + "\")'>play</button>";
			}
		}
		$('#' + id + '_player').html(player);
	}
}



function filePlay(id) {
    fileStop();
    fileCurrentlyPlaying = id;
    var file = $('#' + id + ' option:selected').val();
    var dot = file.lastIndexOf('.');
    if (dot != -1) {
        var ext = file.substr(dot + 1);
        var type = null;
        if (ext == 'opus')
            type = 'audio/ogg';
        else
            type = 'audio/' + ext;
        if (session && type && new Audio().canPlayType(type)) {
            var query = 'download.php?filename=' + file + '&edit=' + encodeURIComponent(session.pid) + '&' + getUrlTokenArg() + '&cmd=download-' + session.type + '&translate=8k16bm&pg=' + encodeURIComponent(session.group);
            var player = '<audio id="' + id + '_ap" controls="" src="' + query + '" autoplay></audio>';
            $('#' + fileCurrentlyPlaying + '_player').html(player);
        }
    }
}



function getConfigValues() {
    var config = {};
    for (var i = 0; i < config_defaults.length; ++i) {
        switch (config_defaults[i].type) {
            case 'radio':
                var selection = $('input[name=' + config_defaults[i].name + ']:checked').attr('id');
                if (selection && selection.substr(0, config_defaults[i].name.length) == config_defaults[i].name) {
                    var val = selection.substr(config_defaults[i].name.length + 1);
                    if (val !== config_defaults[i].default_value) {
                        config[config_defaults[i].name] = val;
                    }
                }
                break;
            case 'check':
                var bool = $('#' + config_defaults[i].id).prop('checked');
                if (config_defaults[i].default_value !== bool) {
                    config[config_defaults[i].id] = bool;
                }
                break;
            case 'text':
                var text = $('#' + config_defaults[i].id).val();
                if (text.length == 0) {
                    if (config_defaults[i].default_value !== null && config_defaults[i].default_value !== "") {
                        config[config_defaults[i].id] = null;
                    }
                }
                else {
                    if (config_defaults[i].default_value === null || config_defaults[i].default_value === "" || config_defaults[i].default_value !== text) {
                        config[config_defaults[i].id] = text;
                    }
                }
                break;
            case 'int':
                var int = parseInt($('#' + config_defaults[i].id).val());
                if (!isNaN(int) && int !== config_defaults[i].default_value) {
                    config[config_defaults[i].id] = int;
                }
                break;
            case 'select':
                var select = $('#' + config_defaults[i].id + ' option:selected').val();
                if (config_defaults[i].default_value !== select) {
                    config[config_defaults[i].id] = select;
                }
                break;
            case 'resource':
                var res = $('#' + config_defaults[i].id + ' option:selected').val();
                if (res !== '(default)' && res !== config_defaults[i].default_value) {
                    config[config_defaults[i].id] = res;
                }
                break;
            default:
                break;
        }
    }
    return config;
}



function applyChanges() {
    // set that they attempted to save
    change_happened = false;

    // check if there's a gui document loaded
    if (typeof config_defaults != 'object') {
        return;
    }

    // get any existing _custom attributes
    var e = $('#xmlvars');
    var _custom = null;
    try {
        var v = e.val();
        var ifo = v.indexOf('{');
        if (ifo >= 0) {
            var ilo = v.lastIndexOf('}');
            if (ilo >= 1) {
                var j = JSON.parse(v.substr(ifo, ilo - ifo + 1));
                _custom = j._custom;
            }
        }
    } catch (e) {
    }
    var c = getConfigValues();
    if (_custom) {
        c._custom = _custom;
    }
    e.val('config=' + JSON.stringify(c) + ';');
}



function populateSelectWithResoures(id) {
    function doPathGroup(name, path, files, val, exts) {
        var html = '';
        var any = false;
        path = path.replace(/\/?$/, '/');
        for (var i = 0; i < files.length; ++i) {
            var fn = files[i].name;
            var ext = fn.substr(fn.lastIndexOf('.') + 1);
            if ($.inArray(ext, exts) >= 0) {
                if (!any) {
                    html += '<optgroup label="' + name + '">';
                    any = true;
                }
                html += ((val && (files[i].name == val || (path + files[i].name) == val)) ? "<option selected='selected' value='" + path + rwc_htmlescape(files[i].name) + "'>" : "<option value='" + path + rwc_htmlescape(files[i].name) + "'>") + rwc_htmlescape(files[i].name) + "</option>";
            }
        }
        if (any) {
            html += '</optgroup>';
        }
        return html;
    }

    var val = typeof config[id] == 'string' ? config[id] : null;
    var e = $('#' + id);
    e.change(function () { change_made(); fileSelect(id); });

    // calculate the possible source paths
    var paths = [];
    var paths_str = e.data('file-path');
    if (typeof paths_str === 'string') {
        paths = paths_str.split('|');
        for (var i = 0; i < paths.length; ++i) {
            paths[i].trim();
        }
        paths = paths.filter(function (el) {
            return typeof el === 'string' && el.length > 0;
        });
    }

    // calculate the desired file types
    var exts = [];
    var exts_str = e.data('file-types');
    if (typeof exts_str === 'string') {
        exts = exts_str.split('|');
        for (var i = 0; i < exts.length; ++i) {
            exts[i].trim();
        }
        exts = exts.filter(function (el) {
            return typeof el === 'string' && el.length > 0;
        });
    }
    if (exts.length === 0) {
        exts.push('wav');
        exts.push('opus');
    }

    var opts = '<option>(default)</option>';
    if (!paths.length || $.inArray('~', paths) >= 0) {
        opts += doPathGroup('Custom', '~', resourceFiles, val, exts);
    }
    if (paths.length && $.type(resourceFilesCommon) === 'object') {
        for (var j = 0; j < resourceFilesCommon.paths.length; ++j) {
            if ($.inArray(resourceFilesCommon.paths[j].path, paths) >= 0) {
                opts += doPathGroup('Common', resourceFilesCommon.paths[j].path, resourceFilesCommon.paths[j].resources, val, exts);
            }
        }
    }

    e.append($(opts));
    if (window.HTMLAudioElement) {
        e.after($("<div id='" + id + "_player' style='display: inline;'></div>"));
        fileSelect(id);
    }
}



function setConfigValues() {
    if (typeof config != 'object') {
        config = {};
    }
    if (typeof resourceFiles != 'object') {
        resourceFiles = [];
    }


    function radioByConfig(id_name, default_part) {
        // find the control by the id_name+config if it exists, else use id_name+default_part
        var e = null;
        if (typeof config[id_name] == 'string') {
            e = $('#' + id_name + '_' + config[id_name]);
            if (e.length == 0) {
                e = null;
            }
        }
        if (!e) {
            e = $('#' + id_name + '_' + default_part);
        }
        e.attr('checked', 'checked');
        $('[id^=' + id_name + '_]').change(change_made);
    }


    function checkByConfig(id_part, default_value) {
        var e = $('#' + id_part);
        // find the control by the id_part if it exists and set the attribute
        if ((default_value && typeof config[id_part] == 'undefined') || (typeof config[id_part] != 'undefined' && config[id_part])) {
            e.attr('checked', 'checked');
        }
        else {
            e.removeAttr('checked');
        }
        e.change(change_made);
    }


    function selectByConfig(id_part, default_value) {
        var str = typeof config[id_part] != 'string' ? default_value : config[id_part];
        $('#' + id_part + " option").filter(function () {
            return $(this).val() == str;
        }).prop('selected', true);
        $('#' + id_part).change(change_made);
    }


    // set all the configuration values
    for (var i = 0; i < config_defaults.length; ++i) {
        switch (config_defaults[i].type) {
            case 'radio':
                radioByConfig(config_defaults[i].name, config_defaults[i].default_value);
                break;
            case 'check':
                checkByConfig(config_defaults[i].id, config_defaults[i].default_value);
                break;
            case 'text':
                $('#' + config_defaults[i].id).val(typeof config[config_defaults[i].id] != 'string' ? config_defaults[i].default_value : config[config_defaults[i].id]).change(change_made).on("input", change_made);
                break;
            case 'int':
                $('#' + config_defaults[i].id).val(typeof config[config_defaults[i].id] != 'number' ? config_defaults[i].default_value : config[config_defaults[i].id]).change(change_made).on("input", change_made);
                break;
            case 'select':
                selectByConfig(config_defaults[i].id, config_defaults[i].default_value);
                break;
            case 'resource':
                populateSelectWithResoures(config_defaults[i].id);
                break;
            case 'password':
                $('#' + config_defaults[i].id).change(change_made).on("input", change_made);
                break;
            default:
                break;
        }
    }
}


$(function(){
    var divID = "[id^=_accordion_]";
    bootstrapCollapseDiv(divID);

    change_detect_set_alert();
});
