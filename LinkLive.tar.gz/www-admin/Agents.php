<?php
$hg=$_REQUEST['hg'];
if(!$hg){
	include 'AgentsAll.php';
	exit();
}
include 'tableTop.php';
$pg=$_REQUEST['pg'];
$urlTokenArg=$revation->getUrlTokenArg();
?>

<script>
var agents = null;
var group = "<?php echo addslashes(htmlspecialchars($hg));?>";
var dataTable = null;

function groupOf(user){
	var g={
		hg: null,
		sessions: 0
	};
	if(user&&user.groups){
		for (var i=0; i<user.groups.length; i++) {
			var ag=user.groups[i];
			g.sessions += ag.activeSessions;
			if ( ag.group == group ) {
				if(ag.maxSessions||ag.primary||ag.monitorable||ag.rights!='inherit'||ag.priority||ag.inbound||ag.outbound){
					g.hg = ag;
				}
			}
		}
	}
	return g;
}

var RightsFriendly = [
	["inherit", "Inherit"],
	["none", "None"],
	["reporting_stats", "Reporting Stats"],
	["detailed_stats", "Detailed Stats"],
	["supervisor", "Supervisor"],
	["qa_rights", "QA Rights"],
	["workforce_mgmt", "Workforce Mgmt"]
];

function rightsFriendly(rights){
	for(var i=0;i<RightsFriendly.length;++i){
		if(RightsFriendly[i][0]==rights){
			return RightsFriendly[i][1];
		}
	}
	return 'None';
}

function renderStatus( data, type, full ) {
	if(type=='display'){
		return statusImage(data);
	}
	else {
		return data;
	}
}

function renderAgentPid( data, type, full ) {
	var agent=agents[full[1]];
	if(type=='display'){
		var html = '<div class="dropdown">' +
			'<button class="btn btn-secondary btn-xs" id="menub-'+data+'" data-toggle="dropdown" title="Menu for ' + rwc_htmlescape(agent.pid) + '" href="#">&#x2699;</button>' +
			'</div>'+
			'<a href="embed.php?doc=AgentEdit.html&<?=$urlTokenArg?>&pid='+encodeURIComponent(agent.pid)+'&hg=<?php echo urlencode($hg);?>&pg=<?php echo urlencode($pg);?>"';

		var g = groupOf(agent);
		if ( g && g.hg && (g.hg.rights=='supervisor'||g.hg.rights=='qa_rights'||g.hg.rights=='workforce_mgmt') ) {
			html += ' style="font-weight: bold;" title="supervisor"';
		}
		return html + '>' + rwc_htmlescape(agent.pid) + '</a>';
	}
	else{
		return agent.pid;
	}
}

function openPopup(event,i) {
	closeMenus();
	event.stopImmediatePropagation();
	var mb=$('#menub-'+i);
	var m=$('#menu-'+i);

	if (m.length) {
		m.remove();
	}
	else {
		var html=
			'<ul id="menu-'+i+'" class="dropdown-menu" style="padding:5px;">'+
			'<li class="dropdown-header menu-header">Agent</li>'+
			'<li class="dropdown-item addCursorPointer hover" onclick="closeMenus(); window.location=\'embed.php?doc=AgentEdit.html&<?=$urlTokenArg?>&pid='+encodeURIComponent(agents[i].pid)+'&hg=<?php echo urlencode($hg);?>&pg=<?php echo urlencode($pg);?>\';return false;">Settings</li>'+
			userAccountPopupMenu(agents[i].group,agents[i].pid)+
			'</ul>';

		mb.after(html);
		$('#menu-'+i).click(function (e) { e.stopPropagation(); }).dropdown().css('display', 'block');
	}
}

function loadTable() {
    idleReset();
    $.ajax({
    type: 'GET',
    url: 'json/huntGroupAgents?<?=$urlTokenArg?>',
		async: true,
		cache: false,
		data: 'group=<?php echo $pg;?>',
		success: function (json) {
			if (json.agents){
				agents = json.agents;
				var data = [];
				for(var i=0;i<agents.length;i++){
					var user = agents[i];
					var g = groupOf( user );
					if ( g.hg ) {
						data.push( [
							g.hg.status,
							i,
							user.alias,
							rightsFriendly(g.hg.rights=='inherit'?user.rights:g.hg.rights),
							g.hg.outbound ? '&#x2714;' : '&#x2716;',
							g.hg.inbound ? '&#x2714;' : '&#x2716;',
							g.hg.priority,
							g.hg.delay,
							g.hg.maxSessions,
							user.maxSessions,
							'' + g.hg.activeSessions + ( g.hg.activeSessions != g.sessions ? '/' + g.sessions : '' )
							] );
					}
				}
				if ( dataTable == null ) {
					var config = {
						"aaData": data,
						"aaSorting":[[1,"asc"]],
						"bAutoWidth":false,
						responsive: true,
						"aoColumns": [
							{ /* "Status" */ "bSearchable": false, "sClass": "right", "sWidth": "14px", "mRender": renderStatus },
							{ /* "Presence Id" */ "sClass": "nowrapellipsis", "mRender": renderAgentPid, responsivePriority: 1 },
							{ /* "Display Name" */ "mRender": $.fn.dataTable.render.text() },
							{ /* "Rights" */ },
							{ /* "Outbound" */ "bSearchable": false, "sClass": "right" },
							{ /* "Inbound" */ "bSearchable": false, "sClass": "right" },
							{ /* "Priority" */ "bSearchable": false, "sClass": "right" },
							{ /* "Delay" */ "bSearchable": false, "sClass": "right" },
							{ /* "Max" */ "bSearchable": false, "sClass": "right" },
							{ /* "Max Total" */ "bSearchable": false, "sClass": "right" },
							{ /* "Active" */ "bSearchable": false, "sClass": "right" }
						],
						"fnFooterCallback": function ( nRow, aaData, iStart, iEnd, aiDisplay ) {
							// do total for only what's displayed
							var local = 0;
							var other = 0;
							for ( var i=0; i<aiDisplay.length; i++ ) {
								var s=aaData[aiDisplay[i]][10];
								var v=parseInt(s);
								if(!isNaN(v)){
									local += v;
									var slash=s.indexOf('/');
									if(slash>0){
										v=parseInt(s.substr(slash+1));
										if(!isNaN(v)){
											other += v;
										}
									}
								}
							}

							var nCells = nRow.getElementsByTagName('th');
							var s=''+local;
							if(other>0){
								s+='/'+other;
							}
							nCells[1].innerHTML = '' + s;
						},
						"fnInfoCallback": function( oSettings, iStart, iEnd, iMax, iTotal, sPre ) {
							for(var row=iStart-1;row<iEnd;++row){
								// since the data is filtered by us before insert, we need to get the source of the display
								var i=oSettings.aoData[oSettings.aiDisplay[row]]._aData[1];
								$('#menub-'+i).click(function(i){
									return function(event){
										openPopup(event,i);
									}
								}(i));
							}
							return sPre;
						}
					};
					tableConfigLoad("agents", config);
					dataTable = $('#main_data_table').dataTable(config);
				}
				else {
					dataTable.fnClearTable();
					if (data.length) {
						dataTable.fnAddData( data );
					}
				}
			}
		}
	});
}

$(document).ready(function(){
	loadTable();
});

$(document).on('click',function(){
	$('ul[id^="menu-"]').remove();
});

$(window).on('unload',function() {
	tableConfigStore("agents",dataTable.fnSettings());
});

function closeMenus(){
	if(agents){
		for(var i=0;i<=agents.length;++i){
			$('#menu-'+i).css('display','none');
		}
	}
}

//# sourceURL=Agents.php.js
</script>
<div class='legend'>Agents of <?php echo htmlspecialchars($hg);?></div>
<table cellpadding="0" cellspacing="0" border="0" class="display table-striped table-bordered nowrap w-100" id="main_data_table" style="padding-top:2em;">
<thead><tr>
	<th><div class="head_rot" title="Current Status of the Agent Account to this Hunt Group">Status</div></th>
  <th title="Presence Id of the Agent Account">Presence Id</th>
  <th title="Display Name Alias of the User Account for Hunt Groups">Display Name</th>
  <th title="Rights of the User Account in this Hunt Group">Rights</th>
	<th><div class="head_rot" title="If an agent handles Inbound sessions in the Hunt Group">Outbound</div></th>
	<th><div class="head_rot" title="If the agent does Outbound sessions in the Hunt Group">Inbound</div></th>
	<th><div class="head_rot" title="Priority of the agent in this Hunt Group versus other Agents&#10;Lower number gets sessions first">Priority</div></th>
	<th><div class="head_rot" title="Delay before Agent Receives Sessions in this Hunt Group">Delay</div></th>
	<th><div class="head_rot" title="Maximum Sessions in this Hunt Group the Agent can be in">Max</div></th>
	<th><div class="head_rot" title="Maximum Total Sessions in all Hunt Groups the Agent can be in">Max Total</div></th>
	<th><div class="head_rot" title="Active Sessions the Agent is in, or:&#10;X/Y where Y is the total Session including Other Hunt Groups">Active</div></th>
</tr></thead>
<tfoot><tr>
  <th colspan="10" style='text-align: right;'>Total:</th>
  <th class="right"></th>
</tr></tfoot>
</table>
<div style="text-align:center;" class="mt-2">
  <?php
	if($revation->adminRight('ar_agents'))
		echo'<input type="button" name=add value="Add New Agents" class="btn btn-secondary btn-sm" onclick="window.location=\'embed.php?doc=AgentAdd.html&'.$urlTokenArg.'&hg='.urlencode($hg).'&pg='.urlencode($pg).'\';return false;" />';
?>
  <input type="button" name="add" value="All Agents" class="btn btn-secondary btn-sm" onclick="window.location='embed.php?php=AgentsAll&<?=$urlTokenArg?>';return false;" />
  <input type="button" value="Refresh" class="btn btn-secondary btn-sm" onclick="loadTable();return false;" />
  <input type="button" value="&#x21e6; Back" class="btn btn-dark btn-sm" onclick="window.location='embed.php?php=Groups&<?=$urlTokenArg?>';return false;" />
</div>
<div style="text-align:center;" class="mt-2">
    <form method='post' action="embedalone.php?doc=Agents.csv&<?=$urlTokenArg?>" target='_blank' style='display: inline;'>
    <input type="hidden" name="hg" value="<?php echo $hg;?>" />
    <input type="hidden" name="pg" value="<?php echo $pg;?>" />
    <input type="submit" name="save" value="Download .CSV" class="btn btn-secondary btn-sm" />
    </form>
    <form method='post' action='embed.php?doc=AgentsUpload.html&<?=$urlTokenArg?>' enctype='multipart/form-data' style='display: inline;'>
    <input type="hidden" name="hg" value="<?php echo $hg;?>" />
    <input type="hidden" name="pg" value="<?php echo $pg;?>" />
	<label class="btn btn-secondary btn-sm" style="margin-bottom: 0;">
    <input hidden title='Upload .CSV' type='file' name='filename' id='uploadButton' onchange='if(this.value){if(this.value.search(/\.csv/i)==-1){alert("file not of correct extension!");this.form.reset();return false;}else{this.form.submit();return true;}}' />
	Upload .CSV...
	</label>
	<label><input type="checkbox" name="test_mode" checked="checked"/> test mode</label>
    </form>
</div>
<?php include 'tableBottom.php';?>