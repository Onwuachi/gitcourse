<?php
$urlTokenArg=$revation->getUrlTokenArg();
include 'tableTop.php';
?>

<div id="userRightsDialog" style="display: none;" title="User Rights">
</div>

<script type="text/javascript">
var privateGroup = "<?php echo $revation->adminGroup();?>";
</script>

<div class='legend'>Phone Logs for <?php echo $revation->adminGroup();?></div>
<form method='post' action='embed.php?php=mail/folder&<?=$urlTokenArg?>&vtop=1&mailbox=Calls' enctype='multipart/form-data' style='display: inline;'>
Enter the phone number to look up: <input type=text name=phone value='<?=htmlspecialchars($_REQUEST['phone'])?>'>
<br/>
<input type='submit' class='btn btn-secondary btn-sm'> &nbsp;
<input type='button' value='&#x21e6; Back' class='btn btn-dark btn-sm' onclick="window.location='embed.php?php=Tools&<?=$urlTokenArg?>';return false;">
</form>

<?php include 'tableBottom.php';?>