<?php
if(strpos($_REQUEST['callback'],'..')||strcspn($_REQUEST['callback'],'><:/&,?%*"\'\\')<strlen($_REQUEST['callback']))
	unset($_REQUEST['callback']);
if($_REQUEST['callback']){
    header('Content-Type: text/javascript');
    echo $_REQUEST['callback'].'(';
}
else{
    header('Content-Type: application/json');
}
echo'{'.$revation->huntGroupStatus($_REQUEST['group'],$_REQUEST['huntgroup'],$_REQUEST['admin'],$_REQUEST['pswd'],$_REQUEST['cmd'],$_REQUEST['options']).'}';
if($_REQUEST['callback']){
    echo');';
}
?>