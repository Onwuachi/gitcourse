<popnotify id='access_denied'>
	<from>LinkLive Server</from>
	<subj>UPDATE REQUIRED - click here</subj>
	<body isHtml='true'>
	Your client version is &lt;i&gt;not compatible&lt;/i&gt; with this server.
	Please contact your system administrator for the correct client version.
	</body>
</popnotify>
