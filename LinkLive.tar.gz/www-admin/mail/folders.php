<?php
$urlTokenArg=$revation->getUrlTokenArg();
$parms='&'.$urlTokenArg.'&vtop=1&pg='.urlencode($_REQUEST['pg']);
if(empty($_REQUEST['phone'])){
	$parms=$parms.'&key='.urlencode($_REQUEST['key']);
	echo'<div class="legend">'.htmlspecialchars($_REQUEST['key']).' <input type=button value="&#x21e6; Back" class="btn btn-dark btn-sm" onclick="window.location=\'embed.php?doc=UserEdit.html&'.$urlTokenArg.'&edit='.urlencode($_REQUEST['key']).'&privateGroup='.urlencode($_REQUEST['pg']).'\'" /></div>';
	$hiddenkey='<input type=hidden name=key value="'.htmlspecialchars($_REQUEST['key']).'">';
	$options=1;
}
else{
	echo'<div class="legend">'.htmlspecialchars($_REQUEST['phone']).' <input type=button value="&#x21e6; Back" class="btn btn-dark btn-sm" onclick="window.location=\'embed.php?php=PhoneLogs&'.$urlTokenArg.'&phone='.urlencode($_REQUEST['phone']).'&privateGroup='.urlencode($_REQUEST['pg']).'\'" /></div>';
	$parms=$parms.'&phone='.urlencode($_REQUEST['phone']);
	$hiddenkey='<input type=hidden name=phone value="'.htmlspecialchars($_REQUEST['phone']).'">';
}

$i=0;
$folder=$_MAILBOX[$i]['name'];
echo'<table cellspacing="0" cellpadding="0" class="mailtbl" style="border: 0; width: 100%; text-align: left;"><tr><td>';
while($folder){
	echo"<a href='embed.php?php=mail/folder&mailbox=".urlencode($folder).$parms."'";
	if(!strcasecmp($folder,$mailbox))
		echo' class="selected"';
	echo'>';
	if($_MAILBOX[$i]['unread']>0)
		echo'<b>'.htmlspecialchars($folder).' ('.$_MAILBOX[$i]['unread'].')</b>';
	else
		echo htmlspecialchars($folder);
	echo'</a>';
	$i=$i+1;
		$folder=$_MAILBOX[$i]['name'];
}
echo'</td><td style="text-align: right;">';
if($_DOCS){
		echo"<a href='embed.php?php=mail/docs".$parms."'";
		if(!strcasecmp('$docs',$mailbox))
			echo' class="selected"';
		echo">Folders</a>";
}
if($_FORWARDING){
		echo"<a href='embed.php?php=mail/forwarding".$parms."'";
		if(!strcasecmp('$av',$mailbox))
			echo' class="selected"';
		echo">aVoice</a>";
}
if($options&&$i!=0){
	echo"<a href='embed.php?php=mail/options".$parms."'";
	if(!strcasecmp('$opt',$mailbox))
		echo' class="selected"';
	echo">Options</a>";
}
echo"</td></tr></table>\n";
?>