<?php
if(!$revation->adminRight('ar_userlogs')){
	echo'NO RIGHTS';
	exit();
}

$mailbox='$opt';
include'mail/folders.php';
if(!empty($_REQUEST['submit'])){
	$revation->config('user-options');
}
$urlTokenArg=$revation->getUrlTokenArg();
?>

<form method="post" name="form" action="embed.php?<?=$urlTokenArg?>" onSubmit="options_verify(this); return;" >
<input type="hidden" name="key" value="<?=htmlspecialchars($_REQUEST['key'])?>"/>
<input type="hidden" name="pg" value="<?=htmlspecialchars($_REQUEST['pg'])?>"/>
<input type="hidden" name="php" value="mail/options"/>
<input type="hidden" name="vtop" value="1"/>

<br />

<table cellpadding="4" cellspacing="0" style="background-color: #ffffff; width: 100%; text-align: left;">
<tr><th colspan='2'>&nbsp;</th></tr>
	
<?php
		if($_EVENT['ForceNewPass'])
			echo'<tr><td align="center" colspan="2" style="color: red; font-weight: bold;">User will be required to change their password at next login.</td></tr>';
	if($_EVENT['VmPINChanged'])
		echo'<tr><td align="center" colspan="2" style="color: green; font-weight: bold;">The Voicemail PIN was changed.</td></tr>';
	else if($_EVENT['VmPINPolicyFailed'])
		echo'<tr><td align="center" colspan="2" style="color: red; font-weight: bold;">The Voicemail PIN change failed because it did not meet policy</td></tr>';
?>

<tr><td align="right">Voicemail PIN:</td><td><input type="password" name="voicemailpin" size="40" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" value="_pn_"/></td></tr>

<tr><td colspan="2"><hr /></td></tr>

<?php
		if($_EVENT['EmailChanged'])
			echo'<tr><td align="center" colspan="2" style="color: green; font-weight: bold;">Your notification email address was changed.</td></tr>';
?>

<tr><td align="right">Notification Email Address:</td><td><input type="text" name="email" size="40" value="<?=$_USERCONFIG['email']?>"/></tr>

<?php
if($_EVENT['NotifyChanged'])
	echo'<tr><td align="center" colspan="2" style="color: green; font-weight: bold;">The notification option was changed.</td></tr>';
?>

<tr><td align="right">Send Notification:</td><td>
<label><input type="radio" name="notify" value="never" <?php if($_USERCONFIG['notify']=='never') echo' checked="checked"';?>> Never</label>,
<label><input type="radio" name="notify" value="first-unseen" <?php if($_USERCONFIG['notify']=='first-unseen') echo' checked="checked"';?>> First Unseen Msg</label>, or
<label><input type="radio" name="notify" value="every-unseen" <?php if($_USERCONFIG['notify']=='every-unseen') echo' checked="checked"';?>> Every Unseen Msg</label>
</td></tr>

<tr>
<td align="right"></td>
<td>
<label>
<input type="checkbox" name="calendarNotify" value="calendarNotify" <?php if($_USERCONFIG['calendarNotify']=='YES') echo' checked="checked"';?>> Use this address for calendar notifications
</label>
</td>
</tr>

<tr><td colspan="2"><hr /></td></tr>

  <?php
		if($_EVENT['PhoneChanged'])
			echo'<tr><td align="center" colspan="2" style="color: green; font-weight: bold;">Your notification phone number was changed.</td></tr>';
?>

  <tr>
    <td align="right">Notification Phone Number:</td>
    <td>
      <input type="text" name="phone" size="40" value="<?=$_USERCONFIG['phone']?>"/>
  </tr>

  <?php
if($_EVENT['PhoneNotifyChanged'])
	echo'<tr><td align="center" colspan="2" style="color: green; font-weight: bold;">The phone notification option was changed.</td></tr>';
?>

  <tr>
    <tr><td align="right">Use phone number: </td>
    <td class="form-field">
      <label>
        <input type="radio" name="phoneNotify" value="never" <?php if($_USERCONFIG['notify']=='never') echo' checked="checked"';?> onchange='madeChanges=true;' onfocus='focusSet=true;'> Never
      </label>
      <label>
        <input type="radio" name="phoneNotify" value="phone" <?php if($_USERCONFIG['phoneNotify']=='phone') echo' checked="checked"';?> onchange='madeChanges=true;' onfocus='focusSet=true;'> For Phone Calls
      </label>
      <label>
        <input type="radio" name="phoneNotify" value="text" <?php if($_USERCONFIG['phoneNotify']=='text') echo' checked="checked"';?> onchange='madeChanges=true;' onfocus='focusSet=true;'> For Text Messages
      </label>
      <label>
        <input type="radio" name="phoneNotify" value="both" <?php if($_USERCONFIG['phoneNotify']=='both') echo' checked="checked"';?> onchange='madeChanges=true;' onfocus='focusSet=true;'> For Both
      </label>
    </td>
  </tr>

<tr><td colspan="2"><hr /></td></tr>
<tr><td colspan="2" align="center">Signature for email:</td></tr>
<tr><td colspan="2" align="center"><textarea style="width: 90%;" placeholder="your eMail signature" name="emailSignature" onchange="madeChanges=true;"><?=htmlspecialchars($_USERCONFIG['emailSignature'])?></textarea>
<?php
	if($_EVENT['EmailSignatureChanged'])
		echo'<br/><span style="color: green; font-weight: bold;">Signature changed.</span>';
?>
</td></tr>

<tr><td colspan="2"><hr /></td></tr>

<tr>
<td style="text-align: right;">Send automatic email replies: </td><td class="form-field">
<label><input type="radio" name="autoreply" value="off" <?php if($_USERCONFIG['autoReply.action']=='off') echo' checked="checked"';?> onchange='madeChanges=true;' onfocus='focusSet=true;'> Off</label>
<label><input type="radio" name="autoreply" value="internal" <?php if($_USERCONFIG['autoReply.action']=='internal') echo' checked="checked"';?> onchange='madeChanges=true;' onfocus='focusSet=true;'> To my domain</label>
<label><input type="radio" name="autoreply" value="on" <?php if($_USERCONFIG['autoReply.action']=='on') echo' checked="checked"';?> onchange='madeChanges=true;' onfocus='focusSet=true;'> To everyone</label>
<?php
	if($_EVENT['ReplyActionChanged'])
		echo'<span style="color: green; font-weight: bold;">Reply type changed.</span>';
?>
</td>
</tr>
<tr><td style="text-align: right;">Each user gets the reply: </td><td class="form-field">
<label><input type="radio" name="autoreply_freq" value="once" <?php if($_USERCONFIG['autoReply.freq']=='once') echo' checked="checked"';?> onchange='setChanged();' onfocus='focusSet=true;'> One Time</label>
<label><input type="radio" name="autoreply_freq" value="every" <?php if($_USERCONFIG['autoReply.freq']=='every') echo' checked="checked"';?> onchange='setChanged();' onfocus='focusSet=true;'> Every message</label>
<?php
	if($_EVENT['ReplyFreqChanged'])
		echo'<span style="color: green; font-weight: bold;">Reply frequency changed.</span>';
?>
</td>
</tr>
<tr><td colspan="2" align="center">
Start: <input type="text" id="autoreply_start" name="autoreply_start" value="<?=$_USERCONFIG['autoReply.timeStart']?>" onchange="madeChanges=true;" />
&nbsp;
End: <input type="text" id="autoreply_end" name="autoreply_end" value="<?=$_USERCONFIG['autoReply.timeEnd']?>" onchange="madeChanges=true;" />
<?php
	if($_EVENT['ReplyTimeStartChanged'])
		echo'<br><span style="color: green; font-weight: bold;">Reply start time changed.</span>';
	if($_EVENT['ReplyTimeEndChanged'])
		echo'<br><span style="color: green; font-weight: bold;">Reply end time changed.</span>';
?>
</td></tr>
<tr><td colspan="2" align="center">Subject: <input type="text" style="min-width: 50%;" placeholder="Out of office reply" name="autoreply_subject" onchange="madeChanges=true;" value="<?=$_USERCONFIG['autoReply>subject']?>" />
<?php
	if($_EVENT['ReplySubjectChanged'])
		echo'<span style="color: green; font-weight: bold;">Reply subject changed.</span>';
?>
</td></tr>
<tr><td colspan="2" align="center"><textarea style="width: 90%;" placeholder="your auto-reply message" name="autoreply_body" onchange="madeChanges=true;"><?=htmlspecialchars($_USERCONFIG['autoReply>body'])?></textarea>
<?php
	if($_EVENT['ReplyBodyChanged'])
		echo'<br/><span style="color: green; font-weight: bold;">Reply body changed.</span>';
?>
</td></tr>

<tr><td colspan="2"><hr /></td></tr>

<tr><td align="center" colspan="2"><input style="min-width:6em;" name="submit" type="submit" value="Save" class='btn btn-secondary btn-sm' /></td></tr>

</table>

</form>

<script type="text/javascript" src="js/flatpickr.js"></script>
<script type="text/javascript">
function options_getDateTime(id) {
    var f = document.querySelector(id)._flatpickr;
    $(id).val(Math.floor(f.latestSelectedDateObj.valueOf()/1000));
}

function options_verify(form) {
    options_getDateTime('#autoreply_start');
    options_getDateTime('#autoreply_end');
}

function options_setDateTime(id) {
    var input=$(id);
    var gmt=parseInt(input.val()) * 1000;
    var d;
    if(gmt) {
        d = new Date(gmt);
    }
    if (!d || isNaN(d)) {
        d = new Date(Date.now());
    }
    input.flatpickr({
        defaultDate: d,
        enableTime: true,
        dateFormat: "Y-m-d  G:i K"
    });
}

$(function() {
  options_setDateTime('#autoreply_start');
  options_setDateTime('#autoreply_end');
  madeChanges=false;
});
</script>