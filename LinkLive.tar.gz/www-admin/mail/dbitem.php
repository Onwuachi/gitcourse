<script type='text/javascript' src='MultiFileAudioPlayer.js'></script>
<script type="text/javascript" src='mail/datetimes.js'></script>
<?php
if(empty($parms)) {
	$urlTokenArg=$revation->getUrlTokenArg();
	$parms='&'.$urlTokenArg.'&key='.urlencode($_REQUEST['key']).'&vtop=1&pg='.urlencode($_REQUEST['pg']);
}
if($revation->adminRight('ar_userlogs'))
	$mi=$_DBITEM[$_REQUEST['dbid']];
echo'<br/><table cellspacing="0" cellpadding="0" class="mailtbl" style="border: 0; width: 100%; text-align: center;"><tr><td>';
echo'<form id="dbid_search" method="post" style="inline-block;" action="index.php?'.$urlTokenArg.'">Database Session ID: <input name="dbid" id="dbid" value="'.htmlspecialchars($_REQUEST['dbid']).'" style="min-width: 24em;"/> <input type="submit" value="Search" class="btn btn-secondary btn-sm"/><div id="participant_select"></div></form></td></tr></table>';
if(!$mi)
	echo'<div class="hilight_red" style="text-align: center;">ITEM NOT FOUND or ACCESS DENIED</div>';
else if(isset($_REQUEST['delatt']))
	$ok=$mi['attachments'][0+$_REQUEST['delatt']]['delete'];
?>

<table style="width: 100%; text-align: left; font-size: smaller; border-bottom: .5em solid #1c394f;" cellspacing="0" cellpadding="3">
	<tr>
		<td style="min-width: 1%;">From:</td>
		<td style="width: 99%;"><b><?=htmlspecialchars($mi['from'])?></b>&nbsp;</td>
	</tr>
	<?php
	$d=$mi['logtimestr'];
	if($d)
		echo'<tr><td style="min-width: 1%;">Date:</td><td><b><script type="text/javascript">outputModifyDate("'.$d.'");</script></b>&nbsp;</td></tr>';
	?>
	<tr>
		<td style="min-width: 1%;">To:</td>
		<td><b><?=htmlspecialchars($mi['to'])?></b>&nbsp;</td>
	</tr>

<?php
$cc=$mi['cc'];
if($cc){
		echo'<tr><td style="min-width: 1%;">Cc:</td><td><b>';
		echo htmlspecialchars($cc);
		echo'</b>&nbsp;</td></tr>';
}
?>
		<tr>
			<td style="min-width: 1%;">Subject:</td>
			<td><b><?php
				if(empty($mi['subject']))
						echo htmlspecialchars($mi['subject']);
				else if($mi)
						echo'(no subject)';
			?></b>&nbsp;</td>
		</tr>
<?php
if(sizeof($mi['attachments'])){
		echo'<tr><td style="min-width: 1%;"><img src="mail/attpic.png" border=0></td><td>';
		$i=0;
		while($mi['attachments'][$i]){
				if($i>0)
					echo", &nbsp;";
				$name=$mi['attachments'][$i]['name'];
				echo'<a target="_blank" href="/download.php?filename='.urlencode($name).'&cmd=mail-attachment&att='.$i.$parms.'">'.htmlspecialchars($name).'&nbsp;('.$mi['attachments'][$i]['sizestr'].')</a>';
				if($name=="conference.wav"){
					echo' <script type="text/javascript">audioPlayer.writeButton("'.$name.'", "cmd=mail-attachment&translate=8k16bm&att='.$i.$parms.'");</script>';
					if($revation->adminRight('ar_delatt'))
						echo'<input type="button" style="display: inline;" class="btn btn-secondary btn-sm" onclick="return deleteWavFile('.$i.');" value="Delete"/>';
				}
				$i=$i+1;
		}
		echo'</td></tr>';
}
if(sizeof($mi['shares'])){
		echo'<tr><td title="shares" style="min-width: 1%;"><img src="mail/attshare.png" border=0></td><td>';
		$i=0;
		while($mi['shares'][$i]){
				if($i>0)
					echo', &nbsp;';
				echo'<a href="mail-shareviewer.php?share='.$i.$parms.'" target="_blank">'.htmlspecialchars($mi['shares'][$i]['name']).'&nbsp;('.$mi['shares'][$i]['sizestr'].')</a>';
				$i=$i+1;
		}
		echo'</td></tr>';
}

?>
		
</table>

<table border="0" cellspacing="0" cellpadding="0" style="width: 100%; background-color: #ffffff; text-align: left; font-size: smaller;"><tr><td>
<?=$mi['htmlbody']?>
</td></tr></table>
<script type="text/javascript">
  changeSessionTimes("<?=$mi['logtimestr']?>");
  function deleteWavFile(){
	if(confirm('Are you sure you want to delete this conference file?  It cannot be un-done and the action will be logged!')){
		window.location='embed.php?php=mail/item&delatt='+att+'<?='&seq='.$seq.'&mailbox='.urlencode($mailbox).$parms?>';
	}
	return false;
  }
  createParticipantSelect('participant_select',<?=$mi['participants']?>);
</script>

<table cellspacing="0" cellpadding="0" class="mailtbl" style="border: 0; width: 100%; text-align: left;"><tr><td>&nbsp;</td></tr></table>