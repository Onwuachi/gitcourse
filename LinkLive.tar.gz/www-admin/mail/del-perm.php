<?php
if(!$revation->adminRight('ar_userlogs')){
	echo'NO RIGHTS';
	exit();
}
$urlTokenArg=$revation->getUrlTokenArg();
?>

<script type="text/javascript" src="mail/datetimes.js"></script>

<script type="text/javascript">
  //<![CDATA[
<?php echo'var key="'.addslashes($_REQUEST['key']).'",group="'.addslashes($_REQUEST['pg']).'",idx="'.addslashes($_REQUEST['idx']).'";';?>
var query = 'idx=_del-perm&key='+key+'&pg='+group+'&<?=$urlTokenArg?>';
var g_data = null;
var dataTable = null;
var dbid_location=document.location.protocol+'//'+document.location.hostname+document.location.pathname.substr(0,document.location.pathname.lastIndexOf('/')+1);

function renderYYYYMMDD( data, type, full ){
  return '<a target=_blank href="'+dbid_location+'embedalone.php?php=mail/dbitem&<?=$urlTokenArg?>&dbid='+group+'/'+full[0]+'/'+full[2]+'/'+key+'">'+full[0]+'</a>';
}

function loadTable() {
	$.ajax({
		type: 'GET',
		url: 'json/userIndex',
		async: true,
		cache: false,
		data: query,
		success: function (json) {
			g_data = json;
			var data = [];
			if (json.userIndex){
				for(var i=0;i<json.userIndex.length;i++){
          // time
          var s=0+json.userIndex[i][2];
          var m=Math.floor(s/60);
          s-=m*60;
          var h=Math.floor(m/60);
          m-=h*60;
          var hms='';
          if(h<10) hms+='0';
          hms+=h;
          hms+=':';
          if(m<10) hms+='0';
          hms+=m;
          hms+=':';
          if(s<10) hms+='0';
          hms+=s;
          
          // flags
          var f=0+json.userIndex[i][3];
          var flags='';
          if ( f & 0x01 ) flags+=" Seen";
          if ( f & 0x02 ) flags+=" Answered";
          if ( f & 0x04 ) flags+=" Flagged";
          if ( f & 0x08 ) flags+=" Deleted";
          if ( f & 0x10 ) flags+=" Draft";
          if ( f & 0x20 ) flags+=" Recent";
          if ( f & 0x40 ) flags+=" NotMime";
          if ( f & 0x80 ) flags+=" Attachments";
          if ( f & 0x4000 ) flags+=" Voicemail";
          if ( f & 0x8000 ) flags+=" NotPopped";          
          
					data.push( [ 
						json.userIndex[i][0], 
						hms, 
						json.userIndex[i][1], 
						flags, 
						i 
					] );
				}
			}
			if ( dataTable == null ) {
				var config = {
					"aaData": data,
					"oLanguage": {
						"sEmptyTable": "(none set)"
					},
					"aoColumns": [
						{ "sTitle": "YYYYMMDD", "mRender": renderYYYYMMDD },
						{ "sTitle": "Time" },
						{ "sTitle": "File Id", "mRender": $.fn.dataTable.render.text() },
						{ "sTitle": "Flags" },
						{ "sTitle": "&nbsp;", "bSearchable": false }
					],
				};
				dataTable = $('#main_data_table').dataTable(config);
			}
			else {
				dataTable.fnClearTable();
				if (data.length) {
					dataTable.fnAddData( data );
				}
			}
		}
	});
}

$(document).ready(function(){
	loadTable();
});

//]]>
</script>

<?php
echo'<div class="legend">'.htmlspecialchars($_REQUEST['key']).' <input type=button value="&#x21e6; Back" class="btn btn-dark btn-sm" onclick="window.location=\'embed.php?doc=UserEdit.html&'.$urlTokenArg.'&edit='.urlencode($_REQUEST['key']).'&privateGroup='.urlencode($_REQUEST['pg']).'\'" /></div>';
?>
<i>Note: this is a raw archive of index entries in the order they were permanently purged and may or may not have an associated mail item based on log sweep and retention policy.</i>
<table cellspacing="0" cellpadding="0" class="mailtbl" style="border: 0; width: 100%; text-align: left;"><tr><td><a>Permanently Deleted Items</a></td></tr></table>
<table cellpadding="0" cellspacing="1" style="font-size: smaller;" class="display table-striped table-bordered nowrap w-100" id="main_data_table">
</table>