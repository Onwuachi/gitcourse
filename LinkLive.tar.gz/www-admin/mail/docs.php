<?php
if(!$revation->adminRight('ar_userlogs')){
	echo'NO RIGHTS';
	exit();
}
$urlTokenArg=$revation->getUrlTokenArg();
?>

<script type="text/javascript" src="mail/datetimes.js"></script>

<?php

$mailbox='$docs';
include'mail/folders.php';

echo'<script type="text/javascript">var json_docs='.$_DOCS['*'].';var fldrref="'.addslashes($_REQUEST['fldrref']).'".toLowerCase();</script>';
?>
<table style="width: 100%;" cellpadding="0" cellspacing="6">
<tr><td style="width: 20%; vertical-align: top;">

<table cellpadding="0" cellspacing="1" class="list" style="border: 1px solid silver;">
<tr><th colspan="2" class="mainline">Folders</th></tr>
<script type='text/javascript'>
	if (json_docs.length > 0) {
		for(var i=0;i<json_docs.length;i++){
			var str='<tr';
			if(json_docs[i].reference.toLowerCase() === fldrref){
				str+=' class="dragging"';
			}
			str+=' style="cursor: pointer;"';
			var loc='embed.php?php=mail/docs&<?=$urlTokenArg?>&vtop=1&pg=<?php echo urlencode($_REQUEST['pg']).'&key='.urlencode($_REQUEST['key']);?>&fldrref='+json_docs[i].reference;
			str+=' onclick="document.location=\''+loc+'\';"><td></td><td style="width: 99%;">&nbsp;<a href=\''+loc+'\' class="subjanch" style=\'line-height: 1em;\'>'+rwc_htmlescape(json_docs[i].descriptor.alias)+'</a></td></tr>\n';
			document.write(str);
		}
	}
	else{
		document.write('<tr><td colspan="2" style="text-align: center;">(no folders)</td></tr>');
	}
</script>
</table>
</td>

  
<td style="vertical-align: top;">
  <table cellpadding="0" cellspacing="1" class="list" style="font-size: smaller; border: 1px solid silver;">
	<tr>
	  <th style="width: 20%;">File Name</th>
	  <th>Size</th>
	  <th>Version</th>
	  <th style="width: 80%;">Latest Comment</th>
	  <th>Date</th>
	  <th>&nbsp;</th>
	</tr>
    <script type='text/javascript'>
	if (json_docs.length > 0 && fldrref && fldrref.length) {
    for(var i=0;i<json_docs.length;i++){
      if(json_docs[i].reference.toLowerCase() === fldrref){
        if(json_docs[i].descriptor.folders.length){
          for(var j=0;j<json_docs[i].descriptor.folders.length;j++){
            var li=json_docs[i].descriptor.folders[j].lastItem;
            if(li){
              var size=li.attachments.length?toBytesKbMb(li.attachments[0].appxsize):'&nbsp;';
              var fn=json_docs[i].descriptor.folders[j].name;
              var link="/download.php?filename="+escape(fn)+"&<?=$urlTokenArg?>&pg=<?php echo urlencode($_REQUEST['pg']).'&key='.urlencode($_REQUEST['key']);?>&cmd=mail-attachment&mailbox=%3c"+fldrref+"%3e"+escape(fn)+"&uid="+li.uid+"&att=0";
              var str="<tr><td><a href='"+link+"' target=_blank>"+rwc_htmlescape(fn)+"</a></td><td><nobr>"+size+"</nobr></td><td>"+li.uid+"</td><td>"+rwc_htmlescape(li.subject)+"</td><td><nobr>";
              str+=getModifyDateStr(li.headers.date);
              str+="</nobr></td><td>";
              str+="</td></tr>";
              document.write(str);
            }
          }
        }
        else{
	        document.write('<tr><td colspan="6" style="text-align: center; cursor: default; font-weight: bold">&nbsp;<br>THIS FOLDER IS EMPTY<br>&nbsp;</td></tr>');
        }
        break;
      }
		}
	}
  </script>

  </table>
  
</td>
</tr>
</table>