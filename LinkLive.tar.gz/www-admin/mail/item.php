<?php
if(!$revation->adminRight('ar_userlogs')){
	echo'NO RIGHTS';
	exit();
}
if(empty($parms)) {
	$urlTokenArg=$revation->getUrlTokenArg();
	$parms='&'.$revation->getUrlTokenArg().'&key='.urlencode($_REQUEST['key']).'&vtop=1&pg='.urlencode($_REQUEST['pg']);
}
$mailbox=$_REQUEST['mailbox'];
if(isset($_REQUEST['seq']))
	$seq=0+$_REQUEST['seq'];
else if(isset($_REQUEST['uid'])){
	$mi=$_MAILBOX[$mailbox]['uid:'+$_REQUEST['uid']];
	$seq=$mi['seq'];
}
else if(isset($_REQUEST['dbid'])){
	$mi=$_MAILBOX[$mailbox]['dbid:'+$_REQUEST['dbid']];
	$seq=$mi['seq'];
}
$next=isset($_MAILBOX[$mailbox][$seq+1]);
$mi=$_MAILBOX[$mailbox][$seq];
if(isset($_REQUEST['delatt']))
	$ok=$mi['attachments'][0+$_REQUEST['delatt']]['delete'];

include'mail/folders.php';

$nav='<table cellspacing="0" cellpadding="0" class="mailtbl" style="border: 0; width: 100%; text-align: left;"><tr><td><a href="embed.php?php=mail/';
if($seq>1)
	$nav=$nav+'item&seq='+($seq-1);
else
	$nav=$nav+'folder';
$nav=$nav+'&'.$urlTokenArg.'&mailbox='+urlencode($mailbox)+$parms+'">&lt;&lt;PREV</a> &nbsp; <a href="embed.php?php=mail/';
if($next)
	$nav=$nav+'item&seq='+($seq+1);
else
	$nav=$nav+'folder';
$nav=$nav+'&'.$urlTokenArg.'&mailbox='+urlencode($mailbox)+$parms+'">NEXT&gt;&gt;</a></td></tr></table>';
?>
<script type='text/javascript' src='MultiFileAudioPlayer.js'></script>
<script type="text/javascript" src='mail/datetimes.js'></script>

<?php echo $nav; echo"<br/>\n";?>

<table style="width: 100%; text-align: left; font-size: smaller; border-bottom: .5em solid #1c394f;" cellspacing="0" cellpadding="3">
	<tr>
		<td>From:</td>
		<td id=rwc_from></td>
	</tr>
	<tr>
		<td>Date:</td>
		<td><b><script type="text/javascript">outputModifyDate('<?=$mi['date']?>');</script></b>&nbsp;
		<?php if(!$revation->adminPrivateView())echo'<div style="float: right"><a href="embed.php?php=mail/dbitem&'.$urlTokenArg.'&vtop=1&dbid='.urlencode($mi['dbid']).'%2f'.urlencode($_REQUEST['key']).'">'.$mi['dbid'].'</a> '.$mi['uid'].'</div>';?></td>
	</tr>
	<tr>
		<td>To:</td>
		<td><b><?=htmlspecialchars($mi['to'])?></b>&nbsp;</td>
	</tr>

<?php
$cc=$mi['cc'];
if($cc){
		echo'<tr><td>Cc:</td><td><b>';
		echo htmlspecialchars($cc);
		echo'</b>&nbsp;</td></tr>';
}
?>
		<tr>
			<td style="width: 10%;">Subject:</td>
			<td width="80%"><b><?php
				if($mi['flagged'])
						echo'<img alt="flagged" src="mail/flagged.png" border=0/> ';
				if(empty($mi['subject']))
						echo'(no subject)';
				else
						echo htmlspecialchars($mi['subject']);
			?></b>&nbsp;</td>
		</tr>
<?php
if(sizeof($mi['attachments'])){
		echo'<tr><td><img src="mail/attpic.png" border=0></td><td>';
		$i=0;
		while($mi['attachments'][$i]){
				if($i>0)
					echo", &nbsp;";
				$name=$mi['attachments'][$i]['name'];
				echo'<a target="_blank" href="/download.php?filename='.urlencode($name).'&'.$urlTokenArg.'&cmd=mail-attachment&mailbox='+urlencode($mailbox)+'&uid='+$mi['uid']+'&att='.$i.$parms.'">'.htmlspecialchars($name).'&nbsp;('.$mi['attachments'][$i]['sizestr'].')</a>';
				if($name=="conference.wav"){
					echo' <script type="text/javascript">audioPlayer.writeButton("'.$name.'", "cmd=mail-attachment&mailbox='+urlencode($mailbox)+'&uid='+$mi['uid']+'&translate=8k16bm&att='.$i.$parms.'");</script>';
					if($revation->adminRight('ar_delatt'))
						echo'&nbsp;<input type="button" style="display: inline;" class="btn btn-secondary btn-sm" onclick="return deleteWavFile('.$i.');" value="Delete"/>';
				}
				$i=$i+1;
		}
		echo'</td></tr>';
}
if(sizeof($mi['shares'])){
		echo'<tr><td title="shares"><img src="mail/attshare.png" border=0></td><td>';
		$i=0;
		while($mi['shares'][$i]){
				if($i>0)
					echo', &nbsp;';
				echo'<a href="mail-shareviewer.php?share='.$i.$parms.'" target="_blank">'.$mi['shares'][$i]['name'].'&nbsp;('.$mi['shares'][$i]['sizestr'].')</a>';
				$i=$i+1;
		}
		echo'</td></tr>';
}

?>
		
</table>

<table border="0" cellspacing="0" cellpadding="0" style="width: 100%; background-color: #ffffff; text-align: left; font-size: smaller;"><tr><td id="mailbody">
<?=$mi['htmlbody']?>
</td></tr></table>
<script type="text/javascript">
  changeSessionTimes("<?=$mi['logtimestr']?>");
  function deleteWavFile(att){
	if(confirm('Are you sure you want to delete this conference file?  It cannot be un-done and the action will be logged!')){
		window.location='embed.php?php=mail/item&delatt='+att+'<?='&seq='.$seq.'&mailbox='.urlencode($mailbox).$parms?>';
	}
	return false;
  }
  convert_links();

  var mail_from=<?=json_encode($mi['from'])?>;
  var mail_sender=<?=json_encode($mi['sender'])?>;
  var mail_from_html = '<b>'+rwc_htmlescape(mail_from)+'</b>';
  if(typeof mail_from==='string' && mail_from.length && typeof mail_sender==='string' && mail_sender.length && mail_from != mail_sender){
	mail_from_html = '<b>'+htmlEscape(mail_sender)+'</b> <span>on behalf of</span> '+mail_from_html;
  }
  $("#rwc_from").html(mail_from_html+'&nbsp;');

</script>

<?php echo"<br/>\n"; echo $nav;?>