<?php
if(!$revation->adminRight('ar_userlogs')){
	echo'NO RIGHTS';
	exit();
}

$mailbox='$av';
include'mail/folders.php';
$revation->config('user-forwarders');
$urlTokenArg=$revation->getUrlTokenArg();
?>

<link rel='stylesheet' href='mail/forwarding.css' type='text/css' />
<script src='../js/Sortable.min.js' type='text/javascript'></script>
<script src='mail/forwarding.js' type='text/javascript'></script>

<form method="post" name="form" action="embed.php?<?=$urlTokenArg?>">
<input type="hidden" name="php" value="mail/forwarding"/>
<input type="hidden" name="key" value="<?=htmlspecialchars($_REQUEST['key'])?>"/>
<input type="hidden" name="pg" value="<?=htmlspecialchars($_REQUEST['pg'])?>"/>
<input type="hidden" name="vtop" value="1"/>
<input type="hidden" name="order" value=""/>

<div id="changes" style="color: green; font-weight: bold;">
<?php
if($_EVENT['ForwardersSaved'])
	echo'Your changes were saved.';
else
	echo'&nbsp;';
?>
</div>

<div class='sortlist sortlist_header'>&nbsp</div>
<div id='forwarding_list'></div>
<div class='sortlist sortlist_footer'>
<button class='btn btn-secondary btn-sm' onclick="doSave();return false;">Save Changes</button>
<button class='btn btn-secondary btn-sm' onclick="checkCancel('<?php echo '&vtop=1&key='+urlencode($_REQUEST['key'])+'&pg='+urlencode($_REQUEST['pg']); ?>');return false;">Cancel Changes</button>
<button class='btn btn-secondary btn-sm' onclick="popHelp();return false;">Help</button>
<button class='btn btn-secondary btn-sm' onclick="addRow(this);return false;">Add Forwarder</button>
</div>

</form>

<script type="text/javascript">
var jo = null;
try {
	jo = <?=$_FORWARDING['json']?>;
} catch (e) {
	jo = null;
}
if(jo){
	outputTimeZone(jo.forwarders.profile.timeZone);
}
forwarding_init(jo);
</script>
