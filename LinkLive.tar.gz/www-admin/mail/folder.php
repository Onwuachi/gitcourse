<script type="text/javascript" src="mail/datetimes.js"></script>

<?php
if(!$revation->adminRight('ar_userlogs')){
	echo'NO RIGHTS';
	exit();
}

if(!$mailbox)
	$mailbox=$_REQUEST['mailbox'];
if(!$mailbox)
	$mailbox='Inbox';

include'mail/folders.php';

echo'<table cellpadding="0" cellspacing="1" class="list" style="font-size: smaller;">';
echo'<tr><th style="min-width: 16px;">&nbsp;</th><th style="min-width: 16px;">&nbsp;</th><th style="min-width: 16px;">&nbsp;</th><th>From</th><th>To</th><th>Subject</th><th>Date</th><th>Size</th></tr>';
$mi=$_MAILBOX[$mailbox]['last'];
if($mi){
		$items=$mi['seq'];
		$page_size=20;
		if($_REQUEST['date_end']){
			$mi=$_MAILBOX[$mailbox]['date_end:'+$_REQUEST['date_end']];
			if($mi){
				$page=$items-$mi['seq'];
				$page=$page/$page_size;
			}
			else{
				$page=0;
			}
		}
		else{
			$page=0+$_REQUEST['page'];
		}
		$start=$items-$page*$page_size;
		$end=$start-$page_size+1;
		if($end<1)
			$end=1;
		$seq=$start;
		if(!$mi||$mi['seq']!=$seq)
			$mi=$_MAILBOX[$mailbox][$seq];
		while($mi&&$seq>=$end){
			if($mi['unread'])
				$class='mailunread';
			else
				$class='mailread';
			$attcnt=sizeof($mi['attachments']);
			if($attcnt)
				$att='<img alt="'.$attcnt.' attachment(s)" src="mail/attpic.png" border=0/>';
			else
				$att='';
			if($mi['flagged'])
				$flag='<img alt="flagged" src="mail/flagged.png" border=0/>';
			else
				$flag='';
			if($mi['replied'])
				$rep='<img alt="replied" src="mail/replypic.png" border=0/>';
			else
				$rep='&nbsp;';
			$from=htmlspecialchars($mi['from']);
			if(empty($from))
				$from='&nbsp;';
			$to=htmlspecialchars($mi['to']);
			if(empty($to))
				$to='&nbsp;';
			echo"<tr class='{$class}'><td>{$att}</td><td>{$rep}</td><td>{$flag}</td><td>{$from}</td><td>{$to}</td><td><a href='embed.php?php=mail/item&mailbox=".urlencode($mailbox)."&seq=".$seq.$parms."'>";
			if(empty($mi['subject']))
				echo'(no subject)';
			else
				echo htmlspecialchars($mi['subject']);
			echo"</a></td><td><nobr><script type='text/javascript'>outputModifyDate('".$mi['date']."');</script><noscript>".$mi['date']."</noscript></nobr></td><td><nobr>".$mi['mimesizestr']."</nobr></td></tr>\n";
			$seq=$seq-1;
			$mi=$_MAILBOX[$mailbox][$seq];
		}

		echo'</table><br/><table class="mailtbl" style="color: #999; width: 100%; text-align: left;"><tr><td>[messages '.($items-$start+1).' - '.($items-$seq).' of '.$items.']&nbsp;';
		if($end>1)
			echo'<a href="embed.php?php=mail/folder&mailbox='.urlencode($mailbox).'&page='.($page+1).$parms.'">&lt;&lt;NEXT</a> ';
		else
			echo'NEXT ';
		if($page>0)
			echo'<a href="embed.php?php=mail/folder&mailbox='.urlencode($mailbox).'&page='.($page-1).$parms.'">LAST&gt;&gt;</a>';
		else
			echo'LAST';
		echo'</td><td style="text-align: right;">jump to date <span style="font-size: 75%;">(YYYYMMDD or MM/DD/YYYY)</span>: <form style="display: inline;" method="post"><input type=text name=date_end size=10 maxsize=10><input type=submit name=Jump class="btn btn-secondary btn-sm">'.$hiddenkey.'<input type=hidden name=pg value="'.htmlspecialchars($_REQUEST['pg']).'"><input type=hidden name=mailbox value="'.htmlspecialchars($_REQUEST['mailbox']).'"><input type=hidden name=php value="mail/folder"><input type=hidden name=vtop value=1></form></td></tr></table>';
}
else{
	echo'<tr><td class="mailread" colspan="8" align="center"><b>THIS FOLDER IS EMPTY.</b></td></tr></table>';
}

?>