﻿var dayOfWeekString = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function toBytesKbMb(sz) {
    if (sz < 1000) {
        // just output 1-3 digit bytes
        return '' + sz + ' bytes';
    }
    else {
        // convert to kilobytes
        sz /= 1024;
        if (sz <= 999) {
            // just output 1-3 digit kilobytes
            return '' + Math.round(sz) + ' KB';
        }
        else if (sz < 10000) {
            // output as x.y MB
            sz /= 1024;
            return sz.toFixed(1) + ' MB';
        }
        else {
            // output a full rounded MB
            return '' + Math.round(sz / 1024) + ' MB';
        }
    }
}

var gmt_min_offset_of_view = null;

function getModifyDateStr(dstr) {
    // convert to a date object
    var d = new Date(dstr);
    if (!isNaN(d)) {
        // save the view offset
        gmt_min_offset_of_view = -d.getTimezoneOffset();

        // if it's today
        var now = new Date();
        if (d.getFullYear() == now.getFullYear() && d.getMonth() == now.getMonth() && d.getDate() == now.getDate()) {
            // output a "today" string
            return "Today, " + d.toLocaleTimeString();
        }
        else {
            // just output the date
            return dayOfWeekString[d.getDay()] + ", " + (d.getMonth() + 1) + "/" + d.getDate() + "/" + d.getFullYear() + " " + d.toLocaleTimeString();
        }
    }
    return typeof dstr === 'string' ? dstr : '';
}

function outputModifyDate(dstr) {
    document.write(getModifyDateStr(dstr));
}

function consolidate_translations() {
    let divs = $('#mailbody div[data-id]');
    if (divs) {
        let divs_to_delete = [];
        for (div of divs) {
            let id = div.dataset.id;
            let lang = div.dataset.lang;
            let main_div = $('#' + id);
            if (main_div.length == 0) {
                div.setAttribute('id', id);
            }
            else {
                let uwrite_div = div.getElementsByClassName('uwrite')[0];
                if (lang) {
                    let html = '<b>[' + lang + ']:</b>&nbsp;' + uwrite_div.innerHTML;
                    uwrite_div.innerHTML = html;
                }
                main_div[0].appendChild(uwrite_div);
                divs_to_delete.push(div);
            }
        }
        for (div of divs_to_delete) {
            div.remove();
        }
    }
}

function changeSessionTimes(logTimeString) {
    consolidate_translations();

    if (typeof gmt_min_offset_of_view !== 'number') {
        // we don't have a view offset
        return;
    }
    if (typeof logTimeString !== "string" || logTimeString.length < 21 || logTimeString.charAt(8) != 'T' || !(logTimeString.charAt(15) == '+' || logTimeString.charAt(15) == '-')) {
        // nothing to do, this isn't a log-time string
        return;
    }

    // determine the gmt offset of the log
    gmt_min_offset_of_log = parseInt(logTimeString.substring(16, 18), 10) * 60 + parseInt(logTimeString.substring(19, 21), 10);
    if (logTimeString.charAt(15) == '-') {
        gmt_min_offset_of_log = -gmt_min_offset_of_log;
    }

    // using the gmt offset of the view at the time of the log, determine the gmt difference
    var gmt_min_delta = gmt_min_offset_of_view - gmt_min_offset_of_log;
    if (gmt_min_delta != 0) {
        // need to make an adjustment
        var elements = $('#mailbody .time');
        var n = elements.length;
        for (var i = 0; i < n; i++) {
            var e = elements[i];
            if (e.innerText && e.innerText.length >= 10 && e.innerText.substr(0, 1) === '[' && e.innerText.substr(9, 1) === ']') {
                var hr = parseInt(e.innerText.substring(1, 3), 10);
                var min = parseInt(e.innerText.substring(4, 6), 10);
                var mins = hr * 60 + min + gmt_min_delta;
                hr = Math.floor(mins / 60);
                min = mins - hr * 60;
                if (hr < 0) {
                    hr += 24;
                }
                else if (hr > 23) {
                    hr -= 24;
                }
                var hr_min;
                if (hr == 0) {
                    hr_min = '12';
                }
                else if (hr < 10) {
                    hr_min = '0' + hr;
                }
                else {
                    hr_min = '' + hr;
                }
                hr_min += ':';
                if (min < 10) {
                    hr_min += '0';
                }
                hr_min += min;
                e.innerHTML = '[' + hr_min + e.innerText.substring(6);
            }
        }
    }
}

function convert_links() {
    var e = $('#mailbody a');
    for (var i = 0; i < e.length; ++i) {
        var a = e[i].getAttribute('target');
        if (typeof a !== 'string' || !a.length) {
            e[i].setAttribute('target', '_blank');
        }
    }
    e = $('#mailbody img');
    for (var i = 0; i < e.length; ++i) {
        var a = e[i].getAttribute('src');
        if (typeof a === 'string' && a.substr(0, 4) === 'cid:') {
            e[i].setAttribute('src', '/object?cmd=mail-embedded&' + urlTokenArg + '&cid=' + a.substr(4));
        }
    }
}

function selectParticipantView() {
    var p = $('#participant').val();
    var components = $('#dbid').val().split('/');
    if (components.length === 4) {
        $('#dbid').val(components[0] + '/' + components[1] + '/' + components[2] + '/' + p);
        $('#dbid_search').submit();
    }
}

function createParticipantSelect(element, participants) {
    element = $('#' + element);
    if (!element.length || !participants || participants.length <= 1) {
        return;
    }

    var email = null;
    var components = $('#dbid').val().split('/');
    if (components.length === 4) {
        email = components[3].toLowerCase();
    }

    var html = '<select id="participant" onchange="selectParticipantView();return false;">';
    for (var i = 0; i < participants.length; ++i) {
        if (participants[i].toLowerCase() === email) {
            html += '<option selected>';
        }
        else {
            html += '<option>';
        }
        html += rwc_htmlescape(participants[i]) + '</option>';
    }
    html += '</select>';
    element.html(html);
}
