<!DOCTYPE html>
<html>
<?php
$mailbox=$_REQUEST['mailbox'];
$mi=$_MAILBOX[$mailbox]['uid:'+$_REQUEST['uid']];
$num=0+$_REQUEST['share'];
?>
<head>
<meta charset="utf-8" />
<script type="text/javascript">
var rds_imgstr=<?php echo'"shareimg.php?session='.$_SESSION.'&mailbox='.urlencode($mailbox).'&uid='.$mi['uid'].'&share='.$num.'&time="';?>;
var rds_start=<?php echo $mi['shares'][$num]['start'];?>;
var rds_end=<?php echo $mi['shares'][$num]['end'];?>;
var slider_min=0
var slider_max=rds_end-rds_start;
var slider_basePx=0;
var slider_extentPx=0;
var slider_thumb_width=24;
var slider_value=0;
var rwc_oldMouseMove=null;
var rwc_oldMouseUp=null;
var rwc_dragOffsetX=0;
function rwc_fetchFrame(){
    var img=document.getElementById("rwc_mainimg");
    if(img){
        img.src=rds_imgstr+slider_value;
    }
}
function rwc_findPos(obj){
	var offsetLeft=0;
	var offsetTop=0;
	while(obj){
		offsetLeft+=obj.offsetLeft;
		offsetTop+=obj.offsetTop;
		obj=obj.offsetParent;
	}
	if(navigator.userAgent.indexOf("Mac")!=-1&&typeof document.body.leftMargin!="undefined"){
		offsetLeft+=document.body.leftMargin;
		offsetTop+=document.body.topMargin;
	}
	return{left:offsetLeft,top:offsetTop};
}
function rwc_getHMS(val){
    var s=val%60;
    val=Math.floor(val/60);
    var m=val%60;
    var h=Math.floor(val/60);
    var t="";
    if(h>0){
        t+=h+':'
    }
    if(m<10&&h>0)
        t+='0';
    t+=m+':';
    if(s<10)
        t+='0';
    t+=s;
    return t;
}
function rwc_setSliderValue(val,set){
    if(val<slider_min)
        val=slider_min;
    else if(val>slider_max)
        val=slider_max;
    var pxleft=Math.round(val/(slider_max-slider_min)*slider_extentPx);
    document.getElementById("slider_pos").style.left=pxleft;
    document.getElementById("slider_value").value=rwc_getHMS(val);
    if(set&&slider_value!=val){
        slider_value=val;
        rwc_fetchFrame();
    }
}
function rwc_setSliderHMS(val){
    var c=val.split(":",3);
    var h=0,m=0,s;
    if(c.length==3){
        h=parseInt(c[0]);
        if(isNaN(h))
            h=0;
        m=parseInt(c[1]);
        s=parseInt(c[2]);
    }
    else if(c.length==2){
        m=parseInt(c[0]);
        s=parseInt(c[1]);
    }
    else{
        s=parseInt(c[0]);
    }
    if(isNaN(m))
        m=0;
    if(isNaN(s))
        s=0;
    rwc_setSliderValue((h*60+m)*60+s,true);
}
function rwc_frameAdj(delta){
    rwc_setSliderValue(slider_value+delta,true);
}
function rwc_setSliderPct(pct,set){
    rwc_setSliderValue(Math.round(pct*(slider_max-slider_min))+slider_min,set);
}
function rwc_setSliderPos(pos,set){
	rwc_setSliderPct((pos-slider_basePx)/slider_extentPx,set);
}
function rwc_resizeEvent(){
    slider_basePx=rwc_findPos(document.getElementById("slider_bkgnd")).left;
    slider_extentPx=rwc_findPos(document.getElementById("slider_tail")).left-slider_basePx-slider_thumb_width;
    rwc_setSliderValue(slider_value,false);
}
function rwc_sliderJump(e){
    if(e==null)
	    e=window.event;
	rwc_setSliderPos(e.clientX,true);
}
function rwc_dragging(e){
    if(e==null)
	    e=window.event;
	rwc_setSliderPos(e.clientX-rwc_dragOffsetX,false);
    return false;
}
function rwc_dragStop(e){
    if(e==null)
	    e=window.event;
	document.onmousemove=rwc_oldMouseMove;
	rwc_oldMouseMove=null;
	document.onmouseup=rwc_oldMouseUp;
	rwc_oldMouseUp=null;
	rwc_setSliderPos(e.clientX-rwc_dragOffsetX,true);
    return false;
}
function rwc_dragStart(e){
    if(e==null)
	    e=window.event;
	rwc_oldMouseMove=document.onmousemove;
	document.onmousemove=rwc_dragging;
	rwc_oldMouseUp=document.onmouseup;
	document.onmouseup=rwc_dragStop;
	document.body.focus();//cancel any text selection
	rwc_dragOffsetX=e.clientX-(0+rwc_findPos(document.getElementById("slider_pos")).left);
	rwc_setSliderPos(e.clientX-rwc_dragOffsetX,false);
    return false;
}
function rwc_killEvent(e){
    if(e==null)
	    e=window.event;
    if(e.stopPropagation)
        e.stopPropagation();
    else
        e.cancelBubble=true;
    return false;
}
window.onresize=rwc_resizeEvent;
</script>
</head>
<body onload="rwc_resizeEvent();rwc_fetchFrame();">

Share of <?=htmlspecialchars($mi['shares'][$num]['name'])?>, total time: <script type="text/javascript">document.write(rwc_getHMS(slider_max));</script>, viewing: <input id="slider_value" type="text" size="9" onchange="rwc_setSliderHMS(this.value);"/><br />
<table style="width:100%; height: 16px; line-height: 1px;" cellpadding="0" cellspacing="0">
<tr>
<td style="width: 16px; height: 16px;"><img alt="reverse one segment" src="mail/slider-step-back.gif" style="width: 16px; height: 16px;" onclick="rwc_frameAdj(-1);"></td>
<td id="slider_bkgnd" style="background-image: url(mail/slider-line.gif);" onclick="rwc_sliderJump(event);"><img src="mail/slider-thumb.gif" id="slider_pos" style="width: 24px; height: 16px; position: relative; cursor: w-resize;" onmousedown="return rwc_dragStart(event);" onclick="return rwc_killEvent(event);"></td>
<td id="slider_tail" style="width: 16px; height: 16px;"><img alt="advance one segment" src="mail/slider-step-forward.gif" style="width: 16px; height: 16px;" onclick="rwc_frameAdj(1);"></td>
</tr>
</table>

<script type="text/javascript">document.write('<img id="rwc_mainimg" src="'+rds_imgstr+slider_value+'">');</script>

</body>
</html>