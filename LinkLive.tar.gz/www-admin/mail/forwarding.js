﻿var madeChanges = false;
var bypassUnloadCheck = false;
var nextRow = 1;

var msg = 'There are unsaved changes.  If you continue, you will lose your changes.';

function setChanged() {
    if (!madeChanges) {
        madeChanges = true;
        var div = document.getElementById("changes");
        if (div) {
            div.style.color = 'red';
            div.innerHTML = 'Changes have not been saved!';
        }
    }
}

function checkUnload() {
    if (!madeChanges || bypassUnloadCheck) {
        return;
    }
    return msg;
}

function checkCancel(info) {
    if (!madeChanges || confirm(msg)) {
        bypassUnloadCheck = true;
        document.location = 'embed.php?php=mail/forwarding&'+getUrlTokenArg()+info;
    }
}

function doSave() {
    // we're saving, skip unload
    bypassUnloadCheck = true;

    var rows = $("[id^=forwarding_row_]");

    var results = "";
    for (var i = 0; i < rows.length; i++) {
        results += "/" + $(rows[i]).attr('id').substr(15);   // remove 'forwarding_row_'
    }

    // put order results in form
    document.form.order.value = results;

    // do the submit
    document.form.submit();
}

function deleteRow(e) {
    if (confirm('Are you sure you want to delete this row?')) {
        $(e).closest('div').remove();
        setChanged();
    }
    return false;
}

function toggleAdvanced(row) {
    var button = $("#advanced" + row);
    var div = button.nextAll('div');
    var span = button.find('span');
    if (div.css('display') === 'none') {
        div.css('display', 'block');
        span.html('&#x25BC;');
    }
    else {
        div.css('display', 'none');
        span.html('&#x25B6;');
    }
}

function doCheckAdvanced(checked) {
    var b = "<button class='btn btn-secondary btn-sm' id='advanced" + nextRow + "' onclick='toggleAdvanced(" + nextRow + "); return false;'><span>";
    if (checked) {
        b += "&#x25BC;";
    }
    else {
        b += "&#x25B6;";
    }
    return b + "</span> advanced</button> ";
}

function doCheck(name, title, checked) {
    name += nextRow;
    var i = "<label><input onchange='setChanged();' type=checkbox name=" + name + " id=" + name;
    if (checked) {
        i += " checked=checked";
    }
    i += " /> " + title + "</label> &nbsp; ";
    return i;
}

function doInput(name, title, size, value) {
    var i = title + ": <input onchange='setChanged();' name=" + name + nextRow + " id=" + name + nextRow;
    if (name == "nums") {
        i += " type='text' placeholder='number(s)' style='width: 30%;'";
    }
    else if (name == "secs") {
        i += " type='number' min='0' max='999' placeholder='secs'";
    }
    else {
        i += " type='text'";
    }
    if (size > 0) {
        i += " size=" + size + " maxlength=" + size;
    }
    if (typeof value === 'string') {
        i += " value='" + value.replace("'", "&apos;") + "'";
    }
    else if (typeof value === 'number' && !isNaN(value)) {
        i += " value='" + value + "'";
    }
    if (name == "notes") {
        i += " style='width: 50%;'";
    }
    return i + "> &nbsp; ";
}

function doRowHTML(f) {
    var line = doInput("nums", "number(s) to ring", 0, f ? f.nums : null);
    line += doInput("secs", "seconds to ring", 3, f ? f.secs : null);
    
    var fs = f && f.schedule ? f.schedule : null;
    var fp = f && f.status ? f.status : null;
    var showAdv = f && (f.notes || f.except || f.allow || f.disable || f.copylog || f.keepallcalls || f.simultaneous || (fs && (fs.from || fs.to)) || fp);
    line += doCheckAdvanced(showAdv);
    line += "<input type=button value=delete class='btn btn-secondary btn-sm' onclick='return deleteRow(this);'><div";
    
    if (!showAdv) {
        line += " style='display: none;'";
    }
    line += ">";
    line += doCheck("disable", "disable this forwarder", f ? f.disable : 0);
    line += doCheck("simultaneous", "ring with previous", f ? f.simultaneous : 0);
    line += doCheck("copylog", "copy session to log", f ? f.copylog : 0);
    line += doCheck("keepallcalls", "keep all calls", f ? f.keepallcalls : 0);
    line += "<br/>";

    line += doCheck("mon", "mon", fs ? fs.days.indexOf('mon') >= 0 : 1);
    line += doCheck("tue", "tue", fs ? fs.days.indexOf('tue') >= 0 : 1);
    line += doCheck("wed", "wed", fs ? fs.days.indexOf('wed') >= 0 : 1);
    line += doCheck("thu", "thu", fs ? fs.days.indexOf('thu') >= 0 : 1);
    line += doCheck("fri", "fri", fs ? fs.days.indexOf('fri') >= 0 : 1);
    line += doCheck("sat", "sat", fs ? fs.days.indexOf('sat') >= 0 : 1);
    line += doCheck("sun", "sun", fs ? fs.days.indexOf('sun') >= 0 : 1);
    line += doInput("from", "from", 8, fs ? fs.from : null);
    line += doInput("to", "to", 8, fs ? fs.to : null);
    
    line += "<br/>Only if my status is: ";
    line += doCheck("offline", "offline", fp ? fp.indexOf('offline') >= 0 : 1);
    line += doCheck("online", "online", fp ? fp.indexOf('online') >= 0 : 1);
    line += doCheck("onthephone", "on the phone", fp ? fp.indexOf('onthephone') >= 0 : 1);
    line += doCheck("berightback", "be right back", fp ? fp.indexOf('berightback') >= 0 : 1);
    line += doCheck("outtolunch", "out to lunch", fp ? fp.indexOf('outtolunch') >= 0 : 1);
    line += doCheck("busy", "busy", fp ? fp.indexOf('busy') >= 0 : 1);
    line += doCheck("away", "away", fp ? fp.indexOf('away') >= 0 : 1);

    line += "<br/>";
    line += doInput("except", "except if from", 0, f ? f.except : null);
    line += doInput("allow", "only if from", 0, f ? f.allow : null);

    line += "<br/>";
    line += doInput("notes", "notes", 0, f ? f.notes : null);

    line += "</div>";
    
    nextRow++;
    return line;
}

function writeRow(forwarder) {
    $('#forwarding_list').append('<div class="sortlist sortlist_item" id="forwarding_row_' + nextRow + '">' + doRowHTML(forwarder) + '</div>');
    nextRow++;
}

function addRow(e) {
    writeRow();
    change_made();
}

function outputTimeZone(timeZone) {
    var str = "<br/><div style='text-align: center;'>Timezone is set as " + timeZone.name + " where the current time is ";

    var dt = new Date();
    dt.setTime(dt.getTime() + timeZone.offsetMin * 60 * 1000);
    str += dt.getUTCHours() + ':';
    if (dt.getUTCMinutes() < 10) {
        str += '0';
    }
    str += dt.getUTCMinutes() + ':';
    if (dt.getUTCSeconds() < 10) {
        str += '0';
    }
    str += dt.getUTCSeconds();

    str += ".  Current time of browser/computer is ";
    dt = new Date();
    str += dt.getHours() + ':';
    if (dt.getMinutes() < 10) {
        str += '0';
    }
    str += dt.getMinutes() + ':';
    if (dt.getSeconds() < 10) {
        str += '0';
    }
    str += dt.getSeconds();

    str += '</div>';

    document.write(str);
}

function popHelp() {
    // create the dialog
    var dlg = $('#help');
    if (!dlg.length) {
        $('body').append(
            '<div class="modal fade text-center" role="dialog" id="help" title="Help on forwarding">\
            <div class="modal-dialog" role="document" style="padding-top: 15%; text-align: left; max-width: 100%; width: auto !important; display: inline-block;" >\
            <div class="modal-content" style="overflow: auto;">\
            <div class="modal-header light-background">\
            <h5 class="modal-title">Help on forwarding</h5>\
            <button type="button" class="close" data-dismiss="modal">&times;</button>\
            </div>\
            <div class="modal-body">\
            If there are <u>any</u> forwarders configured, then calls to the account will result \
            in the system ringing each configured forwarder one at a time in order from \
            top to bottom, until either one answers, or it reaches the end of the list. \
            If the end of the list is reached, the call ends, so if you want to have \
            voicemail, configure that as the last entry.\
            <br/><br/>\
            The <b><i>number(s) to ring</i></b> are the accounts to ring.  If more than one is \
            configured (comma-separated) then all will ring at the same time. \
            If one answers, then all others will stop ringing and forwarding is complete. \
            Exception: if <b><i>keep all calls</i></b> is checked, the non-answering numbers will continue.\
            <br/><br/>\
            Configure the forwarder for a number of <b><i>seconds to ring</i></b>.  If there is no answer \
            in that amount of time, ringing stops and the next forwarder is tried.\
            <br/><br/>\
            Under <b><i>advanced options:</i></b>\
            <br/><br/>\
            Use <b><i>disable this forwarder</i></b> to temporarily bypass a configured forwarder.\
            <br/><br/>\
            Use <b><i>ring with previous</i></b> to configure a forwarder to ring at the same time \
            as the previous forwarder instead of waiting until it times out.  This can be useful \
            to have different ring times or schedules.\
            <br/><br/>\
            Use <b><i>copy session to log</i></b> to have the server put a copy of the session in your \
            account session log if the forwarder is the one that answers.  Note that you would normally \
            not do that if your forwarder has or is the main account (since it automatically gets a copy), \
            nor would you put it on a voicemail forwarder since it too would already be keeping a copy.\
            <br/><br/>\
            Use <b><i>keep all calls</i></b> if all ringing calls on a forwarder should continue ringing \
            past the first one answering instead of terminating.\
            <br/><br/>\
            To schedule a forwarder to only be active for a certain time period, use the \
            day-of-week checkboxes (e.g. <b><i>monday</i></b>) and enter a <b><i>from</i></b> and <b><i>to</i></b> time in \
            either 12-hour (e.g. 5:30pm) or 24-hour (e.g. 17:30) time format.\
            <br/><br/>\
            Use <span style="font-weight: bold; font-style: italic;">except if from</span> to have a forwarder only be active if the entered pattern is <span style="text-decoration: underline;">not</span> \
            contained in the caller identifier.  Oppositely, use <span style="font-weight: bold; font-style: italic;">only if from</span> to have a forwarder \
            only be active if the entered pattern <span style="text-decoration: underline;">is</span> contained in the caller identifier.\
            <div class="modal-footer">\
            <button type="button" class="btn light-background" data-dismiss="modal">Cancel</button>\
            </div>\
            </div>\
            </div>\
            </div>\
            </div>\
        </div>');
        dlg = $('#help');
    }
    dlg.modal('show')
}

function forwarding_init(jo) {
    if (typeof jo === 'object') {
        if (jo.forwarders.forwarder) {
            for (i = 0; i < jo.forwarders.forwarder.length; i++) {
                writeRow(jo.forwarders.forwarder[i]);
            }
        }
        var custom;
        if (typeof (jo.forwarders.profile.redirUncond) == "string" && jo.forwarders.profile.redirUncond.length) {
            custom = "Unconditional forward to: " + rwc_htmlescape(jo.forwarders.profile.redirUncond);
        }
        else {
            custom = "Redirect on no-answer to: " + rwc_htmlescape(jo.forwarders.profile.redirNoAns.text) + " after " + jo.forwarders.profile.redirNoAns.delay + " seconds<br/>";
            custom += "Redirect when offline to: " + rwc_htmlescape(jo.forwarders.profile.redirOffline);
        }
        if (custom) {
            document.write('<br/><div style="text-align: center;">If there are no forwarders configured, the default behavior is:<p style="margin-left: 1em;">' + custom + '</div>');
        }
    }

    var sl = $('#forwarding_list');
    if (sl.length) {
        var s = Sortable.create(sl[0], {
            animation: 150,
            onUpdate: function (evt) {
                change_made();
            }
        });
    }
}