<?php
$revation->config('autoAssistant');
include 'tableTop.php';
$urlTokenArg=$revation->getUrlTokenArg();
?>

<script>

var assistants = null;
var dataTable = null;

function renderStatus( data, type, full ) {
	if(type=='display'){
		return statusImage(data);
	}
	else {
		return data;
	}
}

function renderPid( data, type, full ) {
	if(type=='display'){
		var html = '<div class="dropdown">' +
			'<button class="btn btn-secondary btn-xs" id="menub-'+data+'" data-toggle="dropdown" title="Menu for ' + rwc_htmlescape(assistants[full[1]].autoassistant) + '" href="#">&#x2699;</button>' +
			'</div>'+
			'<a href="embed.php?doc=AutoAssistant.html&<?=$urlTokenArg?>&edit='+encodeURIComponent(assistants[full[1]].autoassistant)+'&pg='+encodeURIComponent(assistants[full[1]].group)+'">' +
			rwc_htmlescape(assistants[full[1]].autoassistant) +
			'</a>';
		return html;
	}
	else{
		return assistants[full[1]].autoassistant;
	}
}

function renderTotal( data, type, full ) {
	if(type=='display'){
		return '<button class="btn btn-secondary btn-xs" onclick="window.location=\'embed.php?doc=AutoAssistantActive.html&<?=$urlTokenArg?>&aa='+assistants[full[1]].autoassistant+'&pg='+assistants[full[1]].group+'\';return false;">'+data+'</button>';
	}
	else {
		return data;
	}
}

function openPopup(event,i) {
	closeMenus();
	event.stopImmediatePropagation();
	var mb=$('#menub-'+i);
	var m=$('#menu-'+i);

	if (m.length) {
		m.remove();
	}
	else {
		var html=
			'<ul id="menu-'+i+'" class="dropdown-menu" onclick="closeMenus();">'+
			'<li class="dropdown-header menu-header">Auto Assistant</li>'+
			'<li class="dropdown-item addCursorPointer hover" onclick="closeMenus(); window.location=\'embed.php?doc=AutoAssistant.html&<?=$urlTokenArg?>&edit='+encodeURIComponent(assistants[i].autoassistant)+'&pg='+encodeURIComponent(assistants[i].group)+'\';return false;">Settings</li>'+
			'<li class="dropdown-item addCursorPointer hover" onclick="closeMenus(); window.location=\'embed.php?doc=AutoAssistantActive.html&<?=$urlTokenArg?>&aa='+encodeURIComponent(assistants[i].autoassistant)+'&pg='+encodeURIComponent(assistants[i].group)+'\';return false;">Active</li>'+
			userAccountPopupMenu(assistants[i].group,assistants[i].autoassistant)+
			'</ul>';
		mb.after(html);
		$('#menu-'+i).click(function (e) { e.stopPropagation(); }).dropdown().css('display', 'block');
	}
}

function loadTable() {
	idleReset();
	$.ajax({
		type: 'GET',
		url: 'json/autoAssistants?<?=$urlTokenArg?>',
		async: true,
		cache: false,
		success: function (json) {
			if (json.autoAssistants){
				assistants = json.autoAssistants;
				var data = [];
				for(var i=0;i<assistants.length;i++){
					data.push( [
					assistants[i].status,
					i,
					assistants[i].display,
					assistants[i].load,
					] );
				}
				if ( dataTable == null ) {
					var config = {
						"aaData": data,
						"aaSorting":[[1,"asc"]],
						"bAutoWidth":false,
						responsive: true,
						"aoColumns": [
							{ /* "Status" */ "bSearchable": false, "sClass": "right", "sWidth": "14px", "mRender": renderStatus },
							{ /* "Presence Id" */ "sClass": "nowrapellipsis", "mRender": renderPid, responsivePriority: 1 },
							{ /* "Display" */ "mRender": $.fn.dataTable.render.text() },
							{ /* "Load" */ "bSearchable": false, "mRender": renderTotal, "sClass": "right" }
						],
						"fnFooterCallback": function ( nRow, aaData, iStart, iEnd, aiDisplay ) {
							// do total for only what's displayed
							var linesInUse = 0;
							for ( var i=0; i<aiDisplay.length; i++ ) {
								linesInUse += aaData[aiDisplay[i]][3];
							}
							
							var nCells = nRow.getElementsByTagName('th');
							nCells[3].innerHTML = '' + linesInUse;
						},
						"fnInfoCallback": function( oSettings, iStart, iEnd, iMax, iTotal, sPre ) {
							for(var row=iStart-1;row<iEnd;++row){
								var i=oSettings.aiDisplay[row];
								$('#menub-'+i).click(function(i){
									return function(event){
										openPopup(event,i);
									}
								}(i));
							}
							return sPre;
						}
					};
					tableConfigLoad("aas", config);
					dataTable = $('#main_data_table').dataTable(config);
				}
				else {
					dataTable.fnClearTable();
					if (data.length) {
						dataTable.fnAddData( data );
					}
				}
			}
		}
	});
}

$(document).ready(function(){
	loadTable();
});

$(document).on('click',function(){
	$('ul[id^="menu-"]').remove();
});

$(window).on('unload',function() {
	tableConfigStore("aas",dataTable.fnSettings());
});

function closeMenus(){
  if(!assistants)
    return;
	for(var i=0;i<=assistants.length;++i){
		$('#menu-'+i).css('display','none');
	}
}

//# sourceURL=AutoAssistants.php.js
</script>

<div class='legend'>Auto Assistants</div>
<table cellpadding="0" cellspacing="0" border="0" class="display table table-striped table-bordered nowrap" id="main_data_table" style="padding-top:2em;">
<thead><tr>
	<th><div class="head_rot" title="Status of the Auto Assistant">Status</div></th>
	<th title="Presence Id of the Auto Assistant Account">Presence Id</th>
	<th title="Display of the Auto Assistant Account">Display</th>
	<th title="Sessions Actively with the Auto Assistant" style="text-align: left;">Active</th>
</tr></thead>
<tfoot><tr><th>&nbsp;</th><th>&nbsp;</th><th style='text-align: right;'>Total:</th><th>0</th></tr></tfoot>
</table>
<br/>
<div style='text-align:center;'>
<br/>
<?php
if($revation->adminGlobalView()){
	echo'<input type=button name=add value="Add New Assistant" class="btn btn-secondary btn-sm" ';
	if($revation->adminRight('ar_assistants'))
		echo'onclick="window.location=\'embed.php?php=NewService&'.$urlTokenArg.'&add&type=aa\';return false;"';
	else
		echo'disabled';
	echo'>';
}?>
<input type=button value="Refresh" class="btn btn-secondary btn-sm" onclick="loadTable();return false;">
</div>

<?php include 'tableBottom.php';?>