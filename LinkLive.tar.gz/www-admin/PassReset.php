<?php
include 'tableTop.php';
include 'groupPre.php';
echo 'Expire All User Passwords';
include 'groupStart.php';
$urlTokenArg=$revation->getUrlTokenArg();
?>
<form method=post action='embed.php?doc=ExpirePasswords.html&<?=$urlTokenArg?>' name=config>
<table>
<?php if($revation->adminGlobal())
	echo'<tr><td>Private Group:</td><td>'.$revation->control('group_select').'</td></tr>'; ?>
<tr>
<td style='vertical-align: top;'>Select a specific profile or [any]:</td>
<td><?php echo $revation->control('profile_search');?></td>
</tr>
<?php if(isset($_REQUEST['expire'])){
	echo'<tr style="background-color: red; color: white;"><td colspan=2>Passwords are being expired now; watch event log for results.</td></tr>';
}?>
<tr>
<td align=center colspan=2>
	<br/>
	<input type=submit name=expire value='Expire' class='btn btn-secondary btn-sm' />&nbsp;
	<input type=submit name=back value='&#x21e6; Back' class='btn btn-dark btn-sm' onclick="window.location='embed.php?php=Tools&<?=$urlTokenArg?>';return false;" />
</td>
</tr>
</table>
</form>
<?php
include 'groupEnd.php';
include 'tableBottom.php';
?>