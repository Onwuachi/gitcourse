<?php
include 'tableTop.php';
$urlTokenArg=$revation->getUrlTokenArg();
$file_changes=$revation->config('trunkRedirects');
?>

<script type="text/javascript">
//<![CDATA[
var g_data = null;
var dataTable = null;
var view_only = true;
<?php
if($revation->adminRight('ar_trunkrestrict'))echo'view_only = false;';
?>

function loadTable(parms){
	$.ajax({
		type: 'GET',
		url: 'json/trunkRedirects?<?=$urlTokenArg?>',
		async: true,
		cache: false,
		data: parms,
		success: function (json) {
			g_data = json;
			var data = [];
			if (json.trunkRedirects){
				for(var i=0;i<json.trunkRedirects.length;i++){
					var tr=json.trunkRedirects[i];
					data.push( [
						typeof tr.number == 'string' ? tr.number : '',
						typeof tr.dst == 'string' ? tr.dst : '',
						tr.code,
						tr.location,
						i
					] );
				}
			}
			if ( dataTable == null ) {
				var config = {
					"aaData": data,
					"bAutoWidth":false,
					responsive: true,
					"oLanguage": {
						"sEmptyTable": "(none set)"
					},
					"aoColumns": [
						{ "mRender": $.fn.dataTable.render.text(), responsivePriority: 1 },
						{ "mRender": $.fn.dataTable.render.text(), responsivePriority: 2 },
						{ "mRender": renderCode },
						{ "mRender": $.fn.dataTable.render.text() },
						{ "bSearchable": false, "bSortable": false, "mRender": renderButtons }
					],
				};
				tableConfigLoad("trunkred", config);
				dataTable = $('#main_data_table').dataTable(config);
			}
			else {
				dataTable.fnClearTable();
				if ( data.length ) {
					dataTable.fnAddData( data );
				}
			}
		}
	});
}

var codes=[
	{ code: 0, label: 'internal forward' },
	{ code: -1, label: 'ignore call' },
	{ code: 302, label: '302 Moved Temporarily' },
	{ code: 403, label: '403 Forbidden' },
	{ code: 404, label: '404 Not Found' },
	{ code: 480, label: '480 Temporarily Unavailable' },
	{ code: 486, label: '486 Busy Here' },
	{ code: 503, label: '503 Service Unavailable' },
	{ code: 603, label: '603 Decline' }
];

$(document).ready(function(){
	var code=$('#code');
	if(code){
		$(codes).each(function(){
			code.append($('<option>').val(this.code).text(this.label));
		});
	}
	loadTable();
});

$(window).on('unload',function() {
	tableConfigStore("trunkred",dataTable.fnSettings());
});

function addPatterns(){
	var num_src=$("#number_src").val();
	var num_dst=$("#number_dst").val();
	if(num_src.length||num_dst.length){
		var forward=$("#forward").val();
		var code=parseInt($("#code").val());
		if(code==NaN){
			code=0;
		}
		if((code==0||code==302)&&!forward.length){
			alert("forward location is required for \"internal forward\" or \"302 Moved Temporarily\"!");
		}
		else{
			$("#number_src").val("");
			$("#number_dst").val("");
			$("#forward").val("");
			loadTable('add='+encodeURIComponent(num_src)+'&dst='+encodeURIComponent(num_dst)+'&code='+code+'&forward='+encodeURIComponent(forward));
		}
	}
}

function renderCode( data, type, full ) {
	for(var i=0;i<codes.length;++i){
		if(codes[i].code==data){
			return rwc_htmlescape(codes[i].label);
		}
	}
}

function deleteItem(src,dst) {
	$('#deleteSource_id').text(src);
	$('#deleteDestination_id').text(dst);
	$('#delete_input_id').attr('onclick', 'loadTable(\'del_src='+encodeURIComponent(src)+'&del_dst='+encodeURIComponent(dst)+'\');$(\'#patternDelete\').modal(\'hide\');');

	var dlg = $('#patternDelete');
	dlg.modal('show');
}

function renderButtons( data, type, full ) {
	var buttons = '<div style="white-space: nowrap;">';

	// delete button
	buttons += '<input type=button value=delete class="btn btn-secondary btn-sm"';
	if(view_only) {
		buttons+=' disabled=disabled';
	}
	else {
		buttons += ' onclick="return deleteItem(\''+full[0]+'\',\''+full[1]+'\')"';
	}
	buttons += '>';
	buttons += '</div>';

	return buttons;
}
//]]>
</script>

<div class='legend'>Trunk Redirects for <?php echo $revation->adminGroup();?></div>
<table cellpadding="0" cellspacing="0" border="0" class="display table-striped table-bordered nowrap w-100" id="main_data_table">
  <thead>
    <tr>
      <th title="Incoming Source Number Patterns to Redirect">Incoming Patterns</th>
      <th title="Target Local Destination Number Patterns to Redirect">Destination Patterns</th>
      <th title="Redirect Code to Respond With">Code</th>
      <th title="If forward, Phone Number to Redirect Call To">Location</th>
      <th>&nbsp;</th>
    </tr>
  </thead>
  <tfoot>
    <tr>
      <th>&nbsp;</th>
      <th>&nbsp;</th>
      <th>&nbsp;</th>
      <th>&nbsp;</th>
      <th>&nbsp;</th>
    </tr>
  </tfoot>
</table>
<br/>
<div style='text-align:center;'>
  <br/>
  <div class='small_note'>
    Calls <span style='text-decoration: underline;'>to the domain</span> that match these patterns will be redirected.
  </div>
  <a class="btn btn-light btn-block service_accordion" data-toggle="collapse" href="#formatting_accordion" role="button" aria-controls="formatting_accordion" aria-expanded="false" style="text-align: left; font-weight: 500;" >formatting<span></span></a>
  <div id="formatting_accordion" class="collapse">
  <div style='font-size: smaller;'>
    Valid chars are: <span class="valch">+0123456789*#</span>
    <br/>
    Visual separators are ignored: <span class="valch">SPACE-.()/</span>
    <br/>
    <span class="valch">?</span> means 0 or 1 of previous rule,
    <br/>
	<span class="valch">%</span> means 0 or more of previous rule,
    <br/>
	<span class="valch">X</span> means any char <span class="valch">0123456789*#</span>,
    <br/>
	<span class="valch">[]</span> means set or range, e.g. <span class="valch">[7-9]</span> or <span class="valch">[789]</span>
    <br/>
	Multiple numbers can be entered at once using a comma or semicolon separator; however,
    <br/>
	there must be 0 or 1 source with multiple destinations, or, 0 or 1 destination with multiple sources.
    <br/>
	When uploading a .CSV file, prepend the line with a tilde (~) to delete the rule.
  </div>
  </div>
  <br/>
<?php
if(!$revation->adminGlobal()){
	echo'<textarea name="number_src" id="number_src" rows="1" cols="40" placeholder="optional source pattern"></textarea><textarea name="number_dst" id="number_dst" rows="1" cols="40" placeholder="optional destination pattern"></textarea><br/><select id="code"></select><input type=select id=forward placeholder="forward location"/><input type=button name=add value="Add Patterns" class="btn btn-secondary btn-sm" ';
	if($revation->adminRight('ar_trunkrestrict'))
		echo'onclick="addPatterns();return false;"';
	else
		echo'disabled';
	echo' />';
}
?>
<input type='button' value='&#x21e6; Back' class='btn btn-dark btn-sm' onclick="window.location='embed.php?php=<?=$_SESSION['nav_back']?>&<?=$urlTokenArg?>';return false;">
</div>

<div style="text-align:center;" class="mt-2">
    <form method='post' action="embedalone.php?doc=TrunkRedirects.csv&<?=$urlTokenArg?>" target='_blank' style='display: inline;'>
    <input type="hidden" name="pg" value="<?=$revation->adminGroup()?>" />
    <input type="submit" name="save" value="Download .CSV" class="btn btn-secondary btn-sm" />
    </form>
    <form method='post' action='embed.php?php=TrunkRedirects&<?=$urlTokenArg?>' enctype='multipart/form-data' style='display: inline;'>
    <input type="hidden" name="pg" value="<?=$revation->adminGroup()?>" />
	<label class="btn btn-secondary btn-sm" style="margin-bottom: 0;">
    <input hidden title='Upload .CSV' type='file' name='filename' id='uploadButton' onchange='if(this.value){if(this.value.search(/\.csv/i)==-1){alert("file not of correct extension!");this.form.reset();return false;}else{this.form.submit();return true;}}' />
	Upload .CSV...
	</label>
    </form>
	<?php if($file_changes)echo'<br/>'.$file_changes;?>
</div>

<div class="modal fade text-center" id="patternDelete" role="dialog">
    <div class="modal-dialog" role="document" style="padding-top: 15%; text-align: left; max-width: 100%; width: auto !important; display: inline-block;">
        <div class="modal-content" style="overflow: auto;">
            <div class="modal-header light-background">
                <h5 class="modal-title">Delete Pattern</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete the pattern '<span id='deleteSource_id' style="font-weight: bold;"></span>'/<span id='deleteDestination_id' style="font-weight: bold;"></span>'?</p>
                <div style="text-align: center;">
                    <input id="delete_input_id" type=button value=Delete class='btn btn-secondary btn-sm' />
                    <input type=button value=Cancel data-dismiss="modal" class='btn btn-secondary btn-sm' />
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'tableBottom.php';?>