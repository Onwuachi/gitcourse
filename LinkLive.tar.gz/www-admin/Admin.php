<?php
if($revation->groupTamperingDetected()){exit();}
include 'tableTop.php';
$urlTokenArg=$revation->getUrlTokenArg();
?>

<script>

var admins = null;
var adminsOnline = null;
var dataTable = null;

$(document).ready(function(){
	$.ajax({
		type: 'GET',
		url: 'json/admins?<?=$urlTokenArg?>',
		async: true,
		cache: false,
		success: function (json) {
			if (json.admins){
				admins = json.admins;
				adminsOnline = json.adminsOnline;
				var data = [];
				for(var i=0;i<admins.length;i++){
					data.push( [ rwc_htmlescape(admins[i].username), rwc_htmlescape(admins[i].fname), rwc_htmlescape(admins[i].lname), rwc_htmlescape(admins[i].groupAccess), rwc_htmlescape(admins[i].group), i ] );
				}
				populateTable(data);
			}
		}
	});
});

$(window).on('unload',function() {
	tableConfigStore("admin",dataTable.fnSettings());
});

function renderUsername( data, type, full ) {
	if(type=='display'){
		return '<button class="btn btn-secondary btn-xs" title="Settings for '+rwc_htmlescape(data)+'" onclick="window.location=\'embed.php?doc=AdminAdd.html&<?=$urlTokenArg?>&edit='+encodeURIComponent(data)+'\';return false;">&#x270e;</button> '+
			'<a href="embed.php?doc=AdminAdd.html&<?=$urlTokenArg?>&edit='+encodeURIComponent(data)+'">'+rwc_htmlescape(data)+'</a>';
	}
	else{
		return data;
	}
}

function renderGroups( data, type, full ) {
	var admin=admins[full[5]];
	if(type=='display'){
		if(admin.groupAccess=='list'){
			return '...';
		}
		else if(admin.groupAccess=='all'||admin.groupAccess=='global'){
			return '*';
		}
		else if(!data.length){
			return '[]';
		}
		else {
			return rwc_htmlescape(data);
		}
	}
	else if(type=='filter'){
		if(admin.groupAccess=='list'){
			var list='';
			for(var i=0;i<admin.groups.length;++i){
				if(list.length>0)
					list+=' ';
				if(admin.groups[i].length)
					list+=admin.groups[i];
				else
					list+='[]';
			}
			return list;
		}
		else if(admin.groupAccess=='all'||admin.groupAccess=='global'){
			return '*';
		}
		else if(!data.length){
			return '[]';
		}
		else {
			return data;
		}
	}
	else{
		return data;
	}
}

function populateTable(data) {
	var config = {
		"aaData": data,
		"bAutoWidth":false,
		responsive: true,
		"aoColumns": [
			{ "mRender": renderUsername, responsivePriority: 1 },
			{  },
			{  },
			{  },
			{ "mRender": renderGroups }
		],
		"fnRowCallback": function( nRow, aaData, iDisplayIndex ) {
			if(admins[aaData[5]].disabled){
				$(nRow).css("color","Red").css("font-weight","bold");
			}
			else if(adminsOnline && adminsOnline.length){
				for(var i=0; i<adminsOnline.length; i++){
					if(adminsOnline[i].un == aaData[0]){
						$(nRow).css("color","Green").css("font-weight","bold");
						break;
					}
				}
			}
		}
	};
	tableConfigLoad("admin", config);
	dataTable = $('#main_data_table').dataTable(config);
}
</script>

<div class='legend'>Admins</div>
<table cellpadding="0" cellspacing="0" border="0" class="display table-striped table-bordered nowrap w-100" id="main_data_table">
  <thead>
    <tr>
      <th title="Username of the Administrator">Username</th>
      <th title="First Name of the Administrator">First</th>
      <th title="Last Name of the Administrator">Last</th>
      <th title="How the Administrator Accesses Private Groups">Access</th>
      <th title="Private Group(s) the Administrator Manages">Group</th>
    </tr>
  </thead>
  <tfoot>
    <tr>
      <th colspan="5">&nbsp;</th>
    </tr>
  </tfoot>
</table>
<br/>
<div style='text-align:center;'>
<div class='small_note'>Note: colorization of <span style='font-weight: bold; color: green;'>GREEN</span> is for currently logged on administrators, and <span style='font-weight: bold; color: red;'>RED</span> is disabled administrators.</div>
<br/>
<?php
if($revation->adminGlobalView()){
	echo'<input type=button class="btn btn-secondary btn-sm" name=add value="Add New Admin" ';
	if($revation->adminRight('ar_admin'))
		echo'onclick="window.location=\'embed.php?doc=AdminAdd.html&'.$urlTokenArg.'&add\';return false;"';
	else
		echo'disabled';
	echo'>';
}?>
</div>

<?php include 'tableBottom.php';?>