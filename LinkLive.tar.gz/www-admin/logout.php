<?php
if($revation->adminPrivate())$_REQUEST['group']=$revation->adminGroup();
$revation->adminLogout();
$results='LOGOUT';
include 'index.php';
?>