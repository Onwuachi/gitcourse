var services_resources = [
    // Auto Assistant Templates
    { text: 'Auto Assistants', label: true },
    {
        text: 'Start from scratch', type: 'aa', value: '_empty_aa',
        description: 'Use this to start an Auto Assistant from scratch.'
    },
    /*{ text: '911 Service', type: 'aa', value: '911-notifications', description: 'This Auto Assistant service does 911 stuff.' },
    { text: 'After Hours', type: 'aa', value: 'afterhours', description: 'Use this Auto Assistant for...' },
    { text: 'Call Park', type: 'aa', value: 'callpark', description: 'Use this Auto Assistant for...' },
    { text: 'Dial By Name', type: 'aa', value: 'dial-by-name', description: 'Use this Auto Assistant for...' },
    { text: 'Echo Tool', type: 'aa', value: 'echo', description: 'Use this Auto Assistant for...' },
    { text: 'Fax', type: 'aa', value: 'fax-in', description: 'Use this Auto Assistant for...' },
    { text: 'Hold Music', type: 'aa', value: 'holdmusic', description: 'Use this Auto Assistant for...' },
    { text: 'SMS Responder', type: 'aa', value: 'sms', description: 'Use this Auto Assistant for...' },
    { text: 'Tone Tool', type: 'aa', value: 'tone', description: 'Use this Auto Assistant for...' },
    { text: 'Virtual Hold', type: 'aa', value: 'virtualhold', description: 'Use this Auto Assistant for...' },
    { text: 'Voicemail', type: 'aa', value: 'voicemail', description: 'Use this Auto Assistant for...' },*/
    {
        text: 'Conference Bridge', type: 'aa', value: 'conf_bridge',
        description: 'Use this Auto Assistant for generating new conference bridges.',
        attrs: {
            respath: '%{$pid}',
            xmldoc: '$/meet-me/service.xml', guidoc: '$/meet-me/gui.html',
            xmlvars: 'config={"session_pin":true,"session_pin_number":"0000","session_show_ref":true};'
        }
    },
    {
        text: 'Huddle', type: 'aa', value: 'huddle_bridge',
        description: 'Use this Auto Assistant for generating new huddles.',
        attrs: {
            respath: '%{$pid}',
            xmldoc: '$/meet-me/service.xml', guidoc: '$/meet-me/gui.html',
            xmlvars: 'config={};'
        }
    },
    {
        text: 'Mobile Attendant', type: 'aa', value: 'mobile_attendant',
        description: 'Use this Auto Assistant for generating a mobile user-agents.',
        attrs: {
            respath: '%mobile',
            xmlgl: '$/mobile/aa-agent-global.js', xmlglen: true, xmldoc: '$/mobile/aa-agent-service.js', guidoc: '$/mobile/aa-gui.html',
            xmlvars: 'config={};'
        }
    },
    {
        text: 'Unassigned Numbers', type: 'aa', value: 'unassigned_nums',
        description: 'Use this Auto Assistant for housing numbers yet to be assigned to user accounts.',
        attrs: {
            respath: '%',
            xmldoc: '$/disconnected/service.xml', guidoc: '$/disconnected/gui.html',
            xmlvars: 'config={};'
        }
    },

    // Hunt Group Templates
    { text: 'Hunt Groups', label: true },
    {
        text: 'Start from scratch', type: 'hg', value: '_empty_hg',
        description: 'Use this to start a Hunt Group from scratch.'
    },
    /*{ text: 'Campaign - IVR/Predictive Mode', type: 'hg', value: 'campaign_ivr', description: '' },
    {
        text: 'Bot Generator', type: 'hg', value: 'bot_generator',
        description: '',
        attrs: {
            respath: '%{$pid}', guidoc: '$/reva_bot_hg/gui.html', htmltools: '$/reva_bot_hg/tools-doc.html',
            xmldocib: '$/reva_bot_hg/service.js',
            xmlvars: 'config={};'
        }
    },*/
    {
        text: 'Campaign - Power/Preview Mode', type: 'hg', value: 'campaign_queue',
        description: 'Use this Hunt Group to build a queue for campaign records to be handled by agents in Power or Preview modes.',
        attrs: {
            respath: '%{$pid}', guidoc: '$/service/gui.html', htmltools: '$/service/tools-doc.html',
            xmldocgl: '$/service/global.js', xmldocglen: true, xmldocib: '$/service/service.xml', xmldocob: '$/service/outbound.xml', xmldocam: '$/service/service-menu.js',
            xmlvars: 'config={"session_operation": "campaign"};'
        }
    },
    {
        text: 'Mobile Queue Builder', type: 'hg', value: 'mobile_queue',
        description: 'Use this Hunt Group to build a queue for voice sessions to be handled by mobile agents.',
        attrs: {
            respath: '%mobile', guidoc: '$/mobile/hg-gui.html',
            xmldocib: '$/mobile/hg-inbound.xml', xmldocam: '$/mobile/hg-agentmenu.js',
            xmlvars: 'config={};'
        }
    },
    {
        text: 'Standard Queue Builder', type: 'hg', value: 'std_queue',
        description: 'Use this Hunt Group to build a queue for chats and/or voice sessions.',
        attrs: {
            respath: '%{$pid}', guidoc: '$/service/gui.html', htmltools: '$/service/tools-doc.html',
            xmldocgl: '$/service/global.js', xmldocglen: true, xmldocib: '$/service/service.xml', xmldocob: '$/service/outbound.xml', xmldocam: '$/service/service-menu.js',
            xmlvars: 'config={};'
        }
    }
];



// set to true after query if the account is an exact match to an existing one
var newServiceExistingAccount = false;

function newServiceCreate() {
    var profile = $('#profile').val();
    if (!newServiceExistingAccount && (typeof profile !== 'string' || !profile.length)) {
        alert('You must Select a Service Account Profile to create a new account!');
        return false;
    }

    var service = newServiceByValue($('#service_type').val());
    if (service) {
        var form = $('#create_form');
        form.html('');
        var pid = $('#dropdown_account').val();
        if (pid.length) {
            form.append('<input type="text" name="pid" value="' + rwc_htmlescape(pid) + '"/>');
            form.append('<input type="text" name="edit" value="' + rwc_htmlescape(pid) + '"/>');
            form.append('<input type="text" name="user" value="' + rwc_htmlescape(pid) + '"/>');
            form.append('<input type="text" name="display" value="' + rwc_htmlescape($('#display').val()) + '"/>');
            form.append('<input type="text" name="profile" value="' + rwc_htmlescape(profile) + '"/>');
            form.append('<input type="text" name="save" value="save"/>');
            form.append('<input type="checkbox" name="NewService" checked="checked"/>');
        }
        else if (service.value !== '_empty_aa' && service.value !== '_empty_hg') {
            alert('You must Create or Select a Service User to create a new non-empty service!');
            return false;
        }
        form.append('<input type="text" name="service" value="16"/>');  // Msg Queue
        form.append('<input type="checkbox" name="enabled" checked="checked"/>');
        if (typeof service.attrs === 'object') {
            for (attr in service.attrs) {
                if (typeof service.attrs[attr] === 'string') {
                    service.attrs[attr] = service.attrs[attr].replace(/({\$([^}]+)})/g, (match, p1, p2) => {
                        switch (p2) {
                            case 'pid': return pid;
                            default: return match;
                        }
                    });
                }
                form.append('<input type="text" name="' + rwc_htmlescape(attr) + '" value="' + rwc_htmlescape(service.attrs[attr]) + '"/>');
            }
        }
        if (service.type === 'aa') {
            form.attr('action', 'embed.php?doc=AutoAssistant.html&add&' + urlTokenArg);
        }
        else if (service.type === 'hg') {
            form.attr('action', 'embed.php?doc=Group.html&add&' + urlTokenArg);
        }
        form.submit();
    }
    return false;
}



function newServiceByValue(value) {
    for (var i = 0; i < services_resources.length; ++i) {
        if (services_resources[i].value === value) {
            return services_resources[i];
        }
    }
    return null;
}


$(document).ready(function () {
    // build the options from the services_resources
    var options = '';
    var in_group = false;
    for (var i = 0; i < services_resources.length; ++i) {
        if (services_resources[i].label) {
            if (in_group) {
                options += '</optgroup>';
            }
            in_group = true;
            options += '<optgroup label="' + services_resources[i].text + '">';
        }
        else {
            options += '<option value="' + services_resources[i].value + '">' + services_resources[i].text + '</option>';
        }
    }
    if (in_group) {
        options += '</optgroup>';
    }

    // set the options, then set the change handler
    $("#service_type").html(options).on('change', function () {
        // look up what was selected and update the GUI
        var service = newServiceByValue($(this).val());
        $('#description').html(service ? service.description : '');
    });

    // where did this page come from
    var type_from = 'Tools';
    if (URLSearchParams) {
        var searchParams = new URLSearchParams(window.location.search);
        if (searchParams.has('type')) {
            var _type_from = searchParams.get('type');
            if (_type_from === 'hg') {
                type_from = 'Groups';
            }
            else if (_type_from === 'aa') {
                type_from = 'AutoAssistants';
            }
        }
    }

    // set defaults
    if (type_from === 'Groups') {
        $('#service_type').val('_empty_hg');
    }
    else {
        $('#service_type').val('_empty_aa');
    }
    $('#cancel').on('click', function () {
        window.location = 'embed.php?php=' + type_from + '&' + urlTokenArg;
    });
    $('#service_type').trigger('change');

    // populate the profile names
    $.ajax({
        type: 'GET',
        url: 'json/profileNames?' + urlTokenArg,
        async: true,
        cache: false,
        success: function (json) {
            if (typeof json === 'object' && typeof json.profiles === 'object') {
                var contents = '';
                var sys = null;
                for (var i = 0; i < json.profiles.length; ++i) {
                    contents += '<option>' + rwc_htmlescape(json.profiles[i].name) + '</option>';
                    if (json.profiles[i].name.substr(-4) === '-sys') {
                        sys = json.profiles[i].name;
                    }
                }
                $('#profile').html(contents).val(sys);
            }
        }
    });
});



function newServiceLookupAccount() {
    var acct = $("#dropdown_account").val().trim().toLowerCase();
    newServiceExistingAccount = false;
    $.ajax({
        type: 'GET',
        url: 'json/usersFilter?' + urlTokenArg + '&max=10&query=' + encodeURIComponent('{"contains":"key","value":"' + acct + '"}') + '&results=' + encodeURIComponent('["key"]'),
        async: true,
        cache: false,
        success: function (json) {
            if (typeof json === 'object' && typeof json.users === 'object') {
                // reset the contents of the dropdown
                var contents = '';
                if (typeof acct !== 'string' || acct.length === 0) {
                    contents += '<div class="dropdown-header">Enter Account<div>';
                }
                else {
                    for (var i = 0; i < json.users.length; ++i) {
                        var key = json.users[i].key.toLowerCase();
                        if (acct === key) {
                            newServiceExistingAccount = true;
                        }
                        contents += '<input type="button" class="dropdown-item" type="button" value="' + rwc_htmlescape(key) + '"/>';
                    }
                    if (json.results_truncated) {
                        contents += '<div class="dropdown-divider"></div><div class="dropdown-header">Results Truncated...<div>';
                    }
                    else if (!contents.length) {
                        contents += '<input type="button" class="dropdown-item" type="button" value="New Account"/>';
                    }
                }
                $('#menuItems').html(contents).on('click', '.dropdown-item', function () {
                    var val = $(this).val();
                    if (val !== 'New Account') {
                        $('#dropdown_account').val(val);
                        newServiceExistingAccount = true;
                    }
                    $("#dropdown_account").dropdown('toggle');
                });
            }
        }
    });
}



var newServiceTypingTimer = null;

$("#dropdown_account").on('input', function () {
    if (newServiceTypingTimer) {
        clearTimeout(newServiceTypingTimer);
        newServiceTypingTimer = null;
    }
    if (!$(this).val().length) {
        $('#menuItems').html('<div class="dropdown-header">Enter <div>');
    }
    else {
        $('#menuItems').html('<div class="dropdown-header">Searching...<div>');
        newServiceTypingTimer = setTimeout(newServiceLookupAccount, 800);
    }
});
