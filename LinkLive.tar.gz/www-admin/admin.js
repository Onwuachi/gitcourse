var urlTokenArg = '';
function setUrlTokenArg(uta) {
    urlTokenArg = uta;
}

function getUrlTokenArg() {
    return urlTokenArg;
}

function idleTooLong() {
    window.location = 'logout.php?LOGON_TIMEOUT';
}

var idleTid = null;
function idleReset() {
    if (idleTid) {
        clearTimeout(idleTid);
    }
    var seconds = $("body").data('timeout');
    if (seconds != 'none') {
        seconds = parseInt(seconds);
        if (!seconds) {
            seconds = 1;
        }
        idleTid = setTimeout(idleTooLong, seconds * 1000);
    }
}

function cobrowse_toggle() {
    if (typeof revationCobrowse === 'object') {
        if (revationCobrowse.running()) {
            $('#cobrowse_stop').modal('show');
        }
        else {
            $('#cobrowse_start_error').addClass('display_none');
            $('#cobrowse_start').off('shown.bs.modal').on('shown.bs.modal', function () {
                $('#cobrowse_token').focus();
            }).modal('show');
        }
    }
}

// called once revation cobrowse is initialized
function revationCobrowseReady() {
    if (typeof revationCobrowse === 'object') {
        $('#cobrowse_toggle').removeClass('disabled');
        $('#cobrowse_stop').on('click', function (e) {
            revationCobrowse.stop();
        });
        $('#cobrowse_form').on('submit', function (e) {
            $('#cobrowse_start_error').addClass('display_none');
            e.preventDefault();
            revationCobrowse.start($('#cobrowse_token').val());
        });
        revationCobrowse.init({
            //transport_img: 'png',
            connected: function () {
                $('#cobrowse_toggle_text').text('Cobrowse Stop');
                $('#cobrowse_toggle').addClass('active');
                $('#cobrowse_start').modal('hide');
                console.log('connected!');
            },
            ended: function (reason) {
                $('#cobrowse_toggle_text').text('Cobrowse Start');
                $('#cobrowse_toggle').removeClass('active');
                if (reason.reason === 'ended') {
                    $('#cobrowse_token').val('');
                }
                else if (reason.reason === 'invalid_token') {
                    $('#cobrowse_start_error_text').text('Invalid Access Token');
                    $('#cobrowse_start_error').removeClass('display_none');
                }
                else if (reason.reason === 'missing_resource' || reason.reason === 'error') {
                    $('#cobrowse_start_error_text').text('Unable to reach server');
                    $('#cobrowse_start_error').removeClass('display_none');
                }
                console.log('ended:' + JSON.stringify(reason));
            }
        });
    }
}

$(document).ready(function () {
    idleReset();
    $('#sidebarToggle').on('click', function () {
        $('#sidebar').toggleClass('active');
        $('body').toggleClass('active');
    });
});

var change_happened = false;
function change_made() {
    if (!change_happened) {
        change_happened = true;
        $('#change_happened').addClass('show');
        $('#changebar_row').addClass('bg-danger');
        $('#cancel_changes').prop('disabled', false);
        if ($('#save,#apply_changes').data('norights')) {
        }
        else {
            $('#save,#apply_changes').prop('disabled', false);
        }
    }
}
function change_saved() {
    change_happened = false;
    $('#change_happened').removeClass('show');
    $('#changebar_row').removeClass('bg-danger');
    $('#save,#apply_changes,#cancel_changes').prop('disabled', true);
}
function change_detect_set_alert() {
    if ($('#save,#apply_changes').data('norights')) {
        $('#change_happened').addClass('show').text('No Rights!').addClass('bg-danger');
    }
    $('#_main_options').change(change_made).submit(applyChanges).find('input:text,:input[type="number"],:input[type="password"]').on("input", change_made);
    $(window).on('beforeunload', function () {
        if (change_happened) {
            return "You have unsaved changes and are navigating away, are you sure?";
        }
    });
}

function hideDropdown(thisID) {
    $('#' + thisID).css('visibility', 'hidden');
}

function adminOption(obj, selected_group) {
    var html = '';
    html += '<option value="' + rwc_htmlescape(obj.name) + '"';
    if (selected_group == obj.name) {
        html += ' selected="selected"';
    }
    html += '>' + rwc_htmlescape(obj.name);
    if (typeof obj.description_short === 'string') {
        html += ' (' + rwc_htmlescape(obj.description_short) + ')';
    }
    html += '</option>';
    return html;
}
function adminGroupSelectSet() {
    var html = '';
    for (var i = 0; i < admin_groups.length; ++i) {
        html += adminOption(admin_groups[i], admin_group);
    }
    $('#groupselect').append(html);
}

function adminEditGroupAccessChange(access) {
    $('#groupselectrow').css('display', access == 'global' || access == 'all' ? 'none' : '');
    $('#pgroup').css('display', access == 'single' ? '' : 'none');
    $('#pgrouplist').css('display', access == 'list' ? '' : 'none');
    return false;
}

function adminEditGroupsSet() {
    var html = '<option>[select one]</option>';
    for (var i = 1; i < admin_groups.length; ++i) {
        html += adminOption(admin_groups[i], admin_selected);
    }
    $('#pgroup').append(html);

    var html = '';
    var grouplist;
    if (admin_group_list.length) {
        grouplist = admin_group_list.split('/');
        grouplist.pop();    // there's nothing after the last slash
    }
    else {
        grouplist = [];
    }
    for (var i = 1; i < admin_groups.length; ++i) {
        html += '<option value="' + rwc_htmlescape(admin_groups[i].name) + '"';
        for (var j = 0; j < grouplist.length; ++j) {
            if (grouplist[j] == admin_groups[i].name) {
                html += ' selected="selected"';
                break;
            }
        }
        html += '>' + rwc_htmlescape(admin_groups[i].name);
        if (typeof admin_groups[i].description_short === 'string') {
            html += ' (' + rwc_htmlescape(admin_groups[i].description_short) + ')';
        }
        html += '</option>';
    }
    $('#pgrouplist').append(html);
    adminEditGroupAccessChange(admin_group_access);
}

function adminEditToggleAll() {
    for (var i = 0; i < document.f.elements.length; i++) {
        if (document.f.elements[i].type == 'checkbox') {
            document.f.elements[i].checked = !document.f.elements[i].checked;
        }
    }
}
function adminEditSetAll(val) {
    for (var i = 0; i < document.f.elements.length; i++) {
        if (document.f.elements[i].type == 'checkbox') {
            document.f.elements[i].checked = val;
        }
    }
}

function adminEditShowTable(t) {
    var disp = ['block', 'none', 'block'];
    $('#rights_table_configure').css('display', disp[t]);
    $('#rights_table_records').css('display', disp[t + 1]);
}

// load and store generic table items with page
function tableConfigStore(page, settings) {
    if (typeof Storage !== "undefined") {
        sessionStorage.setItem(page + '_search', $('#main_data_table_filter label input[type=search]').val());
        sessionStorage.setItem(page + '_iDisplayStart', settings._iDisplayStart);
        sessionStorage.setItem(page + '_aaSorting_col', settings.aaSorting[0][0]);
        sessionStorage.setItem(page + '_aaSorting_dir', settings.aaSorting[0][1]);
        localStorage.setItem(page + '_iDisplayLength', settings._iDisplayLength);
    }
}
function tableConfigLoad(page, config) {
    config.oSearch = { "sSearch": "" };
    config.iDisplayStart = 0;
    config.iDisplayLength = 10;
    config.aLengthMenu = [[10, 20, 30, 50, 100, -1], [10, 20, 30, 50, 100, "All"]];
    if (typeof Storage !== "undefined") {
        config.oSearch.sSearch = sessionStorage.getItem(page + '_search');
        if (typeof config.oSearch.sSearch != "string") {
            config.oSearch.sSearch = "";
        }
        config.iDisplayStart = parseInt(sessionStorage.getItem(page + '_iDisplayStart'));
        if (isNaN(config.iDisplayStart)) {
            config.iDisplayStart = 0;
        }
        var aaSorting_col = parseInt(sessionStorage.getItem(page + '_aaSorting_col'));
        var aaSorting_dir = sessionStorage.getItem(page + '_aaSorting_dir');
        if (!isNaN(aaSorting_col) && typeof aaSorting_dir === 'string') {
            config.aaSorting = [[aaSorting_col, aaSorting_dir]];
        }
        config.iDisplayLength = parseInt(localStorage.getItem(page + '_iDisplayLength'));
        if (isNaN(config.iDisplayLength)) {
            config.iDisplayLength = 10;
        }
    }
}

// combine two different base status values into one
function statusCombine(status1, status2) {
    if (status1 == null || status1 == 'offline' || status1 == 'unknown' || status1 == 'declined') {
        // whatever the other one was
        return status2;
    }
    else if (status1 == 'onthephone') {
        // trumps everything
        return 'onthephone';
    }
    else if (status2 == null || status2 == 'offline' || status2 == 'unknown' || status2 == 'declined' || status2 == 'away' || status2 == 'appearoffline' || (status2 == 'online' && (status1 == 'berightback' || status1 == 'outtolunch' || status1 == 'busy'))) {
        // no change
        return status1;
    }
    else {
        // whatever the other one was
        return status2;
    }
}

// given a status type, return the status image as a div with class
function statusImage(status) {
    return '<div class="status status-' + status.toLowerCase() + '" title="' + status + '">&nbsp;</div>';
}

// given a status type, return the status image and text
function statusColor(status) {
    return statusImage(status) + ' ' + status;
}

// given a link state type, return the state colorized and wrapped in a span
function linkColor(status) {
    if (status == "authenticated-master" || status == "authenticated-slave") {
        return statusColor('online');
    }
    else {
        return statusColor('offline');
    }
}

function serviceDocumentLoad(session) {
    $('#servicecreation').load('download.php?edit=' + encodeURIComponent(session.pid) + '&' + getUrlTokenArg() + '&pg=' + encodeURIComponent(session.group) + '&filename=' + encodeURIComponent(session.doc) + '&cmd=download-' + session.type, null, function () {
        if (!admin_global_view) {
            $('[data-administrator]').hide();
        }
    });
}

function helpButtonClass() {
    return "btn btn-info btn-sm rev-help";
}

function helpButtonText() {
    return "&#x1f6c8; Help on this";
}

// for toggling the rows of the table following the button
function client_toggle(e) {
    var button = $(e);
    var span = button.find('span');
    var hide = true;
    if (span.data('display') === 'hide') {
        span.data('display', 'show').html('&#x25BC;');
        hide = false;
    }
    else {
        span.data('display', 'hide').html('&#x25B6;');
    }

    // show/hide all but first and last row
    var trs = button.parent().next('table').find('tr');
    for (var i = 0; i < trs.length; ++i) {
        if (!trs[i].getAttribute('data-keep-visible')) {
            $(trs[i]).toggleClass('display_none', hide);
        }
    }
    return false;
}


// output the user account portion of the popup menu
function userAccountPopupMenu(group, pid) {

    $(function () {
        $('.disableClick').click(false);
    });

    return '<li class="dropdown-header menu-header">User</li>' +
        '<li class="dropdown-item addCursorPointer hover" onclick="closeMenus(); window.location=\'embed.php?doc=UserEdit.html&' + getUrlTokenArg() + '&edit=' + pid + '&privateGroup=' + group + '\';return false;">Account</li>' +
        '<li class="dropdown-item addCursorPointer hover" onclick="closeMenus(); window.location=\'embed.php?doc=UserInfo.html&' + getUrlTokenArg() + '&key=' + pid + '&privateGroup=' + group + '\';return false;">Info</li>' +
        '<li class="dropdown-item addCursorPointer hover" onclick="closeMenus(); window.location=\'embed.php?php=mail/folder&' + getUrlTokenArg() + '&vtop=1&key=' + pid + '&pg=' + group + '&mailbox=Sessions\';return false;">Logs - Sessions</li>' +
        '<li class="dropdown-item addCursorPointer hover" onclick="closeMenus(); window.location=\'embed.php?php=mail/folder&' + getUrlTokenArg() + '&vtop=1&key=' + pid + '&pg=' + group + '\';return false;">Logs - Inbox</li>' +
        '<li class="dropdown-item addCursorPointer hover" onclick="closeMenus(); window.location=\'embed.php?php=mail/del-perm&' + getUrlTokenArg() + '&vtop=1&key=' + pid + '&pg=' + group + '&mailbox=Sessions\';return false;">Purged</li>';
}

function rwc_htmlescape(html) {
    if (typeof html === 'string') {
        return html.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
    }
    else if (typeof html === 'number') {
        return "" + html;
    }
    else {
        return "";
    }
}

function modalHeader(id, title) {
    var html = '';
    html += '<div class="modal fade text-center" id="' + id + '" role="dialog" style="text-align: center; ">';
    html += '<div class="modal-dialog" role="document" style="padding-top: 15%; text-align: left; max-width: 100%; width: auto !important; display: inline-block;" >';
    html += '<div class="modal-content" style="overflow: auto;">';
    html += '<div class="modal-header light-background">';
    html += '<h5 class="modal-title">' + rwc_htmlescape(title) + '</h5>';
    html += '<button type="button" class="close" data-dismiss="modal">&times;</button>';
    html += '</div>';
    html += '<div class="modal-body">';
    return html;
}

function modalFooter() {
    var html = '';
    html += '</div>';
    html += '</div>';
    html += '</div>';
    html += '</div>';
    return html;
}

function profileDelete() {
    var dlg = $('#admin_del_profile_dlg');
    var name = $('#profile').val();
    if (!dlg.length) {
        var html = modalHeader('admin_del_profile_dlg', 'Delete ' + name + '?');

        html += '<div title="Delete ' + rwc_htmlescape(name) + '?">Are you sure you want to delete this Profile "' + rwc_htmlescape(name) + '"?</div>';

        html += '<div id="admin_del_profile_select"></div>';

        html += '<div class="modal-footer">';
        html += '<button type="button" id="deleteButtonID" class="btn light-background">Delete</button>';
        html += '<button type="button" class="btn light-background" data-dismiss="modal">Cancel</button>';
        html += '</div>';

        html += modalFooter();

        $('body').append(html);
        dlg = $('#admin_del_profile_dlg');

        $("#deleteButtonID").click(function () {
            var profile_replace = $('#admin_del_profile_new').val();
            if (typeof profile_replace !== 'string') {
                profile_replace = '';
            }
            window.location = 'embed.php?doc=ProfileAdd.html&' + getUrlTokenArg() + '&edit&delete&profile=' + encodeURIComponent(name) + '&profile_replace=' + encodeURIComponent(profile_replace);
        });
    }

    $.ajax({
        type: 'GET',
        url: 'json/profileNames?group=' + $('#privateGroup').val() + '&' + getUrlTokenArg(),
        async: true,
        cache: false,
        success: function (json) {
            if (typeof json === 'object' && typeof json.profiles === 'object') {
                html = '<br/>Replace users of deleted profile with: ';
                html += '<select id="admin_del_profile_new">';
                for (var i = 0; i < json.profiles.length; ++i) {
                    if (typeof json.profiles[i] === 'object' && typeof json.profiles[i].name === 'string') {
                        if (name != json.profiles[i].name) {
                            html += '<option>' + rwc_htmlescape(json.profiles[i].name) + '</option>';
                        }
                    }
                }
                html += '</select><br/><br/>';
                $('#admin_del_profile_select').html(html);
            }
        }
    });

    dlg.modal('show');
}

function adminAppAccessRemove(e) {
    $('#admin_remove_apptok_dlg').remove();
    var id = $(e).data('id');
    if (id) {
        var html = modalHeader('admin_remove_apptok_dlg', 'Remove Access Token?');

        html += '<div title="Remove Access Token?"><b>' + rwc_htmlescape($(e).data('comment')) + '</b><br/><br/><p>Are you sure you want to remove this Application Access Token?  This cannot be undone!</p><p>Any applications that utilize it will no longer have access and a new token will need to be created and configured.</p></div>';

        html += '<div class="modal-footer">';
        html += '<button type="button" id="tokenRemoveButtonID" class="btn light-background">Remove</button>';
        html += '<button type="button" class="btn light-background" data-dismiss="modal">Cancel</button>';
        html += '</div>';

        html += modalFooter();

        $('body').append(html);

        $("#tokenRemoveButtonID").click(function () {
            window.location = 'embed.php?doc=AdminAdd.html&' + getUrlTokenArg() + '&edit=' + encodeURIComponent($(e).data('user')) + '&cmd=tokremove&id=' + encodeURIComponent(id);
        });

        $('#admin_remove_apptok_dlg').modal('show');
    }
    return false;
}

function adminAppAccessAdd(e) {
    var user = $(e).data('user');
    if (user) {
        var dlg = $('#admin_add_apptok_dlg');
        if (!dlg.length) {
            var html = modalHeader('admin_add_apptok_dlg', 'Add New Access Token');

            html += '<div>';
            html += '<p>A New application Access Token will be created. The token will be displayed only once after creation - immediately utilize it.</p>Enter a comment to aide in the future identification of the token:';
            html += '<br/><input type=text id=admin_apptok_comment style="width: 100%"/>';
            html += '</div>';

            html += '<div class="modal-footer">';
            html += '<button type="button" id="tokenAddButtonID" class="btn light-background">Add</button>';
            html += '<button type="button" class="btn light-background" data-dismiss="modal">Cancel</button>';
            html += '</div>';

            html += modalFooter();

            $('body').append(html);
            dlg = $('#admin_add_apptok_dlg');

            $("#tokenAddButtonID").click(function () {
                window.location = 'embed.php?doc=AdminAdd.html&' + getUrlTokenArg() + '&edit=' + encodeURIComponent(user) + '&cmd=tokadd&comment=' + encodeURIComponent($('#admin_apptok_comment').val());
            });
        }
        dlg.modal('show');
    }
    return false;
}


function adminDeleteConfirm(e) {
    var user = $(e).data('user');
    if (user) {
        var dlg = $('#admin_delete_dlg');
        if (!dlg.length) {
            var html = modalHeader('admin_delete_dlg', 'Delete ' + user + '?');

            html += '<div title="Delete ' + rwc_htmlescape(user) + '?">Are you sure you want to delete this Administrator "' + rwc_htmlescape(user) + '"?</div>';

            html += '<div class="modal-footer">';
            html += '<button type="button" id="deleteButtonID" class="btn light-background">Delete</button>';
            html += '<button type="button" class="btn light-background" data-dismiss="modal">Cancel</button>';
            html += '</div>';

            html += modalFooter();

            $('body').append(html);
            dlg = $('#admin_delete_dlg');

            $("#deleteButtonID").click(function () {
                window.location = 'embed.php?doc=AdminAdd.html&' + getUrlTokenArg() + '&user=' + encodeURIComponent(user) + '&cmd=delete';
            });
        }
        dlg.modal('show');
    }
}


// the dialogs for disabling and enabling admins
function adminDisableConfirm(e) {
    var user = $(e).data('user');
    if (user) {
        var dlg = $('#admin_disable_dlg');
        if (!dlg.length) {
            var html = modalHeader('admin_disable_dlg', 'Disable ' + user + '?');

            html += '<div title="Disable ' + rwc_htmlescape(user) + '?">Are you sure you want to disable this Administrator "' + rwc_htmlescape(user) + '"?</div>';

            html += '<div class="modal-footer">';
            html += '<button type="button" id="disableButtonID" class="btn light-background">Disable</button>';
            html += '<button type="button" class="btn light-background" data-dismiss="modal">Cancel</button>';
            html += '</div>';

            html += modalFooter();

            $('body').append(html);
            dlg = $('#admin_disable_dlg');

            $("#disableButtonID").click(function () {
                window.location = 'embed.php?doc=AdminAdd.html&' + getUrlTokenArg() + '&edit=' + encodeURIComponent(user) + '&cmd=disable';
            });
        }
        dlg.modal('show');
    }
}

function adminEnableConfirm(e) {
    var user = $(e).data('user');
    if (user) {
        var dlg = $('#admin_enable_dlg');
        if (!dlg.length) {
            var html = modalHeader('admin_enable_dlg', 'Enable ' + user + '?');

            html += '<div title="Enable ' + rwc_htmlescape(user) + '?">Are you sure you want to enable this Administrator "' + rwc_htmlescape(user) + '"?<br/><br/>';
            html += '<select id=admin_enable_select>';
            html += '<option value="0">Leave it Enabled</option>';
            html += '<option value="60">Disable after 1 hour</option>';
            html += '<option value="240">Disable after 4 hours</option>';
            html += '<option value="480">Disable after 8 hours</option>';
            html += '<option value="1440">Disable after 24 hours</option>';
            html += '</select>';
            html += '</div>';

            html += '<div class="modal-footer">';
            html += '<button type="button" id="enableButtonID" class="btn light-background">Enable</button>';
            html += '<button type="button" class="btn light-background" data-dismiss="modal">Cancel</button>';
            html += '</div>';

            html += modalFooter();

            $('body').append(html);
            dlg = $('#admin_enable_dlg');

            $("#enableButtonID").click(function () {
                window.location = 'embed.php?doc=AdminAdd.html&' + getUrlTokenArg() + '&edit=' + encodeURIComponent(user) + '&cmd=enable&disable_after=' + $('#admin_enable_select').val();
            });
        }
        dlg.modal('show');
    }
}

// used when creating a new entity to make sure a private group was selected
function checkPg() {
    if ($('#pg').val() == '[select one]') {
        var dlg = $('#admin_select_pg');
        if (!dlg.length) {
            var html = modalHeader('admin_select_pg', 'Select a private group!');

            html += '<div id="admin_select_pg">A Private Group is required for creating this entity!<br/></div>';

            html += '<div class="modal-footer">';
            html += '<button type="button" autofocus class="btn light-background" data-dismiss="modal">OK</button>';
            html += '</div>';

            html += modalFooter();

            $('body').append(html);
            dlg = $('#admin_select_pg');
        }
        dlg.modal('show');
        return false;
    }
    return true;
}

function bootstrapCollapseDiv(divID) {
    $(divID).each(function (index, value) {
        var $a = $(this);
        var childrenElements = value.children;
        var contentID = 'contentID_' + value.id + '_' + index;
        var buttonID = 'button_' + value.id + '_' + index;
        var str = $a[0].innerText.split(/\r?\n/);

        $(childrenElements[0]).replaceWith('<button id="' + buttonID + '"  class="btn btn-light btn-block service_accordion" data-toggle="collapse" type="button" data-target=#' + contentID + ' aria-expanded="false" style="text-align: left; font-weight: 500;" >' + str[0] + '<span></span>' + '</button>');
        $(childrenElements[1]).attr({ id: contentID, class: 'collapse', style: 'padding: 1rem 0.75rem;' });
    });
}

function LocalServicesHosts(list) {
    var add = function (sk) {
        var next_i = parseInt($('#hosts_max').val());
        var row = '<tr>' +
            '<td>' +
            '<button class="btn btn-secondary btn-xs" title="Delete" onclick="$(this).closest(\'tr\').remove();return false;">&#x267a;&#xFE0E;</button>&nbsp;' +
            '<input type=text name="name_' + next_i + '" value="' + rwc_htmlescape(sk.name) + '"/></td>' +
            '<td><input type=text name="crt_' + next_i + '" value="' + rwc_htmlescape(sk.crt) + '"/></td>' +
            '<td><input type=text name="key_' + next_i + '" value="' + rwc_htmlescape(sk.key) + '"/></td>';

        if (sk.msg.length) {
            var ch = sk.msg.charAt(sk.msg.length - 1);
            row += '<td style="';
            if (ch == '!') {
                row += 'background-color: red; color: white;';
            }
            else {
                row += 'background-color: yellow; color: black;';
            }
            row += '">';
        }
        else {
            row += '<td>';
        }

        row += rwc_htmlescape(sk.msg) + '</td></tr>';

        $('#localServicesHostsTable tr:last').before(row);

        $('#hosts_max').val(next_i + 1);
    };

    // add a new empty host line
    this.addHost = function () {
        add({ name: '', certificate: '', privateKey: '', msg: '' });
    };

    // load the table
    for (var i = 0; i < list.length; ++i) {
        add(list[i]);
    }
}


function updateManageCalendarsFields(i) {
    if (i > 5) {
        return;
    }
    let row = document.getElementById('results_row');
    let col = document.getElementById('results_output_col');
    if (row && col) {
        row.removeChild(col);
    }
    let spn1 = $('#cal_file_' + i + '_span');
    let lbl = $('#cal_file_' + i + '_label');
    let el1 = $('#cal_file_' + (i++) + '_button');
    let spn2 = $('#cal_file_' + i + '_span');
    let lb2 = $('#cal_file_' + i + '_label');
    let el2 = $('#cal_file_' + i + '_button');
    if (el1 && el2) {
        if (!el1.prop('disabled') && el1.val()) {
            if (el1.val().search(/\.csv/i) == -1) {
                el2.prop('disabled', 'disabled');
                if (spn2) {
                    spn1.text('');
                }
                if (lb2) {
                    lb2.addClass('disabled');
                }
                alert("File not of correct extension!");
            }
            else {
                if (spn1) {
                    spn1.text(el1.val().split(/[\/\\]/g).pop());
                }
                el2.prop('disabled', null);
                if (lb2) {
                    lb2.removeClass('disabled');
                }
            }
        }
        else {
            el2.prop('disabled', 'disabled');
            if (spn1) {
                spn1.text('');
            }
            if (lb2) {
                lb2.addClass('disabled');
            }
        }
    }
    updateManageCalendarsFields(i);
}
