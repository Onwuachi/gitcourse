<?php
header('Content-Type: application/json');
echo'{"results":"';
if($_EVENT['FileUploadedOkay']){
  echo'success","sid":'.json_encode($_REQUEST['rwc_sid']).',"cookie":'.json_encode($_REQUEST['rwc_cookie']).',"file_name":'.json_encode($_REQUEST['rwc_filename']).',"file_size":'.$_REQUEST['rwc_filesize'];
}
else{
  echo'fail"';
}
echo'}';
?>