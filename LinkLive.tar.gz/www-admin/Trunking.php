<?php
if($revation->groupTamperingDetected()){exit();}
$revation->config('trunk');
include 'tableTop.php';
$urlTokenArg=$revation->getUrlTokenArg();
?>

<script>

var trunks = null;
var dataTable = null;

function renderStatus( data, type, full ) {
	if(type=='display'){
		return statusImage(data);
	}
	else {
		return data;
	}
}

function renderTotal( data, type, full ) {
	if(type=='display'){
		return '<button class="btn btn-secondary btn-xs" onclick="window.location=\'embed.php?doc=TrunkActive.html&<?=$urlTokenArg?>&trunk='+encodeURIComponent(trunks[full[2]].trunk)+'&pg='+encodeURIComponent(trunks[full[2]].group)+'\';return false;">'+data+'</button>';
	}
	else{
		return data;
	}
}

function renderPid( data, type, full ) {
	if(type=='display'){
		var html = '<div class="dropdown">' +
			'<button class="btn btn-secondary btn-xs" id="menub-'+data+'" data-toggle="dropdown" title="Menu for '+rwc_htmlescape(trunks[full[2]].trunk)+'" href="#">&#x2699;</button>' +
			'</div>'+
			'<a href="embed.php?doc=Trunk.html&<?=$urlTokenArg?>&edit='+encodeURIComponent(trunks[full[2]].trunk)+'&pg='+encodeURIComponent(trunks[full[2]].group)+'">' +
			rwc_htmlescape(trunks[full[2]].trunk) +
			'</a>';
		return html;
	}
	else{
		return trunks[full[2]].trunk;
	}
}

function openPopup(event,i) {
	closeMenus();
	event.stopImmediatePropagation();
	var mb=$('#menub-'+i);
	var m=$('#menu-'+i);

	if (m.length) {
		m.remove();
	}
	else { 
		var html=
			'<ul id="menu-'+i+'" class="dropdown-menu" onclick="closeMenus();">'+
			'<li class="dropdown-header menu-header">Trunk</li>'+
			'<li class="dropdown-item addCursorPointer hover" onclick="closeMenus(); window.location=\'embed.php?doc=Trunk.html&<?=$urlTokenArg?>&edit='+encodeURIComponent(trunks[i].trunk)+'&pg='+encodeURIComponent(trunks[i].group)+'\';return false;">Settings</li>'+
			'<li class="dropdown-item addCursorPointer hover" onclick="closeMenus(); window.location=\'embed.php?doc=TrunkActive.html&<?=$urlTokenArg?>&trunk='+encodeURIComponent(trunks[i].trunk)+'&pg='+encodeURIComponent(trunks[i].group)+'\';return false;">Activity</li>';
		if ( !trunks[i].userRestricted ) {
			html += userAccountPopupMenu(trunks[i].group,trunks[i].trunk);
		}
		html += '</ul>';
		mb.after(html);
		$('#menu-'+i).click(function (e) { e.stopPropagation(); }).dropdown().css('display', 'block');	}
}

function loadTable() {
	idleReset();
	$.ajax({
		type: 'GET',
    url: 'json/trunks?<?=$revation->getUrlTokenArg();?>',
		async: true,
		cache: false,
		success: function (json) {
			if (json.trunks){
				trunks = json.trunks;
				var data = [];
				for(var i=0;i<trunks.length;i++){
					data.push( [
						trunks[i].status,
						trunks[i].trunkState,
						i,
						trunks[i].display,
						trunks[i].bridges,
						trunks[i].linesInUse ] );
				}
				if ( dataTable == null ) {
					var config = {
						"aaData": data,
						"aaSorting":[[2,"asc"]],
						"bAutoWidth":false,
						responsive: true,
						"aoColumns": [
							{ /* "Domain Status" */ "bSearchable": false, "sClass": "right", "sWidth": "14px", "mRender": renderStatus },
							{ /* "Trunk Status" */ "bSearchable": false, "sClass": "right", "sWidth": "14px", "mRender": renderStatus },
							{ /* "Presence Id" */ "sClass": "nowrapellipsis", "mRender": renderPid, responsivePriority: 1 },
							{ /* "Display" */ "mRender": $.fn.dataTable.render.text() },
							{ /* "Bridges" */ "bSearchable": false, "sClass": "right" },
							{ /* "Active" */ "bSearchable": false, "mRender": renderTotal, "sClass": "right" },
						],
						"fnFooterCallback": function ( nRow, aaData, iStart, iEnd, aiDisplay ) {
							// do total for only what's displayed
							var bridges = 0;
							var linesInUse = 0;
							for ( var i=0; i<aiDisplay.length; i++ ) {
								bridges += aaData[aiDisplay[i]][4];
								linesInUse += aaData[aiDisplay[i]][5];
							}
							
							var nCells = nRow.getElementsByTagName('th');
							nCells[4].innerHTML = '' + bridges;
							nCells[5].innerHTML = '' + linesInUse;
						},
						"fnInfoCallback": function( oSettings, iStart, iEnd, iMax, iTotal, sPre ) {
							for(var row=iStart-1;row<iEnd;++row){
								var i=oSettings.aiDisplay[row];
								$('#menub-'+i).click(function(i){
									return function(event){
										openPopup(event,i);
									}
								}(i));
							}
							return sPre;
						}
					};
					tableConfigLoad("trunking", config);
					dataTable = $('#main_data_table').dataTable(config);
				}
				else {
					dataTable.fnClearTable();
					if (data.length) {
						dataTable.fnAddData( data );
					}
				}
			}
		}
	});
}

$(document).ready(function(){
	loadTable();
});

$(document).on('click',function(){
	$('ul[id^="menu-"]').remove();
});

$(window).on('unload',function() {
	tableConfigStore("trunking",dataTable.fnSettings());
});

function closeMenus(){
  if(!trunks)
    return;
	for(var i=0;i<=trunks.length;++i){
		$('#menu-'+i).css('display','none');
	}
}

//# sourceURL=Trunking.php.js
</script>

<div class='legend'>Trunks</div>
<table cellpadding="0" cellspacing="0" border="0" class="display table-striped table-bordered nowrap w-100" id="main_data_table" style="padding-top:2em;">
<thead><tr>
	<th><div class="head_rot" title="Local/Domain Status of the Trunk">Status</div></th>
	<th><div class="head_rot" title="Remote Status of the Trunk">Status</div></th>
	<th title="Presence Id of the Trunk Account">Presence Id</th>
	<th title="Display of the Trunk Account">Display</th>
	<th title="Active Trunk-Side Calls" style="text-align:left;">Bridges</th>
	<th title="Active Local/Domain-Side Calls" style="text-align:left;">Active</th>
</tr></thead>
<tfoot><tr><th>&nbsp;</th><th>&nbsp;</th><th>&nbsp;</th><th style='text-align: right;'>Total:</th><th>0</th><th>0</th></tr></tfoot>
</table>
<div style='text-align:center;' class='mt-2'>
<input type='button' value='Test Routing' class='btn btn-secondary btn-sm' onclick="window.location='embed.php?doc=UserDial.html&<?=$urlTokenArg?>&back_php=Trunking';return false;">
<input type=button value="Refresh" class='btn btn-secondary btn-sm' onclick="loadTable();return false;">
</div>
<?php
$_SESSION['nav_back']='Trunking';
if($revation->adminGlobalView()){
	echo'<div style="text-align:center;" class="mt-2"><input type=button name=add value="Add New Trunk" class="btn btn-secondary btn-sm" ';
	if($revation->adminRight('ar_trunks'))
		echo'onclick="window.location=\'embed.php?doc=Trunk.html&'.$urlTokenArg.'&add\';return false;"';
	else
		echo'disabled';
	echo'> <input type=button name=outbound value="Outbound Restrictions" class="btn btn-secondary btn-sm" ';
	if($revation->adminGlobal())
		echo'disabled';
	else
		echo'onclick="window.location=\'embed.php?php=TrunkRestrictions&'.$urlTokenArg.'\';return false;"';
	echo'> <input type=button name=outbound value="Inbound Redirects" class="btn btn-secondary btn-sm" ';
	if($revation->adminGlobal())
		echo'disabled';
	else
		echo'onclick="window.location=\'embed.php?php=TrunkRedirects&'.$urlTokenArg.'\';return false;"';
	echo'></div>';
}
?>

<?php include 'tableBottom.php';?>