<?php
$revation->config('unauthPres');
include 'tableTop.php';
$urlTokenArg=$revation->getUrlTokenArg();
?>

<script>

var unauthPresentities = null;
var dataTable = null;

function renderStatus( data, type, full ) {
	if(type=='display'){
		return statusImage(data);
	}
	else {
		return data;
	}
}

function renderPid( data, type, full ) {
	if(type=='display'){
		var html = '<div class="dropdown">' +
			'<button class="btn btn-secondary btn-xs" id="menub-'+data+'" data-toggle="dropdown" title="Menu for ' + rwc_htmlescape(unauthPresentities[full[1]].pid) + '" href="#">&#x2699;</button>' +
			'</div>'+
			'<a href="embed.php?doc=UnauthPres.html&<?=$urlTokenArg?>&edit='+encodeURIComponent(unauthPresentities[full[1]].pid)+'&pg='+encodeURIComponent(unauthPresentities[full[1]].group)+'">' +
			rwc_htmlescape(unauthPresentities[full[1]].pid) +
			'</a>';
		return html;
	}
	else{
		return unauthPresentities[full[1]].pid;
	}
}

function renderTotal( data, type, full ) {
	if(type=='display'){
		return '<button class="btn btn-secondary btn-xs" onclick="window.location=\'embed.php?doc=UnauthPresActive.html&<?=$urlTokenArg?>&up='+unauthPresentities[full[1]].pid+'&pg='+unauthPresentities[full[1]].group+'\';return false;">'+data+'</button>';
	}
	else {
		return data;
	}
}

function openPopup(event,i) {
	closeMenus();
	event.stopImmediatePropagation();
	var mb=$('#menub-'+i);
	var m=$('#menu-'+i);

	if (m.length) {
		m.remove();
	}
	else {
		var html=
			'<ul id="menu-'+i+'" class="dropdown-menu" onclick="closeMenus();">'+
			'<li class="dropdown-header menu-header">Presentity</li>'+
			'<li class="dropdown-item addCursorPointer hover" onclick="closeMenus(); window.location=\'embed.php?doc=UnauthPres.html&<?=$urlTokenArg?>&edit='+encodeURIComponent(unauthPresentities[i].pid)+'&pg='+encodeURIComponent(unauthPresentities[i].group)+'\';return false;">Settings</li>'+
			'<li class="dropdown-item addCursorPointer hover" onclick="closeMenus(); window.location=\'embed.php?doc=UnauthPresActive.html&<?=$urlTokenArg?>&up='+encodeURIComponent(unauthPresentities[i].pid)+'&pg='+encodeURIComponent(unauthPresentities[i].group)+'\';return false;">Active</li>'+
			userAccountPopupMenu(unauthPresentities[i].group,unauthPresentities[i].pid)+
			'</ul>';
		mb.after(html);
		$('#menu-'+i).click(function (e) { e.stopPropagation(); }).dropdown().css('display', 'block');
	}
}

function loadTable() {
	idleReset();
	$.ajax({
		type: 'GET',
		url: 'json/unauthPresentities?<?=$urlTokenArg?>',
		async: true,
		cache: false,
		success: function (json) {
			if (json.unauthPresentities){
				unauthPresentities = json.unauthPresentities;
				var data = [];
				for(var i=0;i<unauthPresentities.length;i++){
					data.push( [
					unauthPresentities[i].status,
					i,
					unauthPresentities[i].display,
					unauthPresentities[i].load,
					] );
				}
				if ( dataTable == null ) {
					var config = {
						"aaData": data,
						"aaSorting":[[1,"asc"]],
						"bAutoWidth":false,
						responsive: true,
						"aoColumns": [
							{ /* "Status" */ "bSearchable": false, "sClass": "right", "sWidth": "14px", "mRender": renderStatus },
							{ /* "Presence Id" */ "sClass": "nowrapellipsis", "mRender": renderPid, responsivePriority: 1 },
							{ /* "Display" */ "mRender": $.fn.dataTable.render.text() },
							{ /* "Load" */ "bSearchable": false, "mRender": renderTotal, "sClass": "right" }
						],
						"fnFooterCallback": function ( nRow, aaData, iStart, iEnd, aiDisplay ) {
							// do total for only what's displayed
							var linesInUse = 0;
							for ( var i=0; i<aiDisplay.length; i++ ) {
								linesInUse += aaData[aiDisplay[i]][3];
							}
							
							var nCells = nRow.getElementsByTagName('th');
							nCells[3].innerHTML = '' + linesInUse;
						},
						"fnInfoCallback": function( oSettings, iStart, iEnd, iMax, iTotal, sPre ) {
							for(var row=iStart-1;row<iEnd;++row){
								var i=oSettings.aiDisplay[row];
								$('#menub-'+i).click(function(i){
									return function(event){
										openPopup(event,i);
									}
								}(i));
							}
							return sPre;
						}
					};
					tableConfigLoad("unauth", config);
					dataTable = $('#main_data_table').dataTable(config);
				}
				else {
					dataTable.fnClearTable();
					if (data.length) {
						dataTable.fnAddData( data );
					}
				}
			}
		}
	});
}

$(document).ready(function(){
	loadTable();
});

$(document).on('click',function(){
	$('ul[id^="menu-"]').remove();
});

$(window).on('unload',function() {
	tableConfigStore("unauth",dataTable.fnSettings());
});

function closeMenus(){
  if(!unauthPresentities)
    return;
	for(var i=0;i<=unauthPresentities.length;++i){
		$('#menu-'+i).css('display','none');
	}
}

//# sourceURL=unauthPresentities.php.js
</script>

<div class='legend'>Unauthenticated Presentities</div>
<table cellpadding="0" cellspacing="0" border="0" class="display table table-striped table-bordered nowrap" id="main_data_table" style="padding-top:2em;">
<thead><tr>
	<th><div class="head_rot" title="Status of the Presentity">Status</div></th>
	<th title="Presence Id of the Presentity Account">Presence Id</th>
	<th title="Display of the Presentity Account">Display</th>
	<th title="Sessions Actively with the Presentity" style="text-align: left;">Active</th>
</tr></thead>
<tfoot><tr><th>&nbsp;</th><th>&nbsp;</th><th style='text-align: right;'>Total:</th><th>0</th></tr></tfoot>
</table>
<br/>
<div style='text-align:center;'>
<br/>
<?php
if($revation->adminGlobalView()){
	echo'<input type=button name=add value="Add New Presentity" class="btn btn-secondary btn-sm" ';
	echo'onclick="window.location=\'embed.php?doc=UnauthPres.html&'.$urlTokenArg.'&add\';return false;"';
	echo'>';
}?>
<input type=button value="Refresh" class="btn btn-secondary btn-sm" onclick="loadTable();return false;">
</div>

<?php include 'tableBottom.php';?>