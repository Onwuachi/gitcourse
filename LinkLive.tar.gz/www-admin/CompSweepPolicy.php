<?php
if($revation->groupTamperingDetected()){exit();}
$revation->config('compsweeppolicy');
$urlTokenArg=$revation->getUrlTokenArg();
?>
<?php include 'tableTop.php';?>
<form method='post' name='f' action='embed.php?php=CompSweepPolicy&<?=$urlTokenArg?>'>
<input type='hidden' name='privateGroup' value="<?=htmlspecialchars($_REQUEST['privateGroup'])?>"/>
		<?php
		include 'groupPre.php';
		echo 'Compliance Sweep '.htmlspecialchars($_REQUEST['privateGroup']);
		include 'groupStart.php';
		?>
				<table>
						<tr><td>Scan and Remove All Numbers:</td><td>
								<?php
					echo'<input type="checkbox" name="special_remove_all_num"';
					if(isset($_REQUEST['special_remove_all_num']))
						echo' checked="checked"';
					echo ' /> '.$revChanged['special_remove_all_num'];
								?>
						</td></tr>
						
						<tr><td>Days to Delay Before Sweep:
								<div style="margin-left: 2em; font-style: italic; font-size: x-small;">(For PCI compliance,<br />use no more than 7 days)</div>
						</td>
						<td valign="top">
								<?php echo "<input type='number' min='1' max='366' name='daysBeforeSweep' maxlength='5' size='6' value='".htmlspecialchars($_REQUEST['daysBeforeSweep'])."' /> ".$revChanged['daysBeforeSweep'];?>
								<div style="margin-left: 2em; font-style: italic; font-size: x-small;">(1-366)</div>
						</td></tr>
						
						<tr><td>Secure E-Mail Reports To:
								<div style="margin-left: 2em; font-style: italic; font-size: x-small;">(optional)</div>
						</td>
						<td valign="top">
								<?php echo "<input type='text' name='emailAddrs' value='".htmlspecialchars($_REQUEST['emailAddrs'])."' /> ".$revChanged['emailAddrs'];?>
						</td></tr>
						
				</table>
		<?php include 'groupEnd.php';?>
		<div style="text-align:center;" class="mt-2">
				<?php
				if(isset($_REQUEST['readonly']))
						$isDisabled=' disabled';
				else
						$isDisabled='';
				echo'<input type="submit" name="apply" value="Apply" class="btn btn-secondary btn-sm"'.$isDisabled.' />&nbsp;<input type="submit" name="cancel" value="Cancel" class="btn btn-secondary btn-sm" />&nbsp;';
				echo"<input type='button' value='&#x21e6; Back' class='btn btn-dark btn-sm' onclick=\"window.location='embed.php?doc=CompSweep.html&".$urlTokenArg."'\" /><br/>";
		echo'</div><div style="text-align:center;" class="mt-2">';
				if(isset($_REQUEST['add'])||isset($_REQUEST['name_ro']))
					$isDisabled=' disabled';
				echo'<input type="submit" name="delete" value="Delete" class="btn btn-secondary btn-sm"'.$isDisabled.' onclick="return confirm(\'Are you sure you want to delete this Policy?\');" />&nbsp;';
				?>
		<input type='button' value='Sweep Now' class='btn btn-secondary btn-sm' onclick="window.location='embed.php?php=CompSweepRange&<?=$urlTokenArg?>&privateGroup=<?php echo urlencode($_REQUEST['privateGroup']);?>';return false;" />&nbsp;
		</div>
</form>
<?php include 'tableBottom.php';?>