<?php
include 'tableTop.php';
$urlTokenArg=$revation->getUrlTokenArg();
?>

<script type="text/javascript">
//<![CDATA[
let dataTable = null;
<?php
echo'let is_global='.json_encode($revation->adminGlobal()).';';
echo'let view_only='.json_encode($revation->adminPrivateView()).';';
?>

let smsConfig = {
	load: function() {
		$.ajax({
			type: 'GET',
			url: 'api/msgs/config?' + getUrlTokenArg(),
			async: true,
			cache: false,
			success: function (json) {
				if(typeof json==='object'){
					$('#outbound\\.url').val(json?.outbound?.url||'');
					$('#outbound\\.authorization').val(json?.outbound?.authorization||'');
					$('#outbound\\.attr\\.name').val(json?.outbound?.attr.name||'');
					$('#outbound\\.attr\\.val').val(json?.outbound?.attr.val||'');
					$('#inbound\\.authorization').val(json?.inbound?.authorization||'');
				}
				$.ajax({
					type: 'GET',
					url: 'api/msgs/config/status?' + getUrlTokenArg(),
					async: true,
					cache: false,
					success: function (json) {
						if(typeof json==='object'){
							$('#queue_size').text(json?.queue_size||0);
						}
					}
				});
			}
		});
	},

	save: function(){
		// get our form into a nice json object
		let data={};
		let form_array=$("#sms_config_form").serializeArray();
		$.each(form_array,function(){
			let s=this.name.split('.');
			let d=data;
			while(s.length>1){
				if(typeof d[s[0]]==='undefined'){
					d[s[0]]={};
				}
				d=d[s[0]];
				s.shift();
			}
			d[s[0]]=this.value;
		});

		// save it
		$.ajax({
			type: 'POST',
			url: 'api/msgs/config?' + getUrlTokenArg(),
			async: true,
			cache: false,
			dataType: 'json',
			data: JSON.stringify( data ),
			contentType: 'application/json;charset=UTF-8',
			success: function (json) {
				if(typeof json==='object'){
					change_saved();
					$('#invalid_config').removeClass('show');
					smsConfig.load();
				}
				else {
					$('#invalid_config').addClass('show');
				}
			}
		});
		return false;
	}
};

$(document).ready(function(){
	smsConfig.load();
});

//]]>
</script>

<form method='post' id='sms_config_form'>

<table>
	<tr><td colspan="2"><div class='legend'>SMS Outbound Configuration</div></td></tr>
	<tr><td>URL:</td><td>
		<input type='text' id='outbound.url' name='outbound.url' onchange="change_made();" oninput="change_made();" />
	</td></tr>
	<tr><td>Authorization:</td><td>
		<input type='text' id='outbound.authorization' name='outbound.authorization' onchange="change_made();" oninput="change_made();" />
		<span class='small_note'>e.g. Basic dXNlcm5hbWU6cGFzc3dvcmQK</span>
	</td></tr>
	<tr><td>Obj Attribute:</td><td>
		<input type='text' id='outbound.attr.name' name='outbound.attr.name' onchange="change_made();" oninput="change_made();" />
		<input type='text' id='outbound.attr.val' name='outbound.attr.val' onchange="change_made();" oninput="change_made();" />
		<span class='small_note'>e.g. applicationId 123456</span>
	</td></tr>
	<tr><td>Queue Size:</td><td id='queue_size'>
		?
	</td></tr>
	<tr><td colspan="2"><div class='legend'>SMS Inbound Configuration</div></td></tr>
	<tr><td>Authorization:</td><td>
		<input type='text' id='inbound.authorization' name='inbound.authorization' onchange="change_made();" oninput="change_made();" />
		<span class='small_note'>e.g. Basic dXNlcm5hbWU6cGFzc3dvcmQK</span>
	</td></tr>
	<tr><td colspan="2" align="center">
		<div id='change_happened' class='change_happened'>Changes made - press <b>Save</b> when done!</div>
<?php
		echo'<input type=button name=add value="Save" class="btn btn-secondary btn-sm" ';
		if($revation->adminRight('ar_maincfg'))
			echo'onclick="smsConfig.save();return false;"';
		else
			echo'disabled';
		echo'>';
?>
		<input type='button' value='&#x21e6; Back' class='btn btn-dark btn-sm' onclick="window.location='embed.php?php=TelephoneGroupRouting&<?=$urlTokenArg?>';return false;">
	</td></tr>
</table>

</form>

<?php include 'tableBottom.php';?>