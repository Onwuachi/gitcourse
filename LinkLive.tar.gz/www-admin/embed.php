<?php
$urlTokenArg=$revation->getUrlTokenArg();
if(!isset($_SESSION)){
	include'index.php';
	exit();
}
if($revation->adminExpired()){
	include'passChange.php';
	exit();
}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title></title>

<link rel='stylesheet' href='js/bootstrap.min.css' type='text/css'/>
<link rel='stylesheet' href='js/datatables-1.13.4.min.css' type='text/css'/>
<link rel='stylesheet' href='skin.css' type='text/css'/>
<script type="text/javascript" src="js/jquery-3.6.3.min.js"></script>
<script type="text/javascript" src="js/datatables-1.13.4.min.js"></script>
<script type="text/javascript" src="js/popper.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="admin.js"></script>
<!--script type="text/javascript" async src="https://us-secure3-cobrowse.revation.com/resources/revation-cobrowse.js"></script-->

</head>
<body data-timeout="<?=$revation->adminTimeout()?>">
<svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
	<symbol id="svg_cobrowse" role="img" viewBox="0 0 843 512">
		<path d="M795,0H315a48,48,0,0,0-48,48V336a48,48,0,0,0,48,48H507l-24,96H411a16,16,0,0,0,0,32H699a16,16,0,0,0,0-32H627l-24-96H795a48,48,0,0,0,48-48V48A48,48,0,0,0,795,0ZM516,480l16-64h46l16,64ZM811,336a16,16,0,0,1-16,16H315a16,16,0,0,1-16-16V48a16,16,0,0,1,16-16H795a16,16,0,0,1,16,16Z" />
		<path d="M285.45,51H48A48,48,0,0,0,0,99V335.5a48,48,0,0,0,48,48H169l-24,96H100a16,16,0,0,0,0,32H330a16,16,0,0,0,0-32H289l-24-96h50c26.5,0-29.55-21.5-29.55-48V51ZM178,479.5l16-64h46l16,64ZM280,332c0,8.8,10.8,19.5,2,19.5H48a16,16,0,0,1-16-16V99A16,16,0,0,1,48,83H276c8.8,0,5,7.2,5,16Z" />
	</symbol>
	<symbol id="svg_sign_out" role="img" viewBox="0 0 512 512">
		<path fill="currentColor" d="M180 448H96c-53 0-96-43-96-96V160c0-53 43-96 96-96h84c6.6 0 12 5.4 12 12v40c0 6.6-5.4 12-12 12H96c-17.7 0-32 14.3-32 32v192c0 17.7 14.3 32 32 32h84c6.6 0 12 5.4 12 12v40c0 6.6-5.4 12-12 12zm117.9-303.1l77.6 71.1H184c-13.3 0-24 10.7-24 24v32c0 13.3 10.7 24 24 24h191.5l-77.6 71.1c-10.1 9.2-10.4 25-.8 34.7l21.9 21.9c9.3 9.3 24.5 9.4 33.9.1l152-150.8c9.5-9.4 9.5-24.7 0-34.1L353 88.3c-9.4-9.3-24.5-9.3-33.9.1l-21.9 21.9c-9.7 9.6-9.3 25.4.7 34.6z" />
	</symbol>
	<symbol id="svg_user" role="img" viewBox="0 0 448 512">
		<path fill="currentColor" d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z" />
	</symbol>
	<symbol id="svg_R" viewBox="0 0 85.38 85.38">
		<circle cx="42.69" cy="42.69" r="42.69" style="fill:#39b54a"/>
		<path d="M30.23,49.27,27.47,64.61A4.16,4.16,0,0,1,23.55,68H16.92a2.73,2.73,0,0,1-2.71-3.36l8-44.41a4.09,4.09,0,0,1,3.85-3.35h29c10.52,0,17.27,6.13,15.45,16.21C69.14,41,62.5,44.6,55,46.06c2.76,1.09,4.46,3.65,6.51,8.25L66,64.61c.81,1.9,0,3.36-1.83,3.36H55.76A5.78,5.78,0,0,1,51,64.61l-4.27-9.5c-1.28-2.84-3.34-5.84-7.88-5.84Zm4-22.35L32.05,39.2H47c4,0,9.42-1.47,10.26-6.14s-4-6.14-8-6.14Z" transform="translate(-0.82 -0.72)" style="fill:#fff"/>
	</symbol>
	<symbol id="svg_alert" role="img" viewBox="0 0 576 512">
		<path fill="currentColor" d="M569.517 440.013C587.975 472.007 564.806 512 527.94 512H48.054c-36.937 0-59.999-40.055-41.577-71.987L246.423 23.985c18.467-32.009 64.72-31.951 83.154 0l239.94 416.028zM288 354c-25.405 0-46 20.595-46 46s20.595 46 46 46 46-20.595 46-46-20.595-46-46-46zm-43.673-165.346l7.418 136c.347 6.364 5.609 11.346 11.982 11.346h48.546c6.373 0 11.635-4.982 11.982-11.346l7.418-136c.375-6.874-5.098-12.654-11.982-12.654h-63.383c-6.884 0-12.356 5.78-11.981 12.654z" />
	</symbol>
</svg>
	<div class="main-header">
		<table style="width: 100vw;" cellspacing="0" cellpadding="0">
			<tr>
				<td>
					<input type="button" value="&#9776" id="sidebarToggle">
					<img class="logo" src="imgs/logo-sm.png" alt="LinkLive 9"/>
				</td>
				<td class="topnav" style="padding-right:1em;"><span class="username"><svg><use xlink:href="#svg_user"></use></svg><?=$revation->adminDisplay()?></span><a class="cobrowse disabled" href="#" onclick="cobrowse_toggle();" id="cobrowse_toggle" title="CoBrowse"><svg class="cobrowse"><use xlink:href="#svg_cobrowse"></use></svg><span id="cobrowse_toggle_text">Cobrowse Start</span></a><a href="logout.php?<?=$urlTokenArg?>" title="Log out"><svg><use xlink:href="#svg_sign_out"></use></svg><span id="log_out_text">Log Out</span></a></td>
			</tr>
		</table>
	</div>
    <div class="nav-panel" id="sidebar">
		<div id='menu'>
			<?php
					echo'<script type="text/javascript">setUrlTokenArg("'.$urlTokenArg.'");var admin_global_view='.json_encode($revation->adminGlobalView()).',admin_un='.json_encode($revation->adminUsername()).';';
					if($revation->adminGlobalGroupSelect()){
						echo'</script><div class="groupform"><form name="groupform" style="display:inline;" method="post" action="embed.php?'.$urlTokenArg.'"><input type="hidden" name="';
						if($_REQUEST['php'])
							echo'php" value="'.htmlspecialchars($_REQUEST['php']).'">';
						else
							echo'doc" value="'.htmlspecialchars($_REQUEST['doc']).'">';
						if(!$revation->adminPrivate()){
							echo'<input type="checkbox" name="impersonate" onchange="document.groupform.submit();"'.$revChecked['impersonate'].'/>';
						}
						echo'<select class="groupselect" size="1" id="groupselect" name="groupselect" onchange="document.groupform.submit();"></select></form></div>';
						echo'<script type="text/javascript">var admin_groups='.$revation->adminGroupOptions().',admin_group="';
						if($revation->adminGlobal())
							echo'*",admin_global=true;';
						else
							echo $revation->adminGroup().'",admin_global=false;';
						echo'adminGroupSelectSet();';
					}
					else
						echo'admin_global=false;';
					echo'</script>';
				?> 
			<?php
			if($revation->adminGlobal()){
				echo'<a href="embed.php?doc=Status.html&'.$urlTokenArg.'" title="Current Server Status"><span>Status</span></a>';
				echo'<a href="embed.php?php=EventLog&'.$urlTokenArg.'" title="Log of Latest Events"><span>Event Log</span></a>';
				echo'<a href="embed.php?doc=Services.html&'.$urlTokenArg.'" title="Configure Services and Locations"><span>Services</span></a>';
				echo'<a href="embed.php?doc=Config.html&'.$urlTokenArg.'" title="Miscellaneous Configuration Items"> <span>Configuration</span></a>';
				echo'<a href="embed.php?doc=Management.html&'.$urlTokenArg.'" title="Event Management"><span>Management</span></a>';
				echo'<a href="embed.php?php=Admin&'.$urlTokenArg.'" title="Configure Administrators"><span>Administrators</span></a>';
				echo'<a href="embed.php?php=Tools&'.$urlTokenArg.'" title="Profiles, Routes, Directories and other Tools"><span>Tools</span></a>';
				echo'<a href="embed.php?php=Users&'.$urlTokenArg.'" title="Configure Users"><span>Users</span></a>';
				echo'<a href="embed.php?php=Groups&'.$urlTokenArg.'" title="Configure Hunt Groups"><span>Hunt Groups</span></a>';
				echo'<a href="embed.php?php=Trunking&'.$urlTokenArg.'" title="Configure Voice Trunks"><span>Voice Trunks</span></a>';
				echo'<a href="embed.php?php=AutoAssistants&'.$urlTokenArg.'" title="Configure Auto Assistants"><span>Auto Assistants</span></a>';
				echo'<a href="embed.php?php=UnauthPress&'.$urlTokenArg.'" title="Configure Unauthenticated Presentities"><span>Unauthenticated</span></a>';
			}
			else if($revation->adminAccessType()==0){
				echo'<a href="embed.php?doc=Status.html&'.$urlTokenArg.'" title="Current Server Status"><span>Status</span></a>';
				echo'<a href="embed.php?php=Users&'.$urlTokenArg.'" title="Configure Users"><span>Users</span></a>';
				echo'<a href="embed.php?php=Groups&'.$urlTokenArg.'" title="Configure Hunt Groups"><span>Hunt Groups</span></a>';
				if($revation->adminGlobalGroup()){
					echo'<a href="embed.php?php=Trunking&'.$urlTokenArg.'" title="Configure Voice Trunks"><span>Voice Trunks</span></a>';
				}
				echo'<a href="embed.php?php=AutoAssistants&'.$urlTokenArg.'" title="Configure Auto Assistants"><span>Auto Assistants</span></a>';
				echo'<a href="embed.php?php=EventLog&'.$urlTokenArg.'" title="Log of Latest Events"><span>Event Log</span></a>';
				echo'<a href="embed.php?php=Tools&'.$urlTokenArg.'" title="Profiles, Routes, Directories and other Tools"><span>Tools</span></a>';
				echo'<a href="embed.php?doc=AdminAdd.html&'.$urlTokenArg.'&edit='.urlencode($revation->adminUsername()).'" title="Configure Your Info"><span>Administrator</span></a>';
			}
			?>
		</div>
        <div class="copyright">&copy; 2023 LinkLive</div>
	</div>
	<div class="container-fluid main-content" style="vertical-align: <?php if($_REQUEST['vtop'])echo 'top';else echo'top;';?>">
		<!--main content-->
		<?php
		if(isset($_REQUEST['php']))
			include $_REQUEST['php']+'.php';
		else{
			if(!strlen($doc))
				$doc=$_REQUEST['doc'];
			if(strlen($doc))
				$revation->embed($doc);
			else
				echo'&nbsp;';
		}
		?>
    </div>

<div class="modal fade" id="cobrowse_start" aria-labelledby="startCobrowseLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered rev-modal-dialog">
    <div class="modal-content rev-modal-content">
      <div class="modal-body rev-modal-body">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <svg class="modalCobrowse">
          <use xlink:href="#svg_cobrowse"></use>
        </svg>
        <div id="startCobrowseLabel" class="rev-heading">
          <h1><img class="rev-linklive" src="imgs/logo_cobrowse.png" alt="LinkLive CoBrowse"></img></h1>
        </div>
        <div class="rev-modal-message">
          <div class="alert-primary rev-info-box">
            <form id="cobrowse_form">
              <div class="form-row text-left d-flex">
                <div class="flex-grow-1 form-group mr-2">
                  <label for="token">Access Token</label>
                  <input class="form-control" type="text" id="cobrowse_token" name="Token" required />
                </div>
                <div class="flex-shrink form-group d-flex flex-column justify-content-end">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </div>
            </form>
          </div>
          <div id="cobrowse_start_error" class="alert-warning rev-info-box display_none">
            <svg class="rev-info-box-icon text-danger">
              <use xlink:href="#svg_alert"></use>
            </svg><span id="cobrowse_start_error_text"></span>
          </div>
          <div class="text">
            Share your browser over a secure connection. If you do not already have an access token, please contact an agent to request one at 952-392-1831.
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="cobrowse_stop" aria-labelledby="stopCobrowseLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered rev-modal-dialog">
    <div class="modal-content rev-modal-content">
      <div class="modal-body rev-modal-body">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <svg class="modalCobrowse">
          <use xlink:href="#svg_cobrowse"></use>
        </svg>
        <div id="stopCobrowseLabel" class="rev-heading">
          <h1><img class="rev-linklive" src="imgs/logo_cobrowse.png" alt="LinkLive CoBrowse"></img></h1>
        </div>
        <div class="text">
          Thank you for using LinkLive CoBrowse.
        </div>
        <div class="rev-modal-message">
          <div class="alert-warning rev-info-box">
            <svg class="rev-info-box-icon text-danger">
              <use xlink:href="#svg_alert"></use>
            </svg>Are you sure you want to Stop CoBrowse?
          </div>
          <div class="text">
            <button type="button" class="btn btn-link" data-dismiss="modal">Continue CoBrowsing</button>
            <button type="button" class="btn btn-primary" id="cobrowse_stop" data-dismiss="modal">Stop CoBrowse</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>