<?php
if($revation->groupTamperingDetected()){exit();}
$revation->config('passpolicy');
$urlTokenArg=$revation->getUrlTokenArg();
?>
<?php
include 'tableTop.php';
$policyNameHTML=htmlspecialchars($_REQUEST['policyName']);
?>
<form method='post' name='f' action='embed.php?php=PassPolicy&<?=$urlTokenArg?>'>
			<?php
			include 'groupPre.php';
			echo $title;
			include 'groupStart.php';
			?>
			<table>
						<tr><td>Policy Name:</td><td>
								<?php
									echo '<input type="hidden" name="policyName" value="'.$policyNameHTML.'"/>';
									if(isset($_REQUEST['name_ro']))
										echo $policyNameHTML.'<input type="hidden" name="policyNameEdit" value="'.$policyNameHTML.'"/>';
									else
										echo'<input type="text" required="required" placeholder="policy name" name="policyNameEdit" maxlength="64" size="20" value="'.$policyNameHTML.'" /> '.$revChanged['policyName'];
									if(isset($_REQUEST['name_error']))
										echo'<div class="hilight_red">Invalid name!</div>';
								?>
						</td></tr>
						<tr><td>Minimum Password Length:</td><td>
								<?php echo "<input type='number' min='1' max='99' name='minPassLen' maxlength='2' size='6' value='".htmlspecialchars($_REQUEST['minPassLen'])."' /> {$revChanged['minPassLen']}";?>
						</td></tr>
						<tr><td>Minimum Upper-case Characters:</td><td>
								<?php echo "<input type='number' min='0' max='99' name='minUpperChars' maxlength='2' size='6' value='".htmlspecialchars($_REQUEST['minUpperChars'])."' /> {$revChanged['minUpperChars']}";?>
						</td></tr>
						<tr><td>Minimum Lower-case Characters:</td><td>
								<?php echo "<input type='number' min='0' max='99' name='minLowerChars' maxlength='2' size='6' value='".htmlspecialchars($_REQUEST['minLowerChars'])."' /> {$revChanged['minLowerChars']}";?>
						</td></tr>
						<tr><td>Minimum Numeric Characters:</td><td>
								<?="<input type='number' min='0' max='99' name='minNumericChars' maxlength='2' size='6' value='".htmlspecialchars($_REQUEST['minNumericChars'])."' /> {$revChanged['minNumericChars']}"?>
						</td></tr>
						<tr><td>Minimum Special Characters:</td><td>
								<?php echo "<input type='number' min='0' max='99' name='minSpecialChars' maxlength='2' size='6' value='".htmlspecialchars($_REQUEST['minSpecialChars'])."' /> {$revChanged['minSpecialChars']}";?>
						</td></tr>
						<tr><td>Maximum Identical Sequential Characters:</td><td>
								<?php echo "<input type='number' min='0' max='9999' name='maxSeqChars' maxlength='4' size='6' value='".htmlspecialchars($_REQUEST['maxSeqChars'])."' /> {$revChanged['maxSeqChars']}";?>
								<span style='font-size: smaller;'>(e.g. Passss; 0 is any, or 2+)</span>
						</td></tr>
						<tr><td>Maximum Sequential Characters from Username:</td><td>
								<?php echo "<input type='number' min='0' max='9999' name='maxUserChars' maxlength='4' size='6' value='".htmlspecialchars($_REQUEST['maxUserChars'])."' /> {$revChanged['maxUserChars']}";?>
								<span style='font-size: smaller;'>(0 is any, or 2+)</span>
						</td></tr>
						<tr><td>Maximum Sequential Characters From Last Password:</td><td>
								<?php echo "<input type='number' min='0' max='9999' name='maxPreviousChars' maxlength='4' size='6' value='".htmlspecialchars($_REQUEST['maxPreviousChars'])."' /> {$revChanged['maxPreviousChars']}";?>
								<span style='font-size: smaller;'>(0 is any, or 2+)</span>
						</td></tr>
						<tr><td>Maximum Generations before Password Re-Use:</td><td>
								<?php echo "<input type='number' min='0' max='10' name='maxGenerations' maxlength='2' size='2' value='".htmlspecialchars($_REQUEST['maxGenerations'])."' /> {$revChanged['maxGenerations']}";?>
						</td></tr>
						<tr><td>Maximum Password Changes per Interval:</td><td>
								<?php echo "<input type='number' min='0' max='10' name='maxChanges' maxlength='2' size='2' value='".htmlspecialchars($_REQUEST['maxChanges'])."' /> {$revChanged['maxChanges']}"?> per <?="<input type='number' min='0' max='10' name='maxChangesHr' maxlength='2' size='2' value='".htmlspecialchars($_REQUEST['maxChangesHr'])."' /> {$revChanged['maxChangesHr']}";?> hours
						</td></tr>
						<tr><td>Minimum Voicemail PIN Digits:</td><td>
								<?php echo "<input type='number' min='1' max='99' name='minVoicemailDigits' maxlength='2' size='6' value='".htmlspecialchars($_REQUEST['minVoicemailDigits'])."' /> {$revChanged['minVoicemailDigits']}";?>
						</td></tr>
						<tr><td>Maximum Invalid Password Attempts:</td><td>
								<?php echo "<input type='number' min='1' max='999' name='maxAttemptsPerWindow' maxlength='3' size='6' value='".htmlspecialchars($_REQUEST['maxAttemptsPerWindow'])."' /> {$revChanged['maxAttemptsPerWindow']}";?>
						</td></tr>
						<tr><td>Lockout Minutes:</td><td>
								<?php echo "<input type='number' min='1' max='9999' name='minutesInWindow' maxlength='4' size='6' value='".htmlspecialchars($_REQUEST['minutesInWindow'])."' /> {$revChanged['minutesInWindow']}";?>
						</td></tr>
						<tr><td>Use Generic Error for Lockout:</td><td>
								<?php echo "<input type='checkbox' name='genericFailForLockout' ";if(isset($_REQUEST['genericFailForLockout']))echo"checked='checked'";echo" /> {$revChanged['genericFailForLockout']}";?>
						</td></tr>
						<tr><td>Password Expire Days:</td><td>
								<?php echo "<input type='number' min='0' max='9999' name='daysPassExpire' maxlength='4' size='6' value='".htmlspecialchars($_REQUEST['daysPassExpire'])."' /> {$revChanged['daysPassExpire']}";?>
								<span style='font-size: smaller;'>(0 means does not expire)</span>
						</td></tr>
						<tr><td>Inactive Session Expires Seconds:</td><td>
								<?php echo "<input type='number' min='60' max='86400' name='sessionExpiresSeconds' maxlength='5' size='6' value='".htmlspecialchars($_REQUEST['sessionExpiresSeconds'])."' /> {$revChanged['sessionExpiresSeconds']}";?>
						</td></tr>
						<tr><td>Password Reset and New Account Token Expires Seconds:</td><td>
								<?php echo "<input type='number' min='60' max='604800' name='resetTokenExpiresSeconds' maxlength='6' size='6' value='".htmlspecialchars($_REQUEST['resetTokenExpiresSeconds'])."' /> {$revChanged['resetTokenExpiresSeconds']}";?>
						</td></tr>
						<tr><td>Inactive Account Auto-Disable Days:</td><td>
								<?php echo "<input type='number' min='0' max='9999' name='accountDisablesDays' maxlength='4' size='6' value='".htmlspecialchars($_REQUEST['accountDisablesDays'])."' /> {$revChanged['accountDisablesDays']}";?>
								<span style='font-size: smaller;'>(0 means will not auto-disable)</span>
						</td></tr>
				</table>
		<?php include 'groupEnd.php';?>
		<br />
		<div style="text-align:center;">
				<?php
				if(isset($_REQUEST['readonly']))
						$isDisabled=' disabled';
				else
						$isDisabled='';
				echo'<input type="submit" name="apply" value="Apply" class="btn btn-secondary btn-sm"'.$isDisabled.' />&nbsp;';
				if(isset($_REQUEST['add']))
						$isDisabled=' disabled';
				echo'<input type="submit" name="cancel" value="Cancel" class="btn btn-secondary btn-sm"'.$isDisabled.' />&nbsp;';
				if(isset($_REQUEST['name_ro']))
						$isDisabled=' disabled';
				echo'<input type="submit" name="delete" value="Delete" class="btn btn-secondary btn-sm"'.$isDisabled.' onclick="if(confirm(\'Are you sure you want to delete this Policy?\'))window.location=\'embed.php?doc=PassPolicies.html&'.$urlTokenArg.'&delete&policyName='.urlencode($_REQUEST['policyName']).'\';return false;" />&nbsp;';
				?>
				<input type='button' value='&#x21e6; Back' class='btn btn-dark btn-sm' onclick="window.location='embed.php?doc=PassPolicies.html&<?=$urlTokenArg?>'" />
		</div>
</form>
<?php include 'tableBottom.php';?>