<?php
include 'tableTop.php';
include 'groupPre.php';

if($revation->adminGlobal()){
  echo'Appointment Scheduling';
  include 'groupStart.php';
  echo'Please select a private group to manage Appointment Scheduling.';
  include 'groupEnd.php';
  include 'tableBottom.php';
  exit();
}
else {
  echo'Appointment Scheduling for '.$revation->adminGroup();
  include 'groupStart.php';
}

$revation->config('apptSchd');
?>

<br/>
<form method='post' action='embed.php?<?=$urlTokenArg?>'><input type='hidden' name='php' value='ApptScheduling' autocomplete='off'/>
Enable:&nbsp;<input type=checkbox id=enabled name=enabled <?=$revChecked['enabled']?>/>&nbsp;<?=$revChanged['enabled']?>
<br/><br/>
<input type=submit name=apply value=Apply style='min-width:6em;' class='btn btn-secondary btn-sm'/>&nbsp;
<input type=button value='&#x21e6; Back' class='btn btn-dark btn-sm' onclick="window.location='embed.php?php=Tools&<?=$urlTokenArg?>';return false;"/>
</form>

<?php include 'tableBottom.php';?>
