<?php 
$urlTokenArg=$revation->getUrlTokenArg();
include 'tableTop.php'; 
?>

<script>

var agents = null;
var dataTable = null;

function statsCombiner(user){
	var stats={status:'offline',activeSessions:0};
	for(var i=0;i<user.groups.length;i++){
		stats.status=statusCombine(stats.status,user.groups[i].status);
		stats.activeSessions+=user.groups[i].activeSessions;
	}
	return stats;
}

function renderStatus( data, type, full ) {
	if(type=='display'){
		return statusImage(data);
	}
	else {
		return data;
	}
}

function renderAgentPid( data, type, full ) {
	var agent=agents[full[1]];
	if(type=='display'){
		var html = '<div class="dropdown">' +
			'<button class="btn btn-secondary btn-xs" id="menub-'+data+'" data-toggle="dropdown" title="Menu for ' + rwc_htmlescape(agent.pid) + '" href="#">&#x2699;</button>' +
			'</div>'+
			'<a href="embed.php?doc=AgentEdit.html&<?=$urlTokenArg?>&pid='+encodeURIComponent(agent.pid)+'&pg='+encodeURIComponent(agent.group)+'"';

		var rights=agent.rights;
		var supervisor=rights=='supervisor'||rights=='qa_rights'||rights=='workforce_mgmt';
		if(!supervisor){
			var groups=agent.groups;
			for(var i=0;i<groups.length;++i){
				rights=groups[i].rights;
				if(rights=='supervisor'||rights=='qa_rights'||rights=='workforce_mgmt'){
					html += ' style="font-weight: bold;" title="supervisor"';
					break;
				}
			}
		}
		return html + '>' + rwc_htmlescape(agent.pid) + '</a>';
	}
	else{
		return agent.pid;
	}
}

var RightsFriendly = [
	["inherit", "Inherit"],
	["none", "None"],
	["reporting_stats", "Reporting Stats"],
	["detailed_stats", "Detailed Stats"],
	["supervisor", "Supervisor"],
	["qa_rights", "QA Rights"],
	["workforce_mgmt", "Workforce Mgmt"]
];

function rightsFriendly(rights){
	for(var i=0;i<RightsFriendly.length;++i){
		if(RightsFriendly[i][0]==rights){
			return RightsFriendly[i][1];
		}
	}
	return 'None';
}

function huntGroupGroupings(huntGroups, hg){
	var list='';
	for(var i=0;i<huntGroups.length;i++){
		if(huntGroups[i].huntgroup==hg){
			list+=','+huntGroups[i].grouping;
		}
	}
	return list;
}

function huntGroupCombiner(huntGroups, user){
	var list='';
	for(var i=0;i<user.groups.length;i++){
		if(list.length)list+=',';
		list+=user.groups[i].group;
		// add the grouping names too if present
		if(huntGroups){
			list+=huntGroupGroupings(huntGroups,user.groups[i].group);
		}
	}
	return list;
}

function openPopup(event,i) {
	closeMenus();
	event.stopImmediatePropagation();
	var mb=$('#menub-'+i);
	var m=$('#menu-'+i);

	if (m.length) {
		m.remove()
	}
	else {
		var html=
			'<ul id="menu-'+i+'" class="dropdown-menu" onclick="closeMenus();">'+
			'<li class="dropdown-header menu-header">Agent</li>'+
			'<li class="dropdown-item addCursorPointer hover" onclick="closeMenus(); window.location=\'embed.php?doc=AgentEdit.html&<?=$urlTokenArg?>&pid='+encodeURIComponent(agents[i].pid)+'&pg='+encodeURIComponent(agents[i].group)+'\';return false;">Settings</li>'+
			userAccountPopupMenu(agents[i].group,agents[i].pid)+
			'</ul>';
		mb.after(html);
		$('#menu-'+i).click(function (e) { e.stopPropagation(); }).dropdown().css('display', 'block');
	}
}

function loadTable() {
	idleReset();
	$.ajax({
		type: 'GET',
		url: 'json/huntGroupAgents?<?=$urlTokenArg?>',
		async: true,
		cache: false,
		success: function (json) {
			if (json.agents){
				agents = json.agents;
				var data = [];
				for(var i=0;i<agents.length;i++){
					var user = agents[i];
					var stats = statsCombiner( user );
					data.push( [
						stats.status,
						i,
						huntGroupCombiner( json.huntGroups, user ),
						user.alias,
						rightsFriendly(user.rights),
						user.maxSessions,
						stats.activeSessions
						] );
				}
				if ( dataTable == null ) {
					var config = {
						"aaData": data,
						"bAutoWidth":false,
						responsive: true,
						"aoColumns": [
							{ /* "Status" */ "bSearchable": false, "sClass": "right", "sWidth": "14px", "mRender": renderStatus },
							{ /* "Presence Id" */ "sClass": "nowrapellipsis", "mRender": renderAgentPid, responsivePriority: 1 },
							{ /* "Hunt Groups" */ "bSearchable": true, "bVisible": false },
							{ /* "Display Name" */ "mRender": $.fn.dataTable.render.text() },
							{ /* "Default Rights" */ },
							{ /* "Max Total" */ "bSearchable": false, "sClass": "right" },
							{ /* "Active" */ "bSearchable": false, "sClass": "right" }
						],
						"fnInfoCallback": function( oSettings, iStart, iEnd, iMax, iTotal, sPre ) {
							for(var row=iStart-1;row<iEnd;++row){
								var i=oSettings.aiDisplay[row];
								$('#menub-'+i).click(function(i){
									return function(event){
										openPopup(event,i);
									}
								}(i));
							}
							return sPre;
						}
					};
					tableConfigLoad("agentsall", config);
					dataTable = $('#main_data_table').dataTable(config);
				}
				else {
					dataTable.fnClearTable();
					if (data.length) {
						dataTable.fnAddData( data );
					}
				}
			}
		}
	});
}

$(document).ready(function(){
	loadTable();
});

$(document).on('click',function(){
	$('ul[id^="menu-"]').remove();
});

$(window).on('unload',function() {
	tableConfigStore("agentsall",dataTable.fnSettings());
});

function closeMenus(){
  if(!agents)
    return;
	for(var i=0;i<=agents.length;++i){
		$('#menu-'+i).css('display','none');
	}
}

//# sourceURL=AgentsAll.php.js
</script>
<div class='legend'>All Agents</div>
<table cellpadding="0" cellspacing="0" border="0" class="display table-striped table-bordered nowrap w-100" id="main_data_table" style="padding-top:2em;">
<thead><tr>
	<th><div class="head_rot" title="Current Status of the Agent Account&#10;Combined for All Hunt Groups">Status</div></th>
	<th title="Presence Id of the Agent Account">Presence Id</th>
	<th title="The Hunt Groups the Agent is a Member of">Hunt Groups</th>
	<th title="Display Name Alias of the User Account for Hunt Groups">Display Name</th>
	<th title="Default Rights for the User for all Hunt Groups">Default Rights</th>
	<th title="Maximum Total Sessions in all Hunt Groups the Agent can be in">Max Sessions</th>
	<th title="Active Hunt Group Sessions the Agent is in" style="text-align:left;">Active</th>
</tr></thead>
</table>
<br/>
<div style='text-align:center;'>
<input type=button value="Refresh" class='btn btn-secondary btn-sm' onclick="loadTable();return false;"> <input type=button value='&#x21e6; Back' class='btn btn-dark btn-sm' onclick="window.location='embed.php?php=Groups&<?=$urlTokenArg?>';return false;">
</div>


<?php include 'tableBottom.php';?>