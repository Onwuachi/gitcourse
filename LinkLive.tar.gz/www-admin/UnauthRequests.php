<?php
include 'tableTop.php';
include 'groupPre.php';
echo 'Unauthenticated Requests';
if($revation->adminGlobal())
	echo ' - Global';
else
	echo ' for '.$revation->adminGroup();
include 'groupStart.php';
$urlTokenArg=$revation->getUrlTokenArg();
?>

<script type="text/javascript">
//<![CDATA[

var UnauthRequests = {
	loaddata: function() {
		$.ajax({
			type: 'GET',
			url: 'json/unauthreq/data?'+getUrlTokenArg(),
			async: true,
			cache: false,
			success: function (json) {
				if(typeof json==='object' && json.results==='success' && typeof json.data==='object'){
					$('#chat').prop("checked", json.data.captcha.chat);
					$('#calendar').prop("checked", json.data.captcha.calendar);
					$('#type').val(json.data.captcha.type||'');
					$('#verifyURL').val(json.data.captcha.verifyURL||'');
					$('#appID').val(json.data.captcha.appID||'');
					$('#appKey').val(json.data.captcha.appKey||'');

					if(admin_global&&!json.data.maps.type){
						json.data.maps.type='(disabled)';
					}
					$('#maps_type').val(json.data.maps.type||'');
					$('#maps_appID').val(json.data.maps.appID||'');
				}
			}
		});
	},

	cleardata:function(){
		$('#unauthreq_form')[0].reset();
		change_made();
		return false;
	},

	updatedata:function(){
		// get our form into a nice json object
		var data={captcha:{},maps:{}};
		var form_array=$("#unauthreq_form").serializeArray();
		$.each(form_array,function(){
			if(this.name.substr(0,5)=='maps_')
				data.maps[this.name.substr(5)]=this.value;
			else
				data.captcha[this.name]=this.value;
		});
		$.each($("#unauthreq_form").find(':checkbox'),function(){data.captcha[this.name]=$(this).prop('checked');})

		// save it
		$.ajax({
			type: 'POST',
			url: 'json/unauthreq/data?'+getUrlTokenArg(),
			async: true,
			cache: false,
			dataType: 'json',
			data: JSON.stringify( data ),
			contentType: 'application/json;charset=UTF-8',
			success: function (json) {
				if(typeof json==='object' && json.results==='success'){
					change_saved();
					$('#invalid_config').removeClass('show');
					UnauthRequests.loaddata();
				}
				else {
					$('#invalid_config').addClass('show');
				}
			}
		});
		return false;
	}
};

$(document).ready(function(){
	UnauthRequests.loaddata();
});

//]]>
</script>

<form method='post' id='unauthreq_form'>

<table>
<?php if(!$revation->adminGlobal()){
	echo"<tr><td>Unauthenticated Chat CAPTCHA:</td><td><label><input type='checkbox' id='chat' name='chat' onchange='change_made();' /> require CAPTCHA</label></td></tr>";
	echo"<tr><td>Unauthenticated Calendar CAPTCHA:</td><td><label><input type='checkbox' id='calendar' name='calendar' onchange='change_made();' /> require CAPTCHA for certain calendar requests</label></td></tr>";
}?>
	<tr><td>CAPTCHA Type:</td><td>
		<select class="groupselect" size="1" id="type" name="type" onchange="change_made();">
		<option value="">(default)</option>
		<option value="reCAPTCHAv3">reCAPTCHAv3</option>
		</select>
	</td></tr>
	<tr><td>CAPTCHA Service URL:</td><td>
		<input type='text' id='verifyURL' name='verifyURL' size='100' onchange="change_made();" oninput="change_made();" />
	</td></tr>
	<tr><td>CAPTCHA Service App ID:</td><td>
		<input type='text' id='appID' name='appID' size='100' onchange="change_made();" oninput="change_made();" />
	</td></tr>
	<tr><td>CAPTCHA Service App Key:</td><td>
		<input type='text' id='appKey' name='appKey' size='100' onchange="change_made();" oninput="change_made();" />
	</td></tr>

	<tr><td>Maps Type:</td><td>
		<select class="groupselect" size="1" id="maps_type" name="maps_type" onchange="change_made();">
<?php if(!$revation->adminGlobal())echo'<option value="">(inherit)</option>';?>
		<option value="(disabled)">(disabled)</option>
		<option value="google">Google</option>
		</select>
	</td></tr>
	<tr><td>Maps Service App ID:</td><td>
		<input type='text' id='maps_appID' name='maps_appID' size='100' onchange="change_made();" oninput="change_made();" />
	</td></tr>

	<tr><td colspan="2">
		<div id='change_happened' class='change_happened'>Changes made - press <b>Update Data</b> to save!</div>
		<div id='invalid_config' class='change_happened'>Error: Invalid configuration!</div>
	</td></tr>
</table>

</form>

<div style='text-align:center;'>
<?php
	echo'<input type=button name=add value="Update Data" class="btn btn-secondary btn-sm" id=apply_changes disabled=disabled ';
	if($revation->adminRight('ar_maincfg'))
		echo'onclick="return UnauthRequests.updatedata();"';
	echo'>';
?>
<input type='button' value='Clear' class='btn btn-secondary btn-sm' onclick="return UnauthRequests.cleardata();">
<input type='button' value='&#x21e6; Back' class='btn btn-dark btn-sm' onclick="window.location='embed.php?php=<?=$_SESSION['nav_back']?>&<?=$urlTokenArg?>';return false;">
</div>


<?php
include 'groupEnd.php';
include 'tableBottom.php';
?>