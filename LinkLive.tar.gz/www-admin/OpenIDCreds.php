<?php
include 'tableTop.php';
$urlTokenArg=$revation->getUrlTokenArg();
?>

<script type="text/javascript">
//<![CDATA[
var g_data = null;
var dataTable = null;
<?php echo'var view_only='.json_encode(!$revation->adminRight('ar_maincfg')).';'; ?>

function loadTable(parms){
	$.ajax({
		type: 'GET',
		url: 'json/oauth2/creds?'+getUrlTokenArg(),
		async: true,
		cache: false,
		data: parms,
		success: function (json) {
			var data = [];
			if (typeof json==='object' && Array.isArray(json.creds)){
				g_data = json.creds;
				for(var i=0;i<g_data.length;i++){
					var c=json.creds[i];
					if(typeof c==='object'){
						var	use='users';
						if(admin_global){
							use='administrators';
						}
						else if(typeof c.use==='string'){
							use=c.use;
						}
						if ( typeof c.web==='object' && typeof c.web.client_id==='string' && c.web.client_id.length) {
							data.push( [ c.web.client_id, use, i ] );
						}
						else if ( typeof c.installed==='object' && typeof c.installed.client_id==='string' && c.installed.client_id.length) {
							data.push( [ c.installed.client_id, use, i ] );
						}
					}
				}
			}
			if ( dataTable == null ) {
				var config = {
					"aaData": data,
					"bAutoWidth":false,
					responsive: true,
					"oLanguage": {
						"sEmptyTable": "(none set)"
					},
					"aoColumns": [
						{ "sClass": "nowrapellipsis", "mRender": $.fn.dataTable.render.text(), responsivePriority: 1 },
						{ "mRender": renderUse },
						{ "bSearchable": false, "bSortable": false, "mRender": renderButtons }
					],
				};
				tableConfigLoad("openidcreds", config);
				dataTable = $('#main_data_table').dataTable(config);
			}
			else {
				dataTable.fnClearTable();
				if ( data.length ) {
					dataTable.fnAddData( data );
				}
			}
		}
	});
}

$(document).ready(function(){
	loadTable();
});

$(window).on('unload',function() {
	tableConfigStore("openidcreds",dataTable.fnSettings());
});

function addJSON(){
	var num=$("#cred_add").val();
	if(num && num.length){
		$("#cred_add").val("");
		change_saved();
		loadTable('add='+encodeURIComponent(num));
	}
}

function deleteItem(i) {
	var o=g_data[i].web;
	if(!o){
		o=g_data[i].installed;
	}
	if(o && typeof o.client_id==='string'){
		$('#delete_id').text(o.client_id);
		$('#delete_input_id').attr('onclick', 'loadTable(\'del='+encodeURIComponent(o.client_id)+'\');$(\'#cred_del\').modal(\'hide\');');
		var dlg = $('#cred_del');
		dlg.modal('show');
	}
}

function viewItem(i,select_change) {
	if(select_change){
		g_data[i].use=select_change.value;
		change_made();
	}
	$('#cred_add').val(JSON.stringify(g_data[i]));
}

var use_array=['users','administrators','both','neither'];

function renderUse(data, type, full) {
	if(admin_global){
		return 'administrators';
	}
	else {
		var selected=0;
		for(var i=0;i<use_array.length;++i){
			if(full[1]==use_array[i]){
				selected=i;
				break;
			}
		}
		var html='<select class="form-control" onchange="viewItem('+full[2]+',this);">';
		for(var i=0;i<use_array.length;++i){
			html+='<option';
			if(selected==i){
				html+=' selected';
			}
			html+='>'+use_array[i]+'</option>';
		}
		html+='</select>';
		return html;
	}
}

function renderButtons( data, type, full ) {
	var buttons = '<div style="white-space: nowrap;">';

	// delete button
	buttons += '<input type=button value=delete class="btn btn-secondary btn-sm"';
	if(view_only) {
		buttons+=' disabled=disabled';
	}
	else {
		buttons += ' onclick="return deleteItem(\''+full[2]+'\')"';
	}
	buttons += '>';

	// view button
	buttons += ' <input type=button value=view class="btn btn-secondary btn-sm" onclick="return viewItem(\''+full[2]+'\')">';

	buttons += '</div>';

	return buttons;
}
//]]>
</script>

<div class='legend'>OpenID Connect Credentials for <?php if($revation->adminGlobal())echo'Global Administrators';else echo$revation->adminGroup();?></div>
<table cellpadding="0" cellspacing="0" border="0" class="display table-striped table-bordered nowrap w-100" id="main_data_table">
  <thead>
    <tr>
      <th title="The client identifiers of the individual configurations">Client identifiers</th>
      <th title="How the authentication is used; users, administrators, both, or neither">Auth Type</th>
      <th>&nbsp;</th>
    </tr>
  </thead>
  <tfoot><tr><th colspan="3">&nbsp;</th></tr></tfoot>
</table>
<br/>
<div style='text-align:center;'>
  <br/>
  <div style='font-size: smaller;'>
    To add a credential object, paste the JSON object into the text field and press <b>Add/Update Credential</b>.
  </div>
  <div style='font-size: smaller;'>
	A valid object looks like: <span class="valch">{"web":{"client_id":"...","auth_uri":"...",...}}</span>
  </div>
  <div style='font-size: smaller;'>
	Optional custom attribute for the <span class="valch">web</span> object: <span class="valch">form_gui</span> object can contain
	a <span class="valch">login_title</span> string like "Click to Log In with MyIdP" and
	a <span class="valch">cred_input</span> boolean which, if true, also shows the standard Log In dialog.
  </div>
  <br/>
  <textarea name="cred_add" id="cred_add" rows="10" cols="120"></textarea>
  <br/>
  <div id='change_happened' class='change_happened'>Changes made - press <b>Add/Update Credential</b> to save!</div>
  <br/>
<?php
	echo'<input type=button name=add value="Add/Update Credential" class="btn btn-secondary btn-sm" ';
	if($revation->adminRight('ar_maincfg'))
		echo'onclick="addJSON();return false;"';
	else
		echo'disabled';
	echo'>';
?>
<input type='button' value='&#x21e6; Back' class='btn btn-dark btn-sm' onclick="window.location='embed.php?php=<?=$_SESSION['nav_back']?>&<?=$urlTokenArg?>';return false;">
</div>

<div class="modal fade text-center" id="cred_del" role="dialog">
    <div class="modal-dialog" role="document" style="padding-top: 15%; text-align: left; max-width: 100%; width: auto !important; display: inline-block;">
        <div class="modal-content" style="overflow: auto;">
            <div class="modal-header light-background">
                <h5 class="modal-title">Delete Client Credential</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete the client credentials identified by '<span id='delete_id' style="font-weight: bold;"></span>'?</p>
                <div style="text-align: center;">
                    <input id="delete_input_id" type=button value=Delete class='btn btn-secondary btn-sm' />
                    <input type=button value=Cancel class='btn btn-secondary btn-sm' data-dismiss="modal" />
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'tableBottom.php';?>