<?php
include 'tableTop.php';
$urlTokenArg=$revation->getUrlTokenArg();
$file_changes=$revation->config('trunkRestrictions');
?>

<script type="text/javascript">
//<![CDATA[
var g_data = null;
var dataTable = null;
var view_only = true;
<?php
if($revation->adminRight('ar_trunkrestrict'))echo'view_only = false;';
?>

function loadTable(parms){
	$.ajax({
		type: 'GET',
		url: 'json/trunkRestrictions?<?=$urlTokenArg?>',
		async: true,
		cache: false,
		data: parms,
		success: function (json) {
			g_data = json;
			var data = [];
			if (json.trunkRestrictions){
				for(var i=0;i<json.trunkRestrictions.length;i++){
					data.push( [ json.trunkRestrictions[i], i ] );
				}
			}
			if ( dataTable == null ) {
				var config = {
					"aaData": data,
					"bAutoWidth":false,
					responsive: true,
					"oLanguage": {
						"sEmptyTable": "(none set)"
					},
					"aoColumns": [
						{ "mRender": $.fn.dataTable.render.text(), responsivePriority: 1 },
						{ "bSearchable": false, "bSortable": false, "mRender": renderButtons }
					],
				};
				tableConfigLoad("trunkres", config);
				dataTable = $('#main_data_table').dataTable(config);
			}
			else {
				dataTable.fnClearTable();
				if ( data.length ) {
					dataTable.fnAddData( data );
				}
			}
		}
	});
}

$(document).ready(function(){
	loadTable();
});

$(window).on('unload',function() {
	tableConfigStore("trunkres",dataTable.fnSettings());
});

function addNumber(){
	var num=$("#number").val();
	if(num && num.length){
		$("#number").val("");
		loadTable('add='+encodeURIComponent(num));
	}
}

function deleteItem(i) {
	$('#delete_id').text(i);
	$("#delete_input_id").attr('onclick', 'loadTable(\'del='+encodeURIComponent(i)+'\');$(\'#patternDelete\').modal(\'hide\');');

	var dlg = $('#patternDelete');
	dlg.modal('show');
}

function renderButtons( data, type, full ) {
	var buttons = '<div style="white-space: nowrap;">';

	// delete button
	buttons += '<input type=button value=delete class="btn btn-secondary btn-sm"';
	if(view_only) {
		buttons+=' disabled=disabled';
	}
	else {
		buttons += ' onclick="return deleteItem(\''+full[0]+'\')"';
	}
	buttons += '>';
	buttons += '</div>';

	return buttons;
}
//]]>
</script>

<div class='legend'>Trunk Restrictions for <?php echo $revation->adminGroup();?></div>
<table cellpadding="0" cellspacing="0" border="0" class="display table-striped table-bordered nowrap w-100" id="main_data_table">
  <thead>
    <tr>
      <th title="Outbound Telephone Patterns Users Can Not Call">Restricted Number Patterns</th>
      <th>&nbsp;</th>
    </tr>
  </thead>
  <tfoot><tr><th>&nbsp;</th><th>&nbsp;</th></tr></tfoot>
</table>
<br/>
  <div style='text-align:center;' class='small_note'>
    Calls from the domain <span style='text-decoration: underline;'>to these patterns</span> will be rejected
  </div>
<div style='text-align:center;'>
  <a class="btn btn-light btn-block service_accordion" data-toggle="collapse" href="#formatting_accordion" role="button" aria-controls="formatting_accordion" aria-expanded="false" style="text-align: left; font-weight: 500;" >formatting<span></span></a>
  <div id="formatting_accordion" class="collapse">
  <div style='font-size: smaller;'>
    Valid chars are: <span class="valch">+0123456789*#</span>
    <br/>
    Visual separators are ignored: <span class="valch">SPACE-.()/</span>
    <br/>
    <span class="valch">?</span> means 0 or 1 of previous rule,
    <br/>
	<span class="valch">%</span> means 0 or more of previous rule,
    <br/>
	<span class="valch">X</span> means any char <span class="valch">0123456789*#</span>
    <br/>
	<span class="valch">[]</span> means set or range, e.g. <span class="valch">[7-9]</span> or <span class="valch">[789]</span>
    <br/>
	Multiple numbers can be entered at once using a comma or semicolon separator.
    <br/>
	When uploading a .CSV file, prepend the line with a tilde (~) to delete the rule.
  </div>
  </div>
<?php
if(!$revation->adminGlobal()){
	echo'<textarea name="number" id="number" rows="1" cols="40"></textarea><br/><input type=button name=add value="Add Number" class="btn btn-secondary btn-sm" ';
	if($revation->adminRight('ar_trunkrestrict'))
		echo'onclick="addNumber();return false;"';
	else
		echo'disabled';
	echo'>';
}
?>
<input type='button' value='&#x21e6; Back' class='btn btn-dark btn-sm' onclick="window.location='embed.php?php=<?=$_SESSION['nav_back']?>&<?=$urlTokenArg?>';return false;">
</div>

<div style="text-align:center;" class="mt-2">
    <form method='post' action="embedalone.php?doc=TrunkRestrictions.csv&<?=$urlTokenArg?>" target='_blank' style='display: inline;'>
    <input type="hidden" name="pg" value="<?=$revation->adminGroup()?>" />
    <input type="submit" name="save" value="Download .CSV" class="btn btn-secondary btn-sm" />
    </form>
    <form method='post' action='embed.php?php=TrunkRestrictions&<?=$urlTokenArg?>' enctype='multipart/form-data' style='display: inline;'>
    <input type="hidden" name="pg" value="<?=$revation->adminGroup()?>" />
	<label class="btn btn-secondary btn-sm" style="margin-bottom: 0;">
    <input hidden title='Upload .CSV' type='file' name='filename' id='uploadButton' onchange='if(this.value){if(this.value.search(/\.csv/i)==-1){alert("file not of correct extension!");this.form.reset();return false;}else{this.form.submit();return true;}}' />
	Upload .CSV...
	</label>
    </form>
	<?php if($file_changes)echo'<br/>'.$file_changes;?>
</div>


<div class="modal fade text-center" id="patternDelete" role="dialog">
    <div class="modal-dialog" role="document" style="padding-top: 15%; text-align: left; max-width: 100%; width: auto !important; display: inline-block;">
        <div class="modal-content" style="overflow: auto;">
            <div class="modal-header light-background">
                <h5 class="modal-title">Delete Pattern</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete the pattern '<span id='delete_id' style="font-weight: bold;"></span>'?</p>
                <div style="text-align: center;">
                    <input id="delete_input_id" type=button value=Delete class='btn btn-secondary btn-sm' />
                    <input type=button value=Cancel class='btn btn-secondary btn-sm' data-dismiss="modal" />
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'tableBottom.php';?>