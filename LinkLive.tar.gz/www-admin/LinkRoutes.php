<?php
$urlTokenArg=$revation->getUrlTokenArg();
include 'tableTop.php';
?>

<script>

var routes = null;
var dataTable = null;

function loadTable() {
	$.ajax({
		type: 'GET',
		url: 'json/linkRoutes?<?=$urlTokenArg?>',
		async: true,
		cache: false,
		success: function (json) {
			if (json.linkRoutes){
				routes = json.linkRoutes;
				var data = [];
				for(var i=0;i<routes.length;i++){
					data.push( [ 
						routes[i].local, 
						routes[i].remote, 
						routes[i].status, i 
					] );
				}
				if ( dataTable == null ) {
					var config = {
						"aaData": data,
						"bAutoWidth":false,
						responsive: true,
						"aoColumns": [
							{ "sTitle": "Local Group", "mRender": $.fn.dataTable.render.text(), responsivePriority: 1 },
							{ "sTitle": "Remote Group", "mRender": $.fn.dataTable.render.text(), responsivePriority: 2 },
							{ "sTitle": "Status", "mRender": $.fn.dataTable.render.text() },
							{ "sTitle": "&nbsp;", "bSearchable": false, "bSortable": false, "mRender": renderButtons }
						]
					};
					tableConfigLoad("linkroutes", config);
					dataTable = $('#main_data_table').dataTable(config);
				}
				else {
					dataTable.fnClearTable();
					if (data.length) {
						dataTable.fnAddData( data );
					}
				}
			}
		}
	});
}

$(document).ready(function(){
	loadTable();
});

$(window).on('unload',function() {
	tableConfigStore("linkroutes",dataTable.fnSettings());
});

function renderButtons( data, type, full ) {
	var buttons = '<div style="white-space: nowrap;">';
	buttons += '<input type=button value=edit class="btn btn-secondary btn-sm" onclick="window.location=\'embed.php?doc=LinkRoute.html&<?=$urlTokenArg?>&edit_l='+encodeURIComponent(full[0])+'&edit_r='+encodeURIComponent(full[1])+'\';return false;\">';
	buttons += '</div>';
	return buttons;
}

</script>

<div class='legend'>UC Routes</div>
<table cellpadding="0" cellspacing="0" border="0" class="display table-striped table-bordered nowrap w-100" id="main_data_table">
<tfoot><tr><th colspan=4>&nbsp;</th></tr></tfoot>
</table>
<br/>
<div style='text-align:center;'>
<br/>
<?php
if($revation->adminRight('ar_servers')){
	echo'<input type=button name=add value="Add New UC Route" class="btn btn-secondary btn-sm" onclick="window.location=\'embed.php?doc=LinkRoute.html&'.$urlTokenArg.'&add\';return false;">&nbsp;';
}
?>
<input type=button value="Refresh" class='btn btn-secondary btn-sm' onclick="loadTable();return false;">
<input type=button value="&#x21e6; Back" class="btn btn-dark btn-sm" onclick="window.location='embed.php?php=Tools&<?=$urlTokenArg?>';return false;">
</div>

<?php include 'tableBottom.php';?>