<?php
if(!empty($_REQUEST['jwt']))
	$results=$revation->adminLogonOAuth($_REQUEST['jwt']);
else if(!empty($_REQUEST['pswd']))
	$results=$revation->adminLogon($_REQUEST['user'],$_REQUEST['pswd']);
else if($_REQUEST['RelayState']=='admin'||$_SERVER['SSL_CLIENT_VERIFY']=='SUCCESS')
	$results=$revation->adminLogon();
$urlTokenArg=$revation->getUrlTokenArg();
if(isset($_SESSION)){
	if($_SERVER['REQUEST_METHOD']=='POST')
		header("HTTP/1.1 303 See Other");
	if(isset($_REQUEST['dbid'])||$revation->adminAccessType()!=0)
		header('Location: embed.php?php=mail/dbitem&'.$urlTokenArg.'&vtop=1&dbid='.urlencode($_REQUEST['dbid']));
	else if($revation->adminGlobal())
		header('Location: embed.php?doc=Status.html&'.$urlTokenArg);
	else
		header('Location: embed.php?php=Users&'.$urlTokenArg);
	exit();
}
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>LinkLive</title>
<script type="text/javascript">
<?php
echo'var group='.json_encode($_REQUEST['group']).',dbid='.json_encode($_REQUEST['dbid']).';';if(isset($_REQUEST['LOGON_TIMEOUT']))echo'var auth_results=\'LOGON_TIMEOUT\';';else echo'var auth_results=\''.$results.'\';';
if($results=='LOGOUT')echo'uri=window.location.pathname.split(\'/\');uri.splice(uri.length-1,1);uri=uri.join(\'/\')+\'/\';if(group!==null)uri+=\'?group=\'+encodeURIComponent(group);window.history.replaceState(null, null, uri);';
?>
</script>
<link rel='stylesheet' href='js/bootstrap.min.css' type='text/css'/>
<script type="text/javascript" src="js/jquery-3.6.3.min.js"></script>
<script type="text/javascript" src="admin.js"></script>
<script type="text/javascript" src="login.js"></script>
<link rel='stylesheet' href='skin.css' type='text/css' />
</head>
<body data-timeout='none' class='login-body light-background' style='display: none; width: 100%; height: 100%;'>
<script type="text/javascript"> 
if (self == top) {
	var theBody = document.getElementsByTagName('body')[0];
	theBody.style.display = "block";
} else { 
	top.location = self.location; 
}
</script>
<div class="login-copy">&copy; 2023 LinkLive</div>

<div class="container-login">
	<div class="branding-login"><img src="imgs/logo-sm.png" alt="LinkLive 9"></div>

	<div class='display_none hilight_red' id='error_area'></div>

	<form method='post' action='index.php' id='cred_form'>
		<div class='login-form display_none' id='cred_display'>
			<input type='hidden' name='group'>
			<div class='login'>Log In</div>
			<div class='login_field_desc'>User Name</div>
			<div class='login_field'><input type='text' placeholder='user name' name='user' id='user' onfocus='login_focusset=true;' value='<?php echo htmlspecialchars($_REQUEST['user']);?>' tabindex='1' autocomplete='off' autocorrect='off' autocapitalize='off'></div>
			<div class='login_field_desc'>Password</div>
			<div class='login_field'><input type='password' placeholder='password' name='pswd' id='pswd' onfocus='login_focusset=true;' tabindex='2' autocomplete='off' autocorrect='off' autocapitalize='off'></div>
			<div class='login_field_desc'><input style='min-width:6em;' type='submit' value='Log In' class='btn btn-primary btn-sm' id='log_in_button' tabindex='3'></div>
		</div>
	</form>

	<form method='post' action='index.php' id='sso_form'>
		<div class='login-form display_none' id='form_sso'>
			<input type='hidden' name='group'>
			<div class='login' id='sso_title_area'>Click to Log In</div>
			<div id="google-signin"></div> <div id='revg-enter' class='revg-tool'>&#x21ba; Enter</div><div id='revg-signout' class='revg-tool'>&#x2716; Sign out</div>
			<div class='login_field_desc'><input style='min-width:6em;' type='submit' value='Log In' class='display_none btn btn-primary btn-sm' id='sso_log_in_button' tabindex='3'></div>
		</div>
	</form>
</div>

</body>
</html>