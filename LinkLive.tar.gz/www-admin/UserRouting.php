<?php
include 'tableTop.php';
$urlTokenArg=$revation->getUrlTokenArg();
?>

<script type="text/javascript" src="user.js"></script>
<script type="text/javascript">
//<![CDATA[
var dataTable = null;
var view_only = true;
<?php
if($revation->adminRight('ar_users'))echo'view_only = false;';
?>

var table_uri='api/users/<?php echo urlencode($_REQUEST['key']).'/routes/'.urlencode($_REQUEST['file']).'?pg='.urlencode($_REQUEST['pg']).'&'.$urlTokenArg;?>';

$(document).ready(function(){
    $(window).on('beforeunload', function () {
        if (change_happened) {
            return "You have unsaved changes and are navigating away, are you sure?";
        }
    });

    $('#save').prop('disabled', true);
	routing_loadTable(table_uri);
});

$(window).on('unload',function() {
	tableConfigStore("userroute",dataTable.fnSettings());
});

//]]>
</script>

<div class='legend'>User Telephone Routes for <?php echo htmlspecialchars($_REQUEST['key']);?></div>
<table>
	<tr><td>Default Source Number:</td><td><input id="route_src_default" onchange="change_made();return false;"/></td></tr>
	<tr><td>Default Destination Number:</td><td><input id="route_dst_default" onchange="change_made();return false;"/></td></tr>
</table>
<table cellpadding="0" cellspacing="0" border="0" class="display table-striped table-bordered nowrap w-100" id="main_data_table">
  <thead>
    <tr>
      <th title="Incoming Source Number">Source Number</th>
      <th title="Target Local Destination Number">Destination Number</th>
      <th title="Optional Route Priority">Priority</th>
      <th title="Optional Comments about Route">Comment</th>
      <th>&nbsp;</th>
    </tr>
  </thead>
  <tfoot>
    <tr>
      <th>&nbsp;</th>
      <th>&nbsp;</th>
      <th>&nbsp;</th>
      <th>&nbsp;</th>
      <th>&nbsp;</th>
    </tr>
  </tfoot>
</table>
<div id='change_happened' class='change_happened'>Changes made, use Apply Changes to save!</div>
<br/>
<div class='hilight_red' style='display: none;' id='load_fail'>Route table failed to load! Please contact administrator.</div>
<div class='hilight_red' style='display: none;' id='save_fail'>Route table failed to save! Please contact administrator.</div>
<div style='text-align:center;'>
<?php
echo'<input type=button name=add class="btn btn-secondary btn-sm" data-toggle="modal" data-target="#notifyTarget" value="Add Route" ';
if($revation->adminRight('ar_users'))
	echo'onclick="return routing_showAdd();"';
else
	echo'disabled';
echo' />';
echo'&nbsp;<input type=button id=save value="Apply Changes" class="btn btn-secondary btn-sm" ';
if($revation->adminRight('ar_users'))
	echo'onclick="return routing_saveTable(table_uri);"';
else
	echo'disabled';
echo' />';
?>
<input type='button' value='&#x21e6; Back' class='btn btn-dark btn-sm' onclick="window.location='embed.php?doc=UserEdit.html&<?=$urlTokenArg?>&edit=<?php echo urlencode($_REQUEST['key']).'&privateGroup='.urlencode($_REQUEST['pg']);?>';return false;">
</div>

<div class="modal fade text-center" id="routing_add" role="dialog">
    <div class="modal-dialog" role="document" style="padding-top: 15%; text-align: left; max-width: 100%; width: auto !important; display: inline-block;" >
        <div class="modal-content" style="overflow: auto;"> 
            <div class="modal-header light-background">
                <h5 class="modal-title">Add Route</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <table>
                    <tr><td>Source:</td><td><input id="route_src" autofocus onblur="return routing_addCheck();"/> <span id="route_src_okay" style="visibility: hidden; background-color: red; color: white;"/>Invalid!</span></td></tr>
                    <tr><td>Destination:</td><td><input id="route_dst" onblur="return routing_addCheck();"/> <span id="route_dst_okay" style="visibility: hidden; background-color: red; color: white;"/>Invalid!</span></td></tr>
                    <tr><td>Priority:</td><td><input id="route_pri" onblur="return routing_addCheck();"/> <span id="route_pri_okay" style="visibility: hidden; background-color: red; color: white;"/>Invalid!</span></td></tr>
                    <tr><td>Comment:</td><td><input id="route_cmt" style="min-width: 24em;" onblur="return routing_addCheck();"/></td></tr>
                </table>
                <div style="text-align: center;">
                    <input type=button value=Save disabled class='btn btn-secondary btn-sm' onclick="return routing_doAdd();" id="route_save"/>
                    <input type=button value=Cancel class='btn btn-secondary btn-sm' data-dismiss="modal" />
                </div>
                <div style='font-size: smaller;'>
                    Valid Source/Destination chars are: <span class="valch">0123456789*#NZPXA.!</span>
                    <div style='margin-left: 1em;'>
                    <span class="valch">N</span> means exactly one of 2-9,
                    <br/>
                    <span class="valch">Z</span> means exactly one of 1-9,
                    <br/>
                    <span class="valch">P</span> means exactly one of 0-8,
                    <br/>
                    <span class="valch">X</span> means exactly one of 0-9,
                    <br/>
                    <span class="valch">A</span> means exactly one of 0-9 (same as <span class="valch">X</span>),
                    <br/>
                    <span class="valch">.</span> wildcard matches one or more characters,
                    <br/>
                    <span class="valch">!</span> wildcard matches zero or more characters
                    </div>
                    Comment is free-form text and optional.
                    <br/>
                    Priority is an optional positive integeger and (defaults to 1); lower is higher priority.
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade text-center" id="routing_delete" role="dialog">
    <div class="modal-dialog" role="document" style="padding-top: 15%; text-align: left; max-width: 100%; width: auto !important; display: inline-block;" >
        <div class="modal-content" style="overflow: auto;"> 
            <div class="modal-header light-background">
                <h5 class="modal-title">Delete Route</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                Are you sure you want to delete this route?
                <table>
                    <tr><td>Source:</td><td id="delete_src"></td></tr>
                    <tr><td>Destination:</td><td id="delete_dst"></td></tr>
                    <tr><td>Priority:</td><td id="delete_pri"></td></tr>
                    <tr><td>Comment:</td><td id="delete_cmt"></td></tr>
                </table>
                <div style="text-align: center;">
                    <input type=button value=Delete class='btn btn-secondary btn-sm' onclick="return routing_doDelete();" />
                    <input type=button value=Cancel class='btn btn-secondary btn-sm' data-dismiss="modal" />
                </div>
            </div>
        </div>
    </div>
</div>


<?php include 'tableBottom.php';?>