var editorXml = null;
var editorXmlChanged = false;
var editorXmlActiveLine = null;

function editXmlInit(ext) {
    var config = {
        indentUnit: 4,
        smartIndent: true,
        lineWrapping: true,
        lineNumbers: true,
        autofocus: true,
        styleActiveLine: true
    };

    function completeAfter(cm, pred) {
        var cur = cm.getCursor();
        if (!pred || pred()) setTimeout(function () {
            if (!cm.state.completionActive)
                cm.showHint({ completeSingle: false });
        }, 100);
        return CodeMirror.Pass;
    }

    function completeIfAfterLt(cm) {
        return completeAfter(cm, function () {
            var cur = cm.getCursor();
            return cm.getRange(CodeMirror.Pos(cur.line, cur.ch - 1), cur) == "<";
        });
    }

    function completeIfInTag(cm) {
        return completeAfter(cm, function () {
            var tok = cm.getTokenAt(cm.getCursor());
            if (tok.type == "string" && (!/['"]/.test(tok.string.charAt(tok.string.length - 1)) || tok.string.length === 1)) return false;
            var inner = CodeMirror.innerMode(cm.getMode(), tok.state).state;
            return inner.tagName;
        });
    }

    if (ext === 'js') {
        config.mode = 'javascript';
    }
    else if (ext === 'json') {
        config.mode = 'application/json';
        config.indentUnit = 2;
        config.matchBrackets = true;
        config.autoCloseBrackets = true;
    }
    else if (ext !== 'txt' && ext !== 'log') {
        config.mode = 'htmlmixed';
        if (ext === 'xml' || ext === 'scxml') {
            // set the hints
            var boolean = ["true", "false"];
            var commands = ["assign", "clear", "var", "audiostart", "audiostop", "audiosendtones", "media", "audiostartrec", "audiostoprec", "videostart", "videostop", "raise", "cancel", "send", "exit", "if", "elseif", "else", "transition", "fetch", "file", "log", "script", "voicemail"];
            var state_commands = commands;
            state_commands.push("onentry");
            state_commands.push("onexit");
            var tags = {
                "!top": ["scxml"],
                scxml: {
                    attrs: {
                        initial: null,
                        global: null,
                        version: ["1.0"]
                    },
                    children: ["state", "initial", "final", "presentities"]
                },
                initial: {
                    children: ["transition"]
                },
                final: {
                    attrs: { id: null },
                    children: ["onentry"]
                },
                presentities: {
                    children: ["watch"]
                },
                watch: {
                    children: ["presentity"]
                },
                presentity: {
                    attrs: { pid: null, pidExpr: null }
                },
                state: {
                    attrs: { id: null },
                    children: state_commands
                },
                onentry: {
                    children: commands
                },
                onexit: {
                    children: commands
                },
                assign: {
                    attrs: { name: null, expr: null },
                    children: null
                },
                audiostart: {
                    attrs: {
                        src: null,
                        srcExpr: null,
                        loop: boolean,
                        queue: boolean,
                        clear: boolean,
                        makenum: null
                    },
                    children: ["queue"]
                },
                queue: {
                    attrs: { src: null, srcExpr: null }
                },
                audiostop: {
                },
                audiostartrec: {
                    attrs: { filename: null }
                },
                audiostoprec: {
                },
                audiosendtones: {
                    attrs: { srcExpr: null }
                },
                cancel: {
                    attrs: { sendid: null }
                },
                clear: {
                    attrs: { namelist: null }
                },
                exit: {
                },
                fetch: {
                    attrs: {
                        uri: null,
                        method: ["GET", "POST", "PUT", "DELETE"],
                        content: null,
                        content_type: null,
                        event: null,
                        timeout: null
                    }
                },
                file: {
                    attrs: {
                        src: null,
                        srcExpr: null,
                        dst: null,
                        dstExpr: null,
                        action: ["delete", "move"]
                    }
                },
                "if": {
                    attrs: { cond: null },
                    children: commands
                },
                elseif: {
                    attrs: { cond: null },
                    children: commands
                },
                "else": {
                    children: commands
                },
                log: {
                    attrs: { expr: null, filename: null }
                },
                media: {
                    attrs: {
                        action: ["seek", "rewind", "pause", "resume", "pause-toggle"],
                        offset: null
                    }
                },
                raise: {
                    attrs: { event: null }
                },
                script: {
                },
                send: {
                    attrs: {
                        event: null,
                        delay: null,
                        sendid: boolean
                    },
                    children: ["bridge","display","drop","html","join","log","mail","message","replace","transfer"]
                },
                transition: {
                    attrs: {
                        event: ["agentjoined","agentconfirm","agentdone","agentwrap","bridgefailed","joined","joined-voice","left","link-clicked","message","prompt-response","voicestart","webcommunicator","terminated","audiodone","videodone","statuschange","tonestart","tonestop","tonesdone"],
                        cond: null,
                        target: null,
                        document: null
                    },
                    children: commands
                },
                "var": {
                    attrs: { name: null, expr: null }
                },
                videostart: {
                    attrs: {
                        src: null,
                        srcExpr: null,
                        loop: boolean,
                        queue: boolean,
                        clear: boolean
                    },
                    children: ["queue"]
                },
                videostop: {
                },
                voicemail: {
                    attrs: {
                        seq: null,
                        action: ["play","set-seen","set-saved","play-saved","clear-saved","delete","forward","forward-saved"],
                        mailbox: null
                    }
                }
            };

            config.extraKeys = {
                "'<'": completeAfter,
                "'/'": completeIfAfterLt,
                "' '": completeIfInTag,
                "'='": completeIfInTag,
                "Ctrl-Space": "autocomplete"
            };
            config.hintOptions = { schemaInfo: tags };
        }
    }

    editorXml = CodeMirror.fromTextArea(document.getElementById("editXmlFile"), config);

    editorXml.on("change", function () {
        editorXmlChanged = true;
    });

    editorXmlActiveLine = editorXml.addLineClass(0, "background", "activeline");
    editorXml.focus();
}

var editXmlErrorString = "", editXmlErrorH3OK = 1;

function editXmlCheck(n) {
    var l, i, nam;
    nam = n.nodeName;
    if (nam === "h3") {
        if (editXmlErrorH3OK == 0) {
            return;
        }
        editXmlErrorH3OK = 0;
    }
    if (nam === "#text") {
        editXmlErrorString = editXmlErrorString + n.nodeValue + "\n";
    }
    l = n.childNodes.length;
    for (i = 0; i < l; i++) {
        editXmlCheck(n.childNodes[i]);
    }
}

function escapeHTML(text) {
    if (typeof text !== 'string') {
        return '';
    }
    else {
        var map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, function (m) { return map[m]; });
    }
}

function Contact() {
    this.key = null;
    // (string) type if in Contacts.array, ServerGroup|Contact|Phone|Url|Group
    // (bool) expanded if ServerGroup|Group and children are visible
    // (number) level if in Contacts.array, 0+
    // (string) status if in Contacts.subscribed, e.g. 'offline'
}

function Contacts() {
    var array = [];

    this.html = function () {
        var html = '';
        var current_level = 0;
        var nav_group = 1;
        for (var i = 0; i < array.length; i++) {
            while (array[i].level < current_level) {
                current_level--;
                html += '</ul>';
            }
            if (array[i].type == 'ServerGroup' || array[i].type == 'Group') {
                var expanded = 'false';
                var expanded_in = '';
                if (array[i].expanded) {
                    expanded = 'true';
                    expanded_in = ' in';
                }

                html += '<a class="contact_group status_offline" data-toggle="collapse" data-parent="#collapsible-nav-group-' + nav_group + '" href="#collapse-nav-group-' + nav_group + '" aria-expanded="' + expanded;
                html += '" aria-controls="collapse-nav-group-' + nav_group + '"><div></div> ' + escapeHTML(array[i].key) + '</a>' +
                    '<ul id="collapse-nav-group-' + nav_group + '" class="nav panel-collapse collapse' + expanded_in + '" role="tabpanel" aria-labelledby="collapsible-nav-group-' + nav_group + '" aria-expanded="' + expanded + '">';
                current_level++;
                nav_group++;
            }
            else if (array[i].type == 'Contact') {
                if (!array[i].hidden) {
                    var status = { status: 'online' };
                    var display = escapeHTML(array[i].alias ? array[i].alias : status.display ? status.display : array[i].key);
                    html += '<a href="#" class="contact_item status_' + status.status + '" data-revpid="' + escapeHTML(array[i].key) + '" data-revstatus="' + status.status + '"';
                    if (array[i].alias) {
                        html += ' data-revalias="' + escapeHTML(array[i].alias) + '"';
                    }
                    if (array[i].display) {
                        html += ' data-revdisplay="' + escapeHTML(array[i].display) + '"';
                    }
                    html += '><div></div> <span>' + display + '</span>';
                    if ((status.status != 'online' && status.status != 'offline') || status.statusCustom) {
                        html += ' <span class="status_secondary">(' + status.status;
                        if (status.statusCustom) {
                            html += ' - ' + escapeHTML(status.statusCustom);
                        }
                        html += ')</span>';
                    }
                    html += '</a>';
                }
            }
            else if (array[i].type == 'Url') {
                if (!array[i].hidden) {
                    var url = escapeHTML(array[i].key);
                    var alias = array[i].alias ? escapeHTML(array[i].alias) : null;
                    html += '<a href="' + url + '" data-type="url" target="_blank" class="contact_item contact_url" data-revpid="' + url + '"><div></div> <span>' + (alias ? alias : url) + '</span></a>';
                }
            }
            else if (array[i].type == 'Phone') {
                if (!array[i].hidden) {
                    var phone = escapeHTML(array[i].key);
                    var alias = array[i].alias ? escapeHTML(array[i].alias) : null;
                    html += '<a href="#" data-type="phone" class="contact_item contact_phone" data-revpid="' + phone + '"><div></div> <span>' + (alias ? alias : phone) + '</span></a>';
                }
            }
        }
        while (0 < current_level) {
            current_level--;
            html += '</ul>';
        }
        return html;
    };

    this.resetClickHandlers = function () {
        // reset the click class selector for the contacts
        $(".contact_group").off('click').on('click', function () {
            var a = $(this);
            var p = $('#' + a.attr('aria-controls'));
            if (p.hasClass('in')) {
                // it's expanded, contract it
                p.removeClass('in');
                a.children('div').css('background-image', 'url(buddy-imgs/down.png)');
            }
            else {
                // it's contracted, expand it
                p.addClass('in');
                a.children('div').css('background-image', 'url(buddy-imgs/up.png)');
            }
        });
    };

    var readConfig = function (contact, node) {
        var alias = node.attributes.getNamedItem('alias');
        if (alias) {
            // short form
            contact.alias = alias.value;
            return;
        }

        var hidden = node.attributes.getNamedItem('hidden');
        if (hidden && hidden.value.toLowerCase() == 'true') {
            contact.hidden = true;
        }

        for (var j = 0; j < node.childNodes.length; j++) {
            var cn = node.childNodes[j];
            if (cn.nodeName == "alias" && cn.childNodes.length > 0 && cn.childNodes[0].nodeValue != null) {
                contact.alias = cn.childNodes[0].nodeValue;
            }
        }
    };

    this.xmlContacts = function (nodes, level) {
        for (var i = 0; i < nodes.length; i++) {
            if (nodes[i].nodeName == "contact" || nodes[i].nodeName == "item") {
                var key = nodes[i].attributes.getNamedItem('key');
                if (!key) {
                    key = nodes[i].attributes.getNamedItem('id');
                }
                if (key) {
                    // create the new contact
                    var contact = new Contact();
                    contact.key = key.value.toLowerCase();
                    contact.level = level;
                    contact.type = 'Contact';
                    readConfig(contact, nodes[i]);
                    array.push(contact);
                }
            }
            else if (nodes[i].nodeName == "phone") {
                var key = nodes[i].attributes.getNamedItem('key');
                if (key) {
                    var contact = new Contact();
                    contact.key = key.value;
                    contact.level = level;
                    contact.type = 'Phone';
                    readConfig(contact, nodes[i]);
                    array.push(contact);
                }
            }
            else if (nodes[i].nodeName == "url" || nodes[i].nodeName == "urlwin") {
                var key = nodes[i].attributes.getNamedItem('key');
                if (key) {
                    var contact = new Contact();
                    contact.key = key.value;
                    contact.level = level;
                    contact.type = 'Url';
                    readConfig(contact, nodes[i]);
                    array.push(contact);
                }
            }
            else if (nodes[i].nodeName == "group") {
                var name = nodes[i].attributes.getNamedItem('name');
                if (name) {
                    var contact = new Contact();
                    contact.key = name.value;
                    contact.level = level;
                    contact.type = 'Group';
                    var children = nodes[i].attributes.getNamedItem('children');
                    if (!children || children.value != 'hidden') {
                        contact.expanded = true;
                    }
                    array.push(contact);
                    this.xmlContacts(nodes[i].childNodes, level + 1);
                }
            }
        }
    };
}

function editXmlValidate(render) {
    editXmlErrorString = "";
    if (!editorXml) {
        return 0;
    }
    var xmlDoc = null;
    if ("ActiveXObject" in window) {
        xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
        xmlDoc.async = "false";
        xmlDoc.loadXML(editorXml.getValue());
        if (xmlDoc.parseError.errorCode != 0) {
            editXmlErrorString = "Error Code: " + xmlDoc.parseError.errorCode + "\n";
            editXmlErrorString = editXmlErrorString + "Error Reason: " + xmlDoc.parseError.reason;
            editXmlErrorString = editXmlErrorString + "Error Line: " + xmlDoc.parseError.line;
            return -1;
        }
    }
    else if (document.implementation && document.implementation.createDocument) {
        var parser = new DOMParser();
        xmlDoc = parser.parseFromString(editorXml.getValue(), "text/xml");
        if (xmlDoc.getElementsByTagName("parsererror").length > 0) {
            editXmlErrorString = "";
            editXmlErrorH3OK = 1;
            editXmlCheck(xmlDoc.getElementsByTagName("parsererror")[0]);
            return -1;
        }
    }
    else {
        return 1;
    }
    if (render && xmlDoc && xmlDoc.childNodes.length && xmlDoc.childNodes[0].nodeName == 'contacts') {
        var contacts = new Contacts();
        contacts.xmlContacts(xmlDoc.childNodes[0].childNodes, 0);
        $('#contact_list').html(contacts.html());
        contacts.resetClickHandlers();
    }
    return 0;
}

function renderDirectory() {
    if (editXmlValidate(true) == 1) {
        $('#contact_list').html("Your browser could not verify the XML.");
    }
    else if (editXmlErrorString) {
        $('#contact_list').html(editXmlErrorString);
    }
}

function renderRights() {
    var html = "Rights Form<hr/>";
    if (!editorXml) {
        html += "<span class='hilight_red'>Missing Editor!</span>";
    }
    else {
        var json;
        try {
            json = JSON.parse(editorXml.getValue());
        }
        catch (e) {
            json = null;
            html += "<span class='hilight_red'>Content does not parse correctly as JSON! " + e + "</span>";
        }
        if (json) {
            if (!json || typeof json !== 'object' || (json.rights !== null && !Array.isArray(json.rights))) {
                html += "<span class='hilight_red'>JSON doesn't appear to be in 'rights' format; see Help!</span>";
            }
            else if (json.rights) {
                html += '<table>';
                for (var i = 0; i < json.rights.length; ++i) {
                    var r = json.rights[i];
                    if (r && typeof r === 'object' && typeof r.name === 'string' && typeof r.desc === 'string') {
                        if (!r.type || typeof r.type !== 'string') {
                            r.type = 'check';
                        }
                        if (r.type === 'text') {
                            html += "<tr><td>" + r.desc + ":</td><td><input type=text name='" + rwc_htmlescape(r.name) + "' id='" + rwc_htmlescape(r.name) + "'";
                            if (r.required) {
                                html += " required";
                            }
                            if (typeof r.maxlength === 'number') {
                                html += " maxlength='" + r.maxlength + '\'';
                            }
                            html += "</td></tr>";
                        }
                        else if (r.type === 'select') {
                            html += "<tr><td>" + r.desc + ":</td><td><select name='" + rwc_htmlescape(r.name) + "' id='" + rwc_htmlescape(r.name) + "'";
                            if (r.required) {
                                html += " required";
                            }
                            html += ">";
                            if (typeof r.placeholder === 'string') {
                                html += "<option disabled selected value=\"\">" + rwc_htmlescape(r.placeholder) + "</option>";
                            }
                            if (Array.isArray(r.values)) {
                                for (var j = 0; j < r.values.length; ++j) {
                                    if (typeof r.values[j] === 'string') {
                                        html += "<option value=\"\">" + rwc_htmlescape(r.values[j]) + "</option>";
                                    }
                                }
                            }
                            html += "</td></tr>";
                        }
                        else if (r.type === 'select-multiple') {
                            html += "<tr><td>" + r.desc + ":</td><td><select multiple name='" + rwc_htmlescape(r.name) + "' id='" + rwc_htmlescape(r.name) + "'>";
                            if (Array.isArray(r.values)) {
                                for (var j = 0; j < r.values.length; ++j) {
                                    if (typeof r.values[j] === 'string') {
                                        html += "<option value=\"\">" + rwc_htmlescape(r.values[j]) + "</option>";
                                    }
                                }
                            }
                            html += "</td></tr>";
                        }
                        else {
                            html += "<tr><td colspan='2'><label><input type=checkbox name=" + rwc_htmlescape(r.name) + " id=" + rwc_htmlescape(r.name) + "/> " + r.desc + "</label></td></tr>";
                        }
                    }
                }
                html += '</table>';
            }
        }
    }
    $('#rights_form').html(html);
}

function editXmlVerify() {
    if (editXmlValidate(false) == 1) {
        alert("Your browser could not verify the XML.");
    }
    else if (editXmlErrorString) {
        alert(editXmlErrorString);
    }
    else {
        alert("No XML parsing errors found.");
    }
}

function editXmlReformat() {
    editorXml.autoFormatRange(editorXml.getCursor(true), editorXml.getCursor(false));
}
