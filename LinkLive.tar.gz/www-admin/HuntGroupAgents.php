<?php
if(strpos($_REQUEST['callback'],'..')||strcspn($_REQUEST['callback'],'><:/&,?%*"\'\\')<strlen($_REQUEST['callback']))
	unset($_REQUEST['callback']);
if($_REQUEST['callback']){
    header('Content-Type: text/javascript');
    echo $_REQUEST['callback'].'(';
}
else{
    header('Content-Type: application/json');
}
if(!isset($_SESSION)){
	$revation->adminLogon($_REQUEST['admin'],$_REQUEST['pswd']);
}
echo'{'.$revation->huntGroupAgents($_REQUEST['group']).'}';
if($_REQUEST['callback']){
    echo');';
}
$revation->adminLogout();
?>